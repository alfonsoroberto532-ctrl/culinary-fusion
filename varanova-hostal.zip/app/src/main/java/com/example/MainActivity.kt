package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.VaraNovaTheme
import com.example.varanova.ui.navigation.BottomNavBar
import com.example.varanova.ui.navigation.NavRoutes
import com.example.varanova.ui.screens.*
import com.example.varanova.ui.viewmodel.HostalViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VaraNovaTheme {
                VaraNovaApp()
            }
        }
    }
}

@Composable
fun VaraNovaApp(
    viewModel: HostalViewModel = viewModel()
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: NavRoutes.Dashboard.route

    // Quick Action Flags
    var quickOpenReservation by remember { mutableStateOf(false) }
    var quickOpenExpense by remember { mutableStateOf(false) }
    var quickOpenPurchase by remember { mutableStateOf(false) }
    var quickOpenMaintenance by remember { mutableStateOf(false) }

    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()
    val reservations by viewModel.reservationsWithDetails.collectAsStateWithLifecycle()
    val maintenanceTasks by viewModel.maintenanceRecords.collectAsStateWithLifecycle()
    val supplies by viewModel.supplyItems.collectAsStateWithLifecycle()
    val context = androidx.compose.ui.platform.LocalContext.current

    // Schedule WorkManager tasks on startup
    LaunchedEffect(Unit) {
        try {
            val workManager = androidx.work.WorkManager.getInstance(context)

            // 1. Daily Database Backup Worker (24 Hours)
            val backupWorkRequest = androidx.work.PeriodicWorkRequestBuilder<com.example.varanova.utils.DailyBackupWorker>(
                1, java.util.concurrent.TimeUnit.DAYS
            ).build()

            workManager.enqueueUniquePeriodicWork(
                "DailyDatabaseBackupWork",
                androidx.work.ExistingPeriodicWorkPolicy.KEEP,
                backupWorkRequest
            )

            // 2. Inventory Stock Monitoring Worker (12 Hours)
            val inventoryWorkRequest = androidx.work.PeriodicWorkRequestBuilder<com.example.varanova.utils.InventoryMonitoringWorker>(
                12, java.util.concurrent.TimeUnit.HOURS
            ).build()

            workManager.enqueueUniquePeriodicWork(
                "InventoryStockMonitoringWork",
                androidx.work.ExistingPeriodicWorkPolicy.KEEP,
                inventoryWorkRequest
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    LaunchedEffect(reservations, maintenanceTasks) {
        if (reservations.isNotEmpty() || maintenanceTasks.isNotEmpty()) {
            com.example.varanova.utils.NotificationHelper.checkAndNotifyUpcomingEvents(
                context = context,
                reservations = reservations,
                maintenanceTasks = maintenanceTasks
            )
        }
    }

    LaunchedEffect(supplies) {
        if (supplies.isNotEmpty()) {
            com.example.varanova.utils.NotificationHelper.checkAndNotifyLowStock(
                context = context,
                supplies = supplies
            )
        }
    }

    LaunchedEffect(userMessage) {
        userMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearUserMessage()
        }
    }

    fun navigateToRoute(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        bottomBar = {
            BottomNavBar(
                currentRoute = currentRoute,
                onNavigate = { route -> navigateToRoute(route) }
            )
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NavRoutes.Dashboard.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable(NavRoutes.Dashboard.route) {
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateTab = { route -> navigateToRoute(route) },
                    onOpenQuickAction = { actionKey ->
                        when (actionKey) {
                            "add_reservation" -> {
                                quickOpenReservation = true
                                navigateToRoute(NavRoutes.Reservations.route)
                            }
                            "add_guest" -> navigateToRoute(NavRoutes.Guests.route)
                            "add_payment" -> navigateToRoute(NavRoutes.Reservations.route)
                            "add_expense" -> {
                                quickOpenExpense = true
                                navigateToRoute(NavRoutes.Finances.route)
                            }
                            "buy_supply", "consume_supply" -> {
                                quickOpenPurchase = true
                                navigateToRoute(NavRoutes.Supplies.route)
                            }
                            "report_maintenance" -> {
                                quickOpenMaintenance = true
                                navigateToRoute(NavRoutes.Operations.route)
                            }
                            "complete_cleaning" -> navigateToRoute(NavRoutes.Operations.route)
                            else -> navigateToRoute(NavRoutes.Dashboard.route)
                        }
                    }
                )
            }

            composable(NavRoutes.Reservations.route) {
                ReservationsScreen(
                    viewModel = viewModel,
                    initialOpenCreate = quickOpenReservation
                )
                quickOpenReservation = false
            }

            composable(NavRoutes.Rooms.route) {
                RoomsScreen(viewModel = viewModel)
            }

            composable(NavRoutes.Guests.route) {
                GuestsScreen(viewModel = viewModel)
            }

            composable(NavRoutes.Finances.route) {
                FinancesScreen(
                    viewModel = viewModel,
                    initialOpenExpense = quickOpenExpense
                )
                quickOpenExpense = false
            }

            composable(NavRoutes.Supplies.route) {
                SuppliesScreen(
                    viewModel = viewModel,
                    initialOpenPurchase = quickOpenPurchase
                )
                quickOpenPurchase = false
            }

            composable(NavRoutes.Operations.route) {
                OperationsScreen(
                    viewModel = viewModel,
                    initialOpenMaintenance = quickOpenMaintenance
                )
                quickOpenMaintenance = false
            }

            composable(NavRoutes.Statistics.route) {
                StatisticsScreen(viewModel = viewModel)
            }

            composable(NavRoutes.Settings.route) {
                SettingsScreen(viewModel = viewModel)
            }
        }
    }
}

