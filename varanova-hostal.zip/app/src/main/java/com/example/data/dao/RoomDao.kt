package com.example.data.dao

import androidx.room.*
import com.example.data.model.Room
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for the Room entity [com.example.data.model.Room].
 * Defines standard CRUD operations for managing rooms in the database.
 */
@Dao
interface RoomDao {

    /**
     * Retrieves all rooms ordered by name.
     */
    @Query("SELECT * FROM room_entities ORDER BY name ASC")
    fun getAll(): Flow<List<Room>>

    /**
     * Retrieves a room by its unique ID.
     */
    @Query("SELECT * FROM room_entities WHERE id = :id")
    suspend fun getById(id: Long): Room?

    /**
     * Inserts a new room into the database.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(room: Room): Long

    /**
     * Updates an existing room record.
     */
    @Update
    suspend fun update(room: Room)

    /**
     * Deletes a room from the database.
     */
    @Delete
    suspend fun delete(room: Room)

    /**
     * Alias for [getAll] to maintain compatibility across caller conventions.
     */
    @Query("SELECT * FROM room_entities ORDER BY name ASC")
    fun getAllRooms(): Flow<List<Room>> = getAll()
}
