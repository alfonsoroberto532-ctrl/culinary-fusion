package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Data class representing an Expense entity for hostal management.
 */
@Entity(tableName = "expense_entities")
data class Expense(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val description: String = "",
    val amount: Double = 0.0,
    val category: String = CATEGORY_GENERAL,
    val roomId: Long? = null,
    val date: Long = System.currentTimeMillis(),
    val notes: String = ""
) {
    companion object {
        const val CATEGORY_GENERAL = "GENERAL"
        const val CATEGORY_MAINTENANCE = "MAINTENANCE"
        const val CATEGORY_SUPPLIES = "SUPPLIES"
        const val CATEGORY_UTILITIES = "UTILITIES"
        const val CATEGORY_SALARIES = "SALARIES"
    }
}
