package com.example.data.repository

import com.example.varanova.data.dao.RoomDao
import com.example.varanova.data.model.RoomEntity

/**
 * Concrete implementation of offline-first caching repository for Rooms.
 */
class RoomOfflineRepository(
    private val roomDao: RoomDao
) {

    private val repositoryWrapper = OfflineRepositoryWrapper<RoomEntity, Long>(
        fetchFromLocal = { roomDao.getAllRooms() },
        fetchByIdLocal = { id -> roomDao.getRoomById(id) },
        saveToLocal = { room ->
            if (room.id == 0L) {
                roomDao.insertRoom(room)
            } else {
                roomDao.updateRoom(room)
                room.id
            }
        },
        deleteFromLocal = { room -> roomDao.deleteRoom(room) },
        clearLocal = { roomDao.clearRooms() }
    )

    val roomsStream = repositoryWrapper.getDataStream(CacheStrategy.OfflineFirst)

    suspend fun getRoomById(id: Long): Resource<RoomEntity> = repositoryWrapper.getById(id)

    suspend fun saveRoom(room: RoomEntity): Resource<Long> = repositoryWrapper.save(room)

    suspend fun deleteRoom(room: RoomEntity): Resource<Unit> = repositoryWrapper.delete(room)

    suspend fun clearAllRooms(): Resource<Unit> = repositoryWrapper.clearCache()
}
