package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Data class representing a Room entity for hostal management.
 */
@Entity(tableName = "room_entities")
data class Room(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String = "",
    val description: String = "",
    val capacity: Int = 1,
    val price: Double = 0.0,
    val status: String = ROOM_STATUS_AVAILABLE,
    val features: String = ""
) {
    companion object {
        const val ROOM_STATUS_AVAILABLE = "AVAILABLE"
        const val ROOM_STATUS_RESERVED = "RESERVED"
        const val ROOM_STATUS_OCCUPIED = "OCCUPIED"
        const val ROOM_STATUS_CLEANING_PENDING = "CLEANING_PENDING"
        const val ROOM_STATUS_CLEANING = "CLEANING"
        const val ROOM_STATUS_MAINTENANCE = "MAINTENANCE"
    }
}
