package com.example.data.repository

import com.example.data.dao.RoomDao
import com.example.data.model.Room
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.*

/**
 * Offline-first repository for managing [Room] entities.
 * Interacts directly with the [RoomDao] single source of truth and provides data as [StateFlow].
 */
class RoomRepository(
    private val roomDao: RoomDao,
    private val externalScope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) {

    /**
     * StateFlow emitting the list of all rooms ordered by name.
     * Guaranteed to hold cached state immediately upon subscription.
     */
    val roomsState: StateFlow<List<Room>> = roomDao.getAll()
        .stateIn(
            scope = externalScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allRooms: StateFlow<List<Room>> = roomsState

    suspend fun getRoomById(id: Long): Room? {
        return roomDao.getById(id)
    }

    suspend fun saveRoom(room: Room): Long {
        return if (room.id == 0L) {
            roomDao.insert(room)
        } else {
            roomDao.update(room)
            room.id
        }
    }

    suspend fun deleteRoom(room: Room) {
        roomDao.delete(room)
    }
}
