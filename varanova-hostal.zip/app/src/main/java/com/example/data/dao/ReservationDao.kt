package com.example.data.dao

import androidx.room.*
import com.example.data.model.Reservation
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for [com.example.data.model.Reservation].
 */
@Dao
interface ReservationDao {

    @Query("SELECT * FROM reservation_entities ORDER BY checkInDate DESC")
    fun getAll(): Flow<List<Reservation>>

    @Query("SELECT * FROM reservation_entities WHERE id = :id")
    suspend fun getById(id: Long): Reservation?

    @Query("SELECT * FROM reservation_entities WHERE roomId = :roomId")
    fun getByRoomId(roomId: Long): Flow<List<Reservation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reservation: Reservation): Long

    @Update
    suspend fun update(reservation: Reservation)

    @Delete
    suspend fun delete(reservation: Reservation)
}
