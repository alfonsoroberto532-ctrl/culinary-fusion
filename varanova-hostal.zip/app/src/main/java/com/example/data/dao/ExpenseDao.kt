package com.example.data.dao

import androidx.room.*
import com.example.data.model.Expense
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for [com.example.data.model.Expense].
 */
@Dao
interface ExpenseDao {

    @Query("SELECT * FROM expense_entities ORDER BY date DESC")
    fun getAll(): Flow<List<Expense>>

    @Query("SELECT * FROM expense_entities WHERE id = :id")
    suspend fun getById(id: Long): Expense?

    @Query("SELECT * FROM expense_entities WHERE roomId = :roomId ORDER BY date DESC")
    fun getByRoomId(roomId: Long): Flow<List<Expense>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(expense: Expense): Long

    @Update
    suspend fun update(expense: Expense)

    @Delete
    suspend fun delete(expense: Expense)

    @Query("DELETE FROM expense_entities")
    suspend fun clearAll()
}
