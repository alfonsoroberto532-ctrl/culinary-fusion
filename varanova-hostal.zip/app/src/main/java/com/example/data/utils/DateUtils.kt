package com.example.data.utils

import com.example.data.model.Reservation
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Utility functions for handling date formatting, calculations, and room availability logic across the app.
 */
object DateUtils {

    private val dateFormatter = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    private val dateTimeFormatter = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    private val monthFormatter = SimpleDateFormat("MMMM yyyy", Locale.getDefault())

    /**
     * Formats a timestamp (millis) to a standard date string (dd/MM/yyyy).
     */
    fun formatDate(timestamp: Long): String {
        if (timestamp <= 0) return "-"
        return dateFormatter.format(Date(timestamp))
    }

    /**
     * Formats a timestamp (millis) to a date & time string (dd/MM/yyyy HH:mm).
     */
    fun formatDateTime(timestamp: Long): String {
        if (timestamp <= 0) return "-"
        return dateTimeFormatter.format(Date(timestamp))
    }

    /**
     * Formats a timestamp (millis) to Month Year (e.g., "August 2026").
     */
    fun formatMonthYear(timestamp: Long): String {
        if (timestamp <= 0) return "-"
        return monthFormatter.format(Date(timestamp))
    }

    /**
     * Calculates the number of nights between check-in and check-out timestamps.
     */
    fun calculateNights(checkInDate: Long, checkOutDate: Long): Int {
        if (checkOutDate <= checkInDate) return 1
        val diffMillis = checkOutDate - checkInDate
        val nights = TimeUnit.MILLISECONDS.toDays(diffMillis).toInt()
        return if (nights > 0) nights else 1
    }

    /**
     * Determines whether a room is available during a given date range.
     */
    fun isRoomAvailable(
        roomId: Long,
        checkInDate: Long,
        checkOutDate: Long,
        activeReservations: List<Reservation>
    ): Boolean {
        return !ValidationUtils.hasReservationConflict(
            roomId = roomId,
            checkInDate = checkInDate,
            checkOutDate = checkOutDate,
            existingReservations = activeReservations
        )
    }

    /**
     * Formats double values to formatted currency string (e.g. "$ 120.00").
     */
    fun formatCurrency(amount: Double): String {
        return String.format(Locale.getDefault(), "$ %.2f", amount)
    }
}
