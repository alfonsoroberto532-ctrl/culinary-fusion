package com.example.data.repository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

/**
 * Generic Repository Pattern Wrapper for managing offline-first data caching strategies.
 * Encapsulates local Room DAO operations as the single source of truth (SSOT)
 * and provides robust offline persistence and caching behavior.
 */
class OfflineRepositoryWrapper<T : Any, ID : Any>(
    private val fetchFromLocal: () -> Flow<List<T>>,
    private val fetchByIdLocal: suspend (ID) -> T?,
    private val saveToLocal: suspend (T) -> ID,
    private val deleteFromLocal: suspend (T) -> Unit,
    private val clearLocal: (suspend () -> Unit)? = null,
    private val fetchFromRemote: (suspend () -> List<T>)? = null,
    private val saveToRemote: (suspend (T) -> Unit)? = null
) {

    /**
     * Emits data reactively from the local database according to the specified [CacheStrategy].
     */
    fun getDataStream(strategy: CacheStrategy = CacheStrategy.OfflineFirst): Flow<Resource<List<T>>> = flow {
        emit(Resource.Loading())

        when (strategy) {
            is CacheStrategy.OfflineFirst -> {
                fetchFromLocal()
                    .map { data -> Resource.Success(data, isFromCache = true) }
                    .catch { e -> emit(Resource.Error(e.localizedMessage ?: "Cache read error")) }
                    .collect { emit(it) }
            }
            is CacheStrategy.CacheAndRefresh -> {
                fetchFromLocal().collect { localData ->
                    emit(Resource.Loading(cachedData = localData))

                    if (fetchFromRemote != null) {
                        try {
                            val remoteData = fetchFromRemote.invoke()
                            remoteData.forEach { saveToLocal(it) }
                            emit(Resource.Success(remoteData, isFromCache = false))
                        } catch (e: Exception) {
                            emit(Resource.Error("Network fetch failed: ${e.localizedMessage}. Using cached data.", cachedData = localData))
                        }
                    } else {
                        emit(Resource.Success(localData, isFromCache = true))
                    }
                }
            }
            is CacheStrategy.OfflineWriteFirst -> {
                fetchFromLocal()
                    .map { data -> Resource.Success(data, isFromCache = true) }
                    .catch { e -> emit(Resource.Error(e.localizedMessage ?: "Cache read error")) }
                    .collect { emit(it) }
            }
        }
    }

    /**
     * Retrieves an item by ID locally, returning a [Resource].
     */
    suspend fun getById(id: ID): Resource<T> {
        val cached = fetchByIdLocal(id)
        return if (cached != null) {
            Resource.Success(cached, isFromCache = true)
        } else {
            Resource.Error("Item not found in local cache")
        }
    }

    /**
     * Saves an entity locally first (offline-first execution) and queues remote save if configured.
     */
    suspend fun save(item: T): Resource<ID> {
        return try {
            val localId = saveToLocal(item)
            if (saveToRemote != null) {
                try {
                    saveToRemote.invoke(item)
                } catch (_: Exception) {
                    // Cached locally, safe from remote sync failure
                }
            }
            Resource.Success(localId, isFromCache = true)
        } catch (e: Exception) {
            Resource.Error("Failed to save item locally: ${e.localizedMessage}")
        }
    }

    /**
     * Deletes an entity from local cache.
     */
    suspend fun delete(item: T): Resource<Unit> {
        return try {
            deleteFromLocal(item)
            Resource.Success(Unit, isFromCache = true)
        } catch (e: Exception) {
            Resource.Error("Failed to delete item from local storage: ${e.localizedMessage}")
        }
    }

    /**
     * Clears local cache.
     */
    suspend fun clearCache(): Resource<Unit> {
        return try {
            clearLocal?.invoke()
            Resource.Success(Unit, isFromCache = true)
        } catch (e: Exception) {
            Resource.Error("Failed to clear local cache: ${e.localizedMessage}")
        }
    }
}
