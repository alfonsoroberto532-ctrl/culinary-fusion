package com.example.data.repository

/**
 * Caching strategies for managing offline-first data synchronization and UI responsiveness.
 */
sealed class CacheStrategy {
    /**
     * Serve directly from local Room cache as the single source of truth (SSOT).
     * Guarantees fast, offline-first execution without network latency.
     */
    object OfflineFirst : CacheStrategy()

    /**
     * Serve from local cache immediately, while initiating a background refresh
     * if remote data sources are configured.
     */
    data class CacheAndRefresh(val forceRefresh: Boolean = false) : CacheStrategy()

    /**
     * Persist mutations to local cache immediately (optimistic UI), and queue for remote sync.
     */
    object OfflineWriteFirst : CacheStrategy()
}

/**
 * Encapsulates the state of data cached locally or fetched remotely.
 */
sealed class Resource<out T> {
    data class Success<out T>(val data: T, val isFromCache: Boolean = true) : Resource<T>()
    data class Loading<out T>(val cachedData: T? = null) : Resource<T>()
    data class Error<out T>(val message: String, val cachedData: T? = null) : Resource<T>()
}
