package com.example.data.utils

import com.example.data.model.Reservation
import com.example.varanova.data.model.ReservationEntity

/**
 * Utility class/object providing validation helper functions for checking reservation conflicts,
 * date overlaps, and data integrity before inserting or updating data.
 */
object ValidationUtils {

    /**
     * Checks if two date ranges [start1, end1) and [start2, end2) overlap.
     * Returns true if there is an intersection between the two intervals.
     */
    fun hasDateOverlap(
        start1: Long,
        end1: Long,
        start2: Long,
        end2: Long
    ): Boolean {
        if (start1 >= end1 || start2 >= end2) return false
        val maxStart = maxOf(start1, start2)
        val minEnd = minOf(end1, end2)
        return maxStart < minEnd
    }

    /**
     * Validates whether the given check-in and check-out timestamps form a valid date range.
     */
    fun isValidDateRange(checkInDate: Long, checkOutDate: Long): Boolean {
        return checkInDate > 0 && checkOutDate > checkInDate
    }

    /**
     * Checks if a proposed reservation time slot conflicts with any existing [Reservation]s in the same room.
     */
    fun hasReservationConflict(
        roomId: Long,
        checkInDate: Long,
        checkOutDate: Long,
        existingReservations: List<Reservation>,
        excludeReservationId: Long = 0L
    ): Boolean {
        if (!isValidDateRange(checkInDate, checkOutDate)) return true

        return existingReservations.any { res ->
            if (res.id == excludeReservationId) return@any false
            if (res.status == Reservation.STATUS_CANCELLED) return@any false
            if (res.roomId != roomId) return@any false

            hasDateOverlap(checkInDate, checkOutDate, res.checkInDate, res.checkOutDate)
        }
    }

    /**
     * Checks if a proposed reservation time slot conflicts with any existing [ReservationEntity]s in the same room.
     */
    fun hasEntityReservationConflict(
        roomId: Long,
        checkInDate: Long,
        checkOutDate: Long,
        existingReservations: List<ReservationEntity>,
        excludeReservationId: Long = 0L
    ): Boolean {
        if (!isValidDateRange(checkInDate, checkOutDate)) return true

        return existingReservations.any { res ->
            if (res.id == excludeReservationId) return@any false
            if (res.status == ReservationEntity.STATUS_CANCELLED) return@any false
            if (res.roomId != roomId) return@any false

            hasDateOverlap(checkInDate, checkOutDate, res.checkInDate, res.checkOutDate)
        }
    }

    /**
     * Validates input values for a reservation before database operations.
     */
    fun validateReservationData(
        roomId: Long,
        guestId: Long,
        checkInDate: Long,
        checkOutDate: Long,
        totalPrice: Double,
        advancePayment: Double = 0.0
    ): ValidationResult {
        if (roomId <= 0) {
            return ValidationResult.Error("Debe seleccionar una habitación válida.")
        }
        if (guestId <= 0) {
            return ValidationResult.Error("Debe seleccionar un huésped válido.")
        }
        if (!isValidDateRange(checkInDate, checkOutDate)) {
            return ValidationResult.Error("La fecha de salida debe ser posterior a la fecha de entrada.")
        }
        if (totalPrice < 0) {
            return ValidationResult.Error("El precio total no puede ser negativo.")
        }
        if (advancePayment < 0 || advancePayment > totalPrice) {
            return ValidationResult.Error("El adelanto no puede ser negativo ni mayor al precio total.")
        }
        return ValidationResult.Success
    }

    sealed class ValidationResult {
        object Success : ValidationResult()
        data class Error(val message: String) : ValidationResult()
    }
}
