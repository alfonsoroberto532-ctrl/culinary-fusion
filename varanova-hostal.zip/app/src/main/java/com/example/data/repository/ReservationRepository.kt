package com.example.data.repository

import com.example.data.dao.ReservationDao
import com.example.data.model.Reservation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.*

/**
 * Offline-first repository for managing [Reservation] entities.
 * Interacts directly with the [ReservationDao] single source of truth and provides data as [StateFlow].
 */
class ReservationRepository(
    private val reservationDao: ReservationDao,
    private val externalScope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) {

    /**
     * StateFlow emitting the list of all reservations ordered by check-in date descending.
     * Guaranteed to hold cached state immediately upon subscription.
     */
    val reservationsState: StateFlow<List<Reservation>> = reservationDao.getAll()
        .stateIn(
            scope = externalScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allReservations: StateFlow<List<Reservation>> = reservationsState

    suspend fun getReservationById(id: Long): Reservation? {
        return reservationDao.getById(id)
    }

    fun getReservationsForRoom(roomId: Long): Flow<List<Reservation>> {
        return reservationDao.getByRoomId(roomId)
    }

    suspend fun saveReservation(reservation: Reservation): Long {
        return if (reservation.id == 0L) {
            reservationDao.insert(reservation)
        } else {
            reservationDao.update(reservation)
            reservation.id
        }
    }

    suspend fun deleteReservation(reservation: Reservation) {
        reservationDao.delete(reservation)
    }
}
