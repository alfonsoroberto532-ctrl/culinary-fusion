package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Data class representing a Reservation entity for hostal management.
 * Contains guest information, booking dates, room relation, financial metrics, and status.
 */
@Entity(tableName = "reservation_entities")
data class Reservation(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    // Guest Info
    val guestId: Long = 0,
    val guestName: String = "",
    val guestPhone: String = "",
    val guestDocument: String = "",

    // Room Relation
    val roomId: Long = 0,
    val roomName: String = "",

    // Dates
    val checkInDate: Long = System.currentTimeMillis(),
    val checkOutDate: Long = System.currentTimeMillis() + 86400000L,

    // Financial Data
    val price: Double = 0.0,
    val advance: Double = 0.0,
    val balance: Double = 0.0,

    // Status & Extra
    val status: String = STATUS_CONFIRMED,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val STATUS_PENDING = "PENDING"
        const val STATUS_CONFIRMED = "CONFIRMED"
        const val STATUS_CHECKED_IN = "CHECKED_IN"
        const val STATUS_CHECKED_OUT = "CHECKED_OUT"
        const val STATUS_CANCELLED = "CANCELLED"
    }
}
