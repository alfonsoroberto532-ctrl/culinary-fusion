package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.Room as RoomBuilder
import com.example.data.dao.ExpenseDao
import com.example.data.dao.ReservationDao
import com.example.data.dao.RoomDao
import com.example.data.model.Expense
import com.example.data.model.Reservation
import com.example.data.model.Room
import com.example.varanova.data.model.*

/**
 * Abstract Room Database class defining the configuration and access to DAOs
 * for rooms, reservations, expenses, and other hostal management entities.
 */
@Database(
    entities = [
        Room::class,
        Reservation::class,
        Expense::class,
        RoomEntity::class,
        GuestEntity::class,
        ReservationEntity::class,
        PaymentEntity::class,
        ExpenseCategoryEntity::class,
        ExpenseEntity::class,
        SupplyItemEntity::class,
        InventoryMovementEntity::class,
        CleaningRecordEntity::class,
        MaintenanceRecordEntity::class,
        ExchangeRateEntity::class,
        AuditLogEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun roomDao(): RoomDao
    abstract fun reservationDao(): ReservationDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun hostalDao(): com.example.varanova.data.dao.HostalDao
    abstract fun varanovaRoomDao(): com.example.varanova.data.dao.RoomDao
    abstract fun suministroDao(): com.example.varanova.data.dao.SuministroDao

    companion object {
        const val DATABASE_NAME = "varanova_hostal_database"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = RoomBuilder.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                )
                    .addMigrations(*com.example.varanova.data.database.DatabaseMigrations.ALL_MIGRATIONS)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
