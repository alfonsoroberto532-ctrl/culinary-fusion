package com.example.varanova.utils

import com.example.varanova.data.model.ParsedReservationInput
import com.example.varanova.data.model.ParsedSupplyInput
import com.example.varanova.data.model.RoomEntity

object NaturalLanguageParser {

    /**
     * Parses natural language input for check-ins.
     * Examples:
     * - "Check in John Doe to room 101 for 3 nights"
     * - "Registrar Carlos Mendoza hab 202 por 2 noches $120"
     * - "Check-in Ana Gomez cuarto 105 4 noches"
     */
    fun parseCheckIn(input: String, availableRooms: List<RoomEntity>): ParsedReservationInput {
        val clean = input.trim()
        if (clean.isBlank()) return ParsedReservationInput()

        // Remove command verbs
        val textWithoutVerbs = clean.replace(
            Regex("^(check\\s*in|checkin|registrar|ingresar|reserva|reservar|entrada)\\s*", RegexOption.IGNORE_CASE),
            ""
        ).trim()

        // Match room (e.g., room 101, hab 202, cuarto 105, habitacion 3)
        var roomQuery = ""
        val roomRegex = Regex("(?:to\\s+room|room|hab|habitación|habitacion|cuarto)\\s*#?\\s*(\\d+|[a-zA-Z0-9]+)", RegexOption.IGNORE_CASE)
        val roomMatch = roomRegex.find(textWithoutVerbs)
        if (roomMatch != null) {
            roomQuery = roomMatch.groupValues[1]
        } else {
            // Check if any room name is directly mentioned
            availableRooms.find { r -> textWithoutVerbs.contains(r.name, ignoreCase = true) }?.let {
                roomQuery = it.name
            }
        }

        // Match nights (e.g., for 3 nights, 3 noches, 2 dias, 4 nights)
        var nights = 1
        val nightsRegex = Regex("(\\d+)\\s*(?:noche|noches|días|dias|night|nights)", RegexOption.IGNORE_CASE)
        val nightsMatch = nightsRegex.find(textWithoutVerbs)
        if (nightsMatch != null) {
            nights = nightsMatch.groupValues[1].toIntOrNull() ?: 1
        }

        // Match price/amount (e.g., $120, 150 usd, cost 80)
        var price: Double? = null
        val priceRegex = Regex("(?:\\$|usd|precio|costo)\\s*(\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE)
        val priceMatch = priceRegex.find(textWithoutVerbs)
        if (priceMatch != null) {
            price = priceMatch.groupValues[1].toDoubleOrNull()
        }

        // Extract guest name by stripping room, nights, price fragments
        var namePart = textWithoutVerbs
            .replace(roomRegex, "")
            .replace(nightsRegex, "")
            .replace(priceRegex, "")
            .replace(Regex("\\b(?:for|por|to|en|del|al)\\b", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        // Clean any leading punctuation or stray tokens
        namePart = namePart.trim(' ', ',', '.', '-', ':', ';')

        return ParsedReservationInput(
            guestName = if (namePart.isNotBlank()) namePart else "Huésped",
            roomQuery = roomQuery,
            nights = nights,
            estimatedPrice = price
        )
    }

    /**
     * Parses natural language input for supply restock or creation.
     * Examples:
     * - "Reabastecer 15 rollos de papel higiénico"
     * - "Jabón Líquido 10 litros"
     * - "Comprar 5 paquetes servilletas"
     */
    fun parseSupply(input: String): ParsedSupplyInput {
        val clean = input.trim()
        if (clean.isBlank()) return ParsedSupplyInput()

        val qtyRegex = Regex("(\\d+(?:\\.\\d+)?)\\s*(unidades|rollos|cajas|paquetes|litros|kg|botellas|bolsas)?", RegexOption.IGNORE_CASE)
        val match = qtyRegex.find(clean)
        var qty = 10.0
        var unit = "unidades"

        if (match != null) {
            qty = match.groupValues[1].toDoubleOrNull() ?: 10.0
            if (match.groupValues[2].isNotBlank()) {
                unit = match.groupValues[2].lowercase()
            }
        }

        val name = clean
            .replace(qtyRegex, "")
            .replace(Regex("^(reponer|comprar|agregar|añadir|reabastecer|stock|de)\\s*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\b(?:de|para|en)\\b", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        return ParsedSupplyInput(
            itemName = if (name.isNotBlank()) name else clean,
            quantity = qty,
            unit = unit
        )
    }
}
