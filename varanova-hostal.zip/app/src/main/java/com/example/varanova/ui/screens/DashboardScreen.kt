package com.example.varanova.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import com.example.varanova.data.model.ReservationEntity
import com.example.varanova.data.model.RoomEntity
import com.example.varanova.data.model.SmartDashboardAlert
import com.example.varanova.ui.components.*
import com.example.ui.theme.*
import com.example.varanova.ui.viewmodel.HostalViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: HostalViewModel,
    onNavigateTab: (String) -> Unit,
    onOpenQuickAction: (String) -> Unit
) {
    val rooms by viewModel.rooms.collectAsStateWithLifecycle()
    val finSummary by viewModel.financialSummary.collectAsStateWithLifecycle()
    val alerts by viewModel.smartAlerts.collectAsStateWithLifecycle()
    val reservations by viewModel.reservationsWithDetails.collectAsStateWithLifecycle()
    val lastBackupTimestamp by viewModel.lastBackupTimestamp.collectAsStateWithLifecycle()
    val context = androidx.compose.ui.platform.LocalContext.current

    var showQuickEntrySheet by remember { mutableStateOf(false) }

    val greetingText = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when {
            hour < 12 -> "Buenos días"
            hour < 19 -> "Buenas tardes"
            else -> "Buenas noches"
        }
    }

    val availableCount = rooms.count { it.status == RoomEntity.ROOM_STATUS_AVAILABLE }
    val occupiedCount = rooms.count { it.status == RoomEntity.ROOM_STATUS_OCCUPIED }
    val cleaningCount = rooms.count { it.status == RoomEntity.ROOM_STATUS_CLEANING_PENDING || it.status == RoomEntity.ROOM_STATUS_CLEANING }
    val reservedCount = rooms.count { it.status == RoomEntity.ROOM_STATUS_RESERVED }
    val maintenanceCount = rooms.count { it.status == RoomEntity.ROOM_STATUS_MAINTENANCE }

    val primarySmartAction by viewModel.primarySmartAction.collectAsStateWithLifecycle()
    val occupancyForecast by viewModel.occupancyForecast.collectAsStateWithLifecycle()

    val sdf = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        // --- GREETING & ASSISTANT BANNER ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = "$greetingText, Propietario",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "VaraNova Hostal • ${rooms.size} unidades registradas",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(Color.White.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SmartToy,
                                contentDescription = "Asistente",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "RESUMEN DE HOY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Status Chips
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        StatusChip("🟢 $availableCount Libres", Color(0xFF10B981)) { onNavigateTab("rooms") }
                        StatusChip("🔴 $occupiedCount Ocupadas", Color(0xFFEF4444)) { onNavigateTab("rooms") }
                        StatusChip("🟡 $cleaningCount Limpieza", Color(0xFFF59E0B)) { onNavigateTab("operations") }
                        StatusChip("🔵 $reservedCount Reservas", Color(0xFF3B82F6)) { onNavigateTab("reservations") }
                    }
                }
            }
        }

        primarySmartAction?.let { action ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.5.dp, TealPrimary),
                    modifier = Modifier.fillMaxWidth().testTag("primary_smart_action_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(TealPrimaryContainer, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = TealPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = action.title,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Surface(
                                color = StatusOccupied.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = action.badgeText,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StatusOccupied,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = action.description,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = {
                                val alert = com.example.varanova.data.model.SmartDashboardAlert(
                                    id = action.id,
                                    title = action.title,
                                    message = action.description,
                                    type = com.example.varanova.data.model.SmartDashboardAlert.AlertType.CRITICAL,
                                    iconName = action.iconName,
                                    targetTabRoute = "dashboard",
                                    actionType = action.actionType,
                                    actionLabel = action.actionLabel,
                                    entityId = action.entityId,
                                    secondaryAmount = action.amount,
                                    secondaryText = action.currency
                                )
                                viewModel.executeSmartAlertAction(alert)
                            },
                            modifier = Modifier.fillMaxWidth().height(44.dp).testTag("primary_smart_action_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = TealPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(action.actionLabel, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // --- 7-DAY OCCUPANCY FORECAST CARD ---
        if (occupancyForecast.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().testTag("occupancy_forecast_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = "📊 Ocupación vs Disponibilidad",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Estimación proactiva para los próximos 7 días",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = { viewModel.triggerDailyShiftSummary(context) },
                                modifier = Modifier
                                    .background(TealPrimaryContainer, CircleShape)
                                    .size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = "Resumen de Turno",
                                    tint = TealPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            occupancyForecast.forEach { day ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    if (day.isPeakDemand) {
                                        Surface(
                                            color = StatusOccupied,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = "🔥 PICO",
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                    }

                                    Text(
                                        text = "${day.occupancyPercentage.toInt()}%",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (day.isPeakDemand) StatusOccupied else MaterialTheme.colorScheme.onSurface
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Box(
                                        modifier = Modifier
                                            .width(18.dp)
                                            .height(60.dp)
                                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
                                        contentAlignment = Alignment.BottomCenter
                                    ) {
                                        val fillFraction = (day.occupancyPercentage / 100.0).coerceIn(0.1, 1.0).toFloat()
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .fillMaxHeight(fillFraction)
                                                .background(
                                                    if (day.isPeakDemand) StatusOccupied else TealPrimary,
                                                    RoundedCornerShape(8.dp)
                                                )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = day.dayName,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = day.dateLabel,
                                        fontSize = 9.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }


        // --- INTELLIGENT ALERTS BANNER ---
        if (alerts.isNotEmpty()) {
            item {
                SectionHeader(title = "Asistente Inteligente Varanova", subtitle = "${alerts.size} acciones recomendadas (1 toque)")
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(alerts) { alert ->
                        AlertCard(
                            alert = alert,
                            onClick = { onNavigateTab(alert.targetTabRoute) },
                            onActionClick = { viewModel.executeSmartAlertAction(alert) }
                        )
                    }
                }
            }
        }

        // --- VISUAL SYNC / BACKUP INDICATOR ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().testTag("sync_indicator_card")
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(
                                    if (lastBackupTimestamp > 0) StatusAvailable.copy(alpha = 0.15f) else StatusOccupied.copy(alpha = 0.15f),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (lastBackupTimestamp > 0) Icons.Default.CloudDone else Icons.Default.CloudOff,
                                contentDescription = null,
                                tint = if (lastBackupTimestamp > 0) StatusAvailable else StatusOccupied,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Respaldo y Seguridad BD",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (lastBackupTimestamp > 0)
                                    "Último respaldo: ${sdf.format(Date(lastBackupTimestamp))}"
                                else
                                    "Sin respaldo local guardado",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = { viewModel.backupToGoogleDrive(context) },
                            modifier = Modifier
                                .background(Color(0xFF107C41).copy(alpha = 0.15f), CircleShape)
                                .size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = "Guardar en Drive",
                                tint = Color(0xFF107C41),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Button(
                            onClick = { viewModel.generateBackupJson(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = TealPrimary),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sync,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Respaldar", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // --- FINANCIAL QUICK STATS ---
        item {
            SectionHeader(title = "Dinero y Estado Financiero", actionText = "Ver Finanzas") { onNavigateTab("finances") }
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                StatCard(
                    title = "Cobrado hoy",
                    value = "$${finSummary.collectedToday.toInt()}",
                    subtitle = "Moneda Base",
                    icon = Icons.Default.AccountBalanceWallet,
                    containerColor = StatusAvailable.copy(alpha = 0.15f),
                    contentColor = StatusAvailable,
                    modifier = Modifier.weight(1f),
                    testTag = "stat_collected_today"
                )
                StatCard(
                    title = "Pendiente cobrar",
                    value = "$${finSummary.pendingToCollect.toInt()}",
                    subtitle = "Saldos activos",
                    icon = Icons.Default.AttachMoney,
                    containerColor = AmberSecondaryContainer,
                    contentColor = AmberSecondary,
                    modifier = Modifier.weight(1f),
                    testTag = "stat_pending_collect"
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                StatCard(
                    title = "Gastos de hoy",
                    value = "$${finSummary.expensesToday.toInt()}",
                    subtitle = "Insumos y operacion",
                    icon = Icons.Default.ReceiptLong,
                    containerColor = StatusOccupied.copy(alpha = 0.15f),
                    contentColor = StatusOccupied,
                    modifier = Modifier.weight(1f),
                    testTag = "stat_expenses_today"
                )
                StatCard(
                    title = "Ganancia estimada",
                    value = "$${finSummary.estimatedProfitToday.toInt()}",
                    subtitle = "Cobrado - Gastos",
                    icon = Icons.Default.TrendingUp,
                    containerColor = TealPrimaryContainer,
                    contentColor = TealPrimary,
                    modifier = Modifier.weight(1f),
                    testTag = "stat_profit_today"
                )
            }
        }

        // --- QUICK ACTIONS GRID ---
        item {
            SectionHeader(title = "Acciones Rápidas", subtitle = "Registra en un solo paso")
            val actions = listOf(
                ActionItem("Nueva Reserva", Icons.Default.AddCircle, StatusReserved, "add_reservation"),
                ActionItem("Nuevo Huésped", Icons.Default.PersonAdd, TealPrimary, "add_guest"),
                ActionItem("Registrar Pago", Icons.Default.Payment, StatusAvailable, "add_payment"),
                ActionItem("Registrar Gasto", Icons.Default.MoneyOff, StatusOccupied, "add_expense"),
                ActionItem("Comprar Insumo", Icons.Default.AddShoppingCart, StatusCleaning, "buy_supply"),
                ActionItem("Consumo Insumo", Icons.Default.RemoveShoppingCart, StatusMaintenance, "consume_supply"),
                ActionItem("Mantenimiento", Icons.Default.Build, AmberSecondary, "report_maintenance"),
                ActionItem("Limpieza", Icons.Default.CleaningServices, StatusAvailable, "complete_cleaning")
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (row in actions.chunked(4)) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        row.forEach { act ->
                            QuickActionButton(
                                label = act.title,
                                icon = act.icon,
                                color = act.color,
                                onClick = { onOpenQuickAction(act.key) },
                                modifier = Modifier.weight(1f),
                                testTag = "quick_action_${act.key}"
                            )
                        }
                    }
                }
            }
        }

        // --- UPCOMING MOVEMENTS ---
        item {
            SectionHeader(title = "Próximos Movimientos", actionText = "Ver Calendario") { onNavigateTab("reservations") }
            val activeRes = reservations.filter { it.reservation.status != ReservationEntity.STATUS_CANCELLED }

            if (activeRes.isEmpty()) {
                EmptyState(
                    title = "Sin Entradas/Salidas Próximas",
                    message = "No hay entradas ni salidas próximas registradas en tu hostal.",
                    icon = Icons.Default.EventNote,
                    actionLabel = "Crear Reserva",
                    onActionClick = { onNavigateTab("reservations") },
                    testTag = "dashboard_empty_movements"
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    activeRes.take(3).forEach { res ->
                        MovementCard(res, sdf)
                    }
                }
            }
        }
    }

        // Floating Action Button for Quick Entry in 2 Taps
        FloatingActionButton(
            onClick = { showQuickEntrySheet = true },
            containerColor = TealPrimary,
            contentColor = Color.White,
            shape = CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("quick_entry_fab")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.FlashOn, contentDescription = "Registro Rápido")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Registro Rápido", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }

    if (showQuickEntrySheet) {
        QuickEntryBottomSheet(
            viewModel = viewModel,
            onDismiss = { showQuickEntrySheet = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickEntryBottomSheet(
    viewModel: HostalViewModel,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Reserva, 1 = Mantenimiento
    val rooms by viewModel.rooms.collectAsStateWithLifecycle()
    val context = androidx.compose.ui.platform.LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .navigationBarsPadding()
        ) {
            Text(
                text = "⚡ Registro Rápido (2 toques)",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Registra una nueva reserva o mantenimiento de forma rápida",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = TealPrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("📝 Nueva Reserva", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("🛠️ Mantenimiento", fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (selectedTab == 0) {
                // Quick Reservation Form
                var naturalLanguageText by remember { mutableStateOf("") }
                var guestName by remember { mutableStateOf("") }
                var selectedRoom by remember { mutableStateOf(rooms.firstOrNull()) }
                var nightsText by remember { mutableStateOf("1") }
                var expandedRoomDropdown by remember { mutableStateOf(false) }

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = naturalLanguageText,
                        onValueChange = { text ->
                            naturalLanguageText = text
                            val parsed = viewModel.parseReservationText(text, rooms)
                            if (parsed.guestName.isNotBlank()) guestName = parsed.guestName
                            if (parsed.roomQuery.isNotBlank()) {
                                rooms.find { it.name.contains(parsed.roomQuery, ignoreCase = true) }?.let {
                                    selectedRoom = it
                                }
                            }
                            if (parsed.nights > 0) nightsText = parsed.nights.toString()
                        },
                        label = { Text("⚡ Entrada en Lenguaje Natural (Autocompletado)") },
                        placeholder = { Text("Ej: Carlos Rodriguez hab 102 por 3 noches") },
                        leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = TealPrimary) },
                        modifier = Modifier.fillMaxWidth().testTag("quick_res_nl_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = TealPrimary)
                    )

                    OutlinedTextField(
                        value = guestName,
                        onValueChange = { guestName = it },
                        label = { Text("Nombre del Huésped") },
                        modifier = Modifier.fillMaxWidth().testTag("quick_res_guest_name"),
                        singleLine = true
                    )

                    ExposedDropdownMenuBox(
                        expanded = expandedRoomDropdown,
                        onExpandedChange = { expandedRoomDropdown = it }
                    ) {
                        OutlinedTextField(
                            value = selectedRoom?.let { "${it.name} ($${it.pricePerNight.toInt()}/noche)" } ?: "Seleccionar Habitación",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Habitación") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedRoomDropdown) },
                            modifier = Modifier.menuAnchor().fillMaxWidth().testTag("quick_res_room_select")
                        )

                        ExposedDropdownMenu(
                            expanded = expandedRoomDropdown,
                            onDismissRequest = { expandedRoomDropdown = false }
                        ) {
                            rooms.forEach { room ->
                                DropdownMenuItem(
                                    text = { Text("${room.name} • $${room.pricePerNight.toInt()}/noche (${room.status})") },
                                    onClick = {
                                        selectedRoom = room
                                        expandedRoomDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = nightsText,
                        onValueChange = { if (it.all { char -> char.isDigit() }) nightsText = it },
                        label = { Text("Número de noches") },
                        modifier = Modifier.fillMaxWidth().testTag("quick_res_nights"),
                        singleLine = true
                    )

                    val nights = nightsText.toIntOrNull() ?: 1
                    val totalPrice = (selectedRoom?.pricePerNight ?: 30.0) * nights

                    Surface(
                        color = TealPrimaryContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total estimado:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("$${totalPrice.toInt()} USD", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TealPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (guestName.isBlank()) {
                                android.widget.Toast.makeText(context, "Ingrese el nombre del huésped", android.widget.Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val room = selectedRoom ?: rooms.firstOrNull()
                            if (room == null) {
                                android.widget.Toast.makeText(context, "No hay habitaciones disponibles", android.widget.Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val now = System.currentTimeMillis()
                            val checkOut = now + (nights * 86400000L)

                            coroutineScope.launch {
                                val guestId = viewModel.saveGuestAndGetId(
                                    com.example.varanova.data.model.GuestEntity(
                                        name = guestName,
                                        createdAt = now
                                    )
                                )
                                viewModel.saveReservation(
                                    com.example.varanova.data.model.ReservationEntity(
                                        guestId = guestId,
                                        roomId = room.id,
                                        checkInDate = now,
                                        checkOutDate = checkOut,
                                        guestCount = 1,
                                        pricePerNight = room.pricePerNight,
                                        totalPrice = totalPrice,
                                        advancePayment = 0.0,
                                        currency = room.currency,
                                        status = com.example.varanova.data.model.ReservationEntity.STATUS_CONFIRMED,
                                        notes = "Reserva rápida creada en 2 toques"
                                    ),
                                    onSuccess = { onDismiss() }
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("quick_res_submit_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = TealPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Crear Reserva Rápida", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                // Quick Maintenance Form
                var selectedRoom by remember { mutableStateOf(rooms.firstOrNull()) }
                var issueText by remember { mutableStateOf("") }
                var priorityText by remember { mutableStateOf("Media") }
                var expandedRoomDropdown by remember { mutableStateOf(false) }

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ExposedDropdownMenuBox(
                        expanded = expandedRoomDropdown,
                        onExpandedChange = { expandedRoomDropdown = it }
                    ) {
                        OutlinedTextField(
                            value = selectedRoom?.name ?: "Seleccionar Habitación",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Habitación con incidencia") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedRoomDropdown) },
                            modifier = Modifier.menuAnchor().fillMaxWidth().testTag("quick_maint_room_select")
                        )

                        ExposedDropdownMenu(
                            expanded = expandedRoomDropdown,
                            onDismissRequest = { expandedRoomDropdown = false }
                        ) {
                            rooms.forEach { room ->
                                DropdownMenuItem(
                                    text = { Text(room.name) },
                                    onClick = {
                                        selectedRoom = room
                                        expandedRoomDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = issueText,
                        onValueChange = { issueText = it },
                        label = { Text("Descripción del problema") },
                        modifier = Modifier.fillMaxWidth().testTag("quick_maint_issue_input"),
                        singleLine = true
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Baja", "Media", "Alta", "Urgente").forEach { p ->
                            FilterChip(
                                selected = priorityText == p,
                                onClick = { priorityText = p },
                                label = { Text(p, fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (issueText.isBlank()) {
                                android.widget.Toast.makeText(context, "Describa el problema", android.widget.Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val room = selectedRoom ?: rooms.firstOrNull()
                            if (room == null) return@Button

                            viewModel.reportMaintenance(
                                roomId = room.id,
                                issue = issueText,
                                priority = priorityText,
                                cost = 0.0,
                                technician = null,
                                notes = "Reportado vía acceso rápido"
                            )
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("quick_maint_submit_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = AmberSecondary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Registrar Mantenimiento", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatusChip(label: String, color: Color, onClick: () -> Unit) {
    Surface(
        color = Color.White.copy(alpha = 0.2f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun AlertCard(
    alert: SmartDashboardAlert,
    onClick: () -> Unit,
    onActionClick: () -> Unit
) {
    val bgColor = when (alert.type) {
        SmartDashboardAlert.AlertType.CRITICAL -> StatusOccupied.copy(alpha = 0.15f)
        SmartDashboardAlert.AlertType.WARNING -> AmberSecondaryContainer
        SmartDashboardAlert.AlertType.INFO -> StatusReserved.copy(alpha = 0.15f)
        SmartDashboardAlert.AlertType.SUCCESS -> StatusAvailable.copy(alpha = 0.15f)
    }
    val contentColor = when (alert.type) {
        SmartDashboardAlert.AlertType.CRITICAL -> StatusOccupied
        SmartDashboardAlert.AlertType.WARNING -> AmberSecondary
        SmartDashboardAlert.AlertType.INFO -> StatusReserved
        SmartDashboardAlert.AlertType.SUCCESS -> StatusAvailable
    }

    Card(
        modifier = Modifier
            .width(280.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when (alert.iconName) {
                            "inventory" -> Icons.Default.Inventory2
                            "build" -> Icons.Default.Build
                            "attach_money" -> Icons.Default.AttachMoney
                            else -> Icons.Default.Warning
                        },
                        contentDescription = null,
                        tint = contentColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = alert.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = alert.message,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            if (alert.actionLabel != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onActionClick,
                    colors = ButtonDefaults.buttonColors(containerColor = contentColor),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text(
                        text = alert.actionLabel,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun MovementCard(res: com.example.varanova.data.model.ReservationWithDetails, sdf: SimpleDateFormat) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(TealPrimaryContainer, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MeetingRoom,
                        contentDescription = null,
                        tint = TealPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = res.guest.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${res.room.name} • ${res.nights} noches",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${sdf.format(Date(res.reservation.checkInDate))} → ${sdf.format(Date(res.reservation.checkOutDate))}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TealPrimary
                )
                StatusBadge(status = res.reservation.status)
            }
        }
    }
}

private data class ActionItem(
    val title: String,
    val icon: ImageVector,
    val color: Color,
    val key: String
)
