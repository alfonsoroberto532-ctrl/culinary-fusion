package com.example.varanova.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.varanova.data.database.AppDatabase
import com.example.varanova.data.model.*
import com.example.varanova.data.repository.HostalRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class HostalViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getDatabase(application).hostalDao()
    private val repository: HostalRepository = HostalRepository(dao)

    private val _lastBackupTimestamp = MutableStateFlow(
        com.example.varanova.data.utils.BackupManager.getLastBackupTimestamp(application)
    )
    val lastBackupTimestamp: StateFlow<Long> = _lastBackupTimestamp.asStateFlow()

    private val _integrityReport = MutableStateFlow<com.example.varanova.data.utils.IntegrityReport?>(null)
    val integrityReport: StateFlow<com.example.varanova.data.utils.IntegrityReport?> = _integrityReport.asStateFlow()

    init {
        // Auto-seed if database is completely empty on launch
        viewModelScope.launch {
            val rooms = repository.allRooms.first()
            if (rooms.isEmpty()) {
                repository.seedDemoData()
            }
            // Initial integrity validation
            runIntegrityCheckSilent()
        }
    }

    // State Flows
    val rooms: StateFlow<List<RoomEntity>> = repository.allRooms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val guests: StateFlow<List<GuestEntity>> = repository.allGuests
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reservationsWithDetails: StateFlow<List<ReservationWithDetails>> = repository.reservationsWithDetails
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<PaymentEntity>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<ExpenseEntity>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val supplyItems: StateFlow<List<SupplyItemEntity>> = repository.allSupplyItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val inventoryMovements: StateFlow<List<InventoryMovementEntity>> = repository.allInventoryMovements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cleaningRecords: StateFlow<List<CleaningRecordEntity>> = repository.allCleaningRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val maintenanceRecords: StateFlow<List<MaintenanceRecordEntity>> = repository.allMaintenanceRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val exchangeRates: StateFlow<List<ExchangeRateEntity>> = repository.allExchangeRates
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.allAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Toast / SnackBar Notification State
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    fun clearUserMessage() {
        _userMessage.value = null
    }

    // --- DASHBOARD CALCULATED METRICS ---
    val smartAlerts: StateFlow<List<SmartDashboardAlert>> = combine(
        supplyItems,
        maintenanceRecords,
        reservationsWithDetails,
        rooms
    ) { supplies, maintenance, reservations, roomsList ->
        val alerts = mutableListOf<SmartDashboardAlert>()

        // Low stock alerts
        supplies.filter { it.currentStock <= it.minStock }.forEach { item ->
            alerts.add(
                SmartDashboardAlert(
                    id = "stock_${item.id}",
                    title = "Stock bajo de insumos",
                    message = "⚠️ ${item.name}: quedan ${item.currentStock.toInt()} ${item.unit} (mínimo ${item.minStock.toInt()}).",
                    type = SmartDashboardAlert.AlertType.WARNING,
                    iconName = "inventory",
                    targetTabRoute = "supplies",
                    actionType = SmartDashboardAlert.ActionType.QUICK_RESTOCK_SUPPLY,
                    actionLabel = "⚡ Reponer (+10)",
                    entityId = item.id
                )
            )
        }

        // Pending maintenance
        maintenance.filter { it.status != MaintenanceRecordEntity.STATUS_RESOLVED }.forEach { maint ->
            val room = roomsList.find { it.id == maint.roomId }
            alerts.add(
                SmartDashboardAlert(
                    id = "maint_${maint.id}",
                    title = "Mantenimiento pendiente",
                    message = "⚠️ ${room?.name ?: "Habitación"}: ${maint.issue}",
                    type = SmartDashboardAlert.AlertType.CRITICAL,
                    iconName = "build",
                    targetTabRoute = "operations",
                    actionType = SmartDashboardAlert.ActionType.QUICK_RESOLVE_MAINTENANCE,
                    actionLabel = "⚡ Marcar Resuelto",
                    entityId = maint.id
                )
            )
        }

        // Pending payments from active/past guests
        reservations.filter { it.pendingBalance > 0 && it.reservation.status != ReservationEntity.STATUS_CANCELLED }.forEach { res ->
            alerts.add(
                SmartDashboardAlert(
                    id = "pay_${res.reservation.id}",
                    title = "Saldo pendiente de cobro",
                    message = "💰 ${res.guest.name} debe $${res.pendingBalance.toInt()} ${res.reservation.currency} (${res.room.name})",
                    type = SmartDashboardAlert.AlertType.INFO,
                    iconName = "attach_money",
                    targetTabRoute = "finances",
                    actionType = SmartDashboardAlert.ActionType.QUICK_COLLECT_PAYMENT,
                    actionLabel = "⚡ Cobrar $${res.pendingBalance.toInt()}",
                    entityId = res.reservation.id,
                    secondaryAmount = res.pendingBalance,
                    secondaryText = res.reservation.currency
                )
            )
        }

        // Pending cleaning
        roomsList.filter { it.status == RoomEntity.ROOM_STATUS_CLEANING_PENDING }.forEach { room ->
            alerts.add(
                SmartDashboardAlert(
                    id = "clean_${room.id}",
                    title = "Limpieza requerida",
                    message = "🧹 ${room.name} pendiente de limpieza",
                    type = SmartDashboardAlert.AlertType.WARNING,
                    iconName = "cleaning_services",
                    targetTabRoute = "operations",
                    actionType = SmartDashboardAlert.ActionType.QUICK_CLEAN_ROOM,
                    actionLabel = "⚡ Marcar Limpia",
                    entityId = room.id
                )
            )
        }

        alerts
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun executeSmartAlertAction(alert: SmartDashboardAlert) {
        viewModelScope.launch {
            when (alert.actionType) {
                SmartDashboardAlert.ActionType.QUICK_CLEAN_ROOM -> {
                    alert.entityId?.let { roomId ->
                        completeCleaning(roomId, "Insumos básicos", "Limpieza completada en 1 toque")
                        _userMessage.value = "✨ Habitación marcada como limpia y disponible"
                    }
                }
                SmartDashboardAlert.ActionType.QUICK_COLLECT_PAYMENT -> {
                    alert.entityId?.let { reservationId ->
                        val currency = if (alert.secondaryText.isNotBlank()) alert.secondaryText else "USD"
                        addPayment(reservationId, alert.secondaryAmount, currency, "Efectivo", "Cobro completo 1 toque")
                        _userMessage.value = "💰 Cobro de $${alert.secondaryAmount.toInt()} $currency registrado"
                    }
                }
                SmartDashboardAlert.ActionType.QUICK_RESOLVE_MAINTENANCE -> {
                    alert.entityId?.let { maintId ->
                        val maint = maintenanceRecords.value.find { it.id == maintId }
                        if (maint != null) {
                            resolveMaintenance(maint)
                            _userMessage.value = "🛠️ Incidencia resuelta"
                        }
                    }
                }
                SmartDashboardAlert.ActionType.QUICK_RESTOCK_SUPPLY -> {
                    alert.entityId?.let { supplyId ->
                        recordInventoryMovement(supplyId, "ENTRADA", 10.0, null, "Reposición rápida 1 toque (+10)")
                        _userMessage.value = "📦 Stock reimpulsado (+10 unidades)"
                    }
                }
                else -> {}
            }
        }
    }

    // --- PRIMARY SINGLE SMART ACTION ---
    val primarySmartAction: StateFlow<PrimarySmartAction?> = combine(
        rooms,
        reservationsWithDetails,
        maintenanceRecords,
        supplyItems
    ) { roomList, resList, maintList, suppliesList ->
        val todayStart = getTodayStartMillis()
        val todayEnd = todayStart + 86400000L

        // Priority 1: Dirty rooms with upcoming check-in TODAY
        val dirtyRooms = roomList.filter { it.status == RoomEntity.ROOM_STATUS_CLEANING_PENDING }
        val dirtyRoomWithCheckInToday = dirtyRooms.find { room ->
            resList.any { res -> res.room.id == room.id && res.reservation.checkInDate in todayStart until todayEnd }
        } ?: dirtyRooms.firstOrNull()

        if (dirtyRoomWithCheckInToday != null) {
            val checkInGuest = resList.find { it.room.id == dirtyRoomWithCheckInToday.id && it.reservation.checkInDate in todayStart until todayEnd }?.guest?.name
            val desc = if (checkInGuest != null) {
                "🧹 Limpiar ${dirtyRoomWithCheckInToday.name} para Check-In de $checkInGuest hoy"
            } else {
                "🧹 Limpiar ${dirtyRoomWithCheckInToday.name} para tenerla lista y disponible"
            }
            return@combine PrimarySmartAction(
                id = "p_clean_${dirtyRoomWithCheckInToday.id}",
                title = "Acción Prioritaria Principal",
                description = desc,
                badgeText = "🔴 URGENTE - TURNO ACTUAL",
                actionLabel = "⚡ Marcar Limpia (1 Toque)",
                iconName = "cleaning_services",
                actionType = SmartDashboardAlert.ActionType.QUICK_CLEAN_ROOM,
                entityId = dirtyRoomWithCheckInToday.id
            )
        }

        // Priority 2: Critical Maintenance
        val criticalMaint = maintList.find { it.status != MaintenanceRecordEntity.STATUS_RESOLVED && it.priority in listOf("Alta", "Urgente") }
        if (criticalMaint != null) {
            val roomName = roomList.find { it.id == criticalMaint.roomId }?.name ?: "Habitación"
            return@combine PrimarySmartAction(
                id = "p_maint_${criticalMaint.id}",
                title = "Acción Prioritaria Principal",
                description = "🛠️ Resolver '${criticalMaint.issue}' en $roomName",
                badgeText = "⚠️ MANTENIMIENTO CRÍTICO",
                actionLabel = "⚡ Resolver Incidencia (1 Toque)",
                iconName = "build",
                actionType = SmartDashboardAlert.ActionType.QUICK_RESOLVE_MAINTENANCE,
                entityId = criticalMaint.id
            )
        }

        // Priority 3: Low Inventory Stock
        val criticalSupply = suppliesList.find { it.currentStock <= it.minStock }
        if (criticalSupply != null) {
            return@combine PrimarySmartAction(
                id = "p_stock_${criticalSupply.id}",
                title = "Acción Prioritaria Principal",
                description = "📦 Reponer ${criticalSupply.name} (quedan solo ${criticalSupply.currentStock.toInt()} ${criticalSupply.unit})",
                badgeText = "📦 STOCK CRÍTICO",
                actionLabel = "⚡ Reponer +10 (1 Toque)",
                iconName = "inventory",
                actionType = SmartDashboardAlert.ActionType.QUICK_RESTOCK_SUPPLY,
                entityId = criticalSupply.id
            )
        }

        // Priority 4: Outstanding Payment from Guest
        val pendingRes = resList.find { it.pendingBalance > 0 && it.reservation.status != ReservationEntity.STATUS_CANCELLED }
        if (pendingRes != null) {
            return@combine PrimarySmartAction(
                id = "p_pay_${pendingRes.reservation.id}",
                title = "Acción Prioritaria Principal",
                description = "💰 Registrar cobro de $${pendingRes.pendingBalance.toInt()} ${pendingRes.reservation.currency} de ${pendingRes.guest.name}",
                badgeText = "💵 COBRO PENDIENTE",
                actionLabel = "⚡ Cobrar $${pendingRes.pendingBalance.toInt()} (1 Toque)",
                iconName = "attach_money",
                actionType = SmartDashboardAlert.ActionType.QUICK_COLLECT_PAYMENT,
                entityId = pendingRes.reservation.id,
                amount = pendingRes.pendingBalance,
                currency = pendingRes.reservation.currency
            )
        }

        // Priority 5: Operations normal
        PrimarySmartAction(
            id = "p_ok",
            title = "Acción Prioritaria Principal",
            description = "✨ ¡Operación impecable! Habitaciones limpias, pagos al día e inventario suficiente.",
            badgeText = "🟢 OPERACIÓN OPTIMA",
            actionLabel = "👍 Todo al Día",
            iconName = "check_circle",
            actionType = SmartDashboardAlert.ActionType.QUICK_CLEAN_ROOM,
            entityId = null
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // --- 7-DAY OCCUPANCY FORECAST ---
    val occupancyForecast: StateFlow<List<OccupancyDayForecast>> = combine(
        rooms,
        reservationsWithDetails
    ) { roomList, resList ->
        val totalRooms = if (roomList.isNotEmpty()) roomList.size else 1
        val cal = Calendar.getInstance()
        val dayNames = arrayOf("Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb")
        val dateSdf = SimpleDateFormat("dd/MM", Locale.getDefault())

        val forecast = mutableListOf<OccupancyDayForecast>()

        for (i in 0 until 7) {
            val dayCal = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, i) }
            val dayStart = (dayCal.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val dayEnd = dayStart + 86400000L - 1L

            val occupiedCount = resList.filter { res ->
                res.reservation.status != ReservationEntity.STATUS_CANCELLED &&
                res.reservation.checkInDate <= dayEnd &&
                res.reservation.checkOutDate >= dayStart
            }.map { it.room.id }.distinct().size

            val clampedOccupied = occupiedCount.coerceAtMost(totalRooms)
            val pct = (clampedOccupied.toDouble() / totalRooms) * 100.0

            val dayLabel = if (i == 0) "Hoy" else dayNames[dayCal.get(Calendar.DAY_OF_WEEK) - 1]

            forecast.add(
                OccupancyDayForecast(
                    dayName = dayLabel,
                    dateLabel = dateSdf.format(dayCal.time),
                    timestamp = dayStart,
                    occupiedRooms = clampedOccupied,
                    totalRooms = totalRooms,
                    occupancyPercentage = pct,
                    isPeakDemand = pct >= 70.0
                )
            )
        }
        forecast
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- TASK SMART-ROUTER (TOP 3 PRIORITIES FOR SHIFT) ---
    val top3PriorityTasks: StateFlow<List<com.example.varanova.utils.TaskPriorityItem>> = combine(
        rooms,
        reservationsWithDetails,
        maintenanceRecords,
        supplyItems,
        inventoryMovements
    ) { roomList, resList, maintList, suppliesList, movementsList ->
        com.example.varanova.utils.TaskSmartRouter.evaluateTop3Tasks(
            rooms = roomList,
            reservations = resList,
            maintenanceRecords = maintList,
            supplies = suppliesList,
            movements = movementsList
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- NATURAL LANGUAGE PARSERS ---
    fun parseReservationText(input: String, availableRooms: List<RoomEntity>): ParsedReservationInput {
        return com.example.varanova.utils.NaturalLanguageParser.parseCheckIn(input, availableRooms)
    }

    fun parseSupplyText(input: String): ParsedSupplyInput {
        return com.example.varanova.utils.NaturalLanguageParser.parseSupply(input)
    }

    fun triggerDailyShiftSummary(context: Context) {
        com.example.varanova.utils.NotificationHelper.sendDailyShiftSummaryNotification(
            context = context,
            reservations = reservationsWithDetails.value,
            maintenanceTasks = maintenanceRecords.value,
            supplies = supplyItems.value,
            rooms = rooms.value
        )
        _userMessage.value = "🌅 Notificación de Resumen de Turno enviada"
    }


    val financialSummary: StateFlow<FinancialSummary> = combine(
        payments,
        expenses,
        reservationsWithDetails
    ) { paymentList, expenseList, reservationList ->
        val todayStart = getTodayStartMillis()

        val collectedToday = paymentList
            .filter { it.date >= todayStart }
            .sumOf { it.amount }

        val expensesToday = expenseList
            .filter { it.date >= todayStart }
            .sumOf { it.amount }

        val totalPending = reservationList
            .filter { it.reservation.status != ReservationEntity.STATUS_CANCELLED }
            .sumOf { it.pendingBalance }

        val totalIncome = paymentList.sumOf { it.amount }
        val totalExp = expenseList.sumOf { it.amount }

        FinancialSummary(
            collectedToday = collectedToday,
            pendingToCollect = totalPending,
            expensesToday = expensesToday,
            estimatedProfitToday = collectedToday - expensesToday,
            totalIncomePeriod = totalIncome,
            totalExpensesPeriod = totalExp,
            netProfitPeriod = totalIncome - totalExp
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        FinancialSummary(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    )

    // Room Profitability breakdown
    val roomProfitabilityList: StateFlow<List<RoomProfitability>> = combine(
        rooms,
        reservationsWithDetails,
        expenses
    ) { roomList, resList, expenseList ->
        roomList.map { room ->
            val roomRes = resList.filter { it.room.id == room.id && it.reservation.status != ReservationEntity.STATUS_CANCELLED }
            val roomIncome = roomRes.sumOf { it.totalPaid }
            val roomExpenses = expenseList.filter { it.roomId == room.id }.sumOf { it.amount }
            val totalNights = roomRes.sumOf { it.nights }

            RoomProfitability(
                room = room,
                totalIncome = roomIncome,
                totalExpenses = roomExpenses,
                netProfit = roomIncome - roomExpenses,
                occupancyRatePercent = if (totalNights > 0) (totalNights.toDouble() / 30.0) * 100.0 else 0.0,
                totalReservationsCount = roomRes.size,
                totalNightsOccupied = totalNights
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- ACTIONS & MUTATIONS ---

    // Rooms
    fun saveRoom(room: RoomEntity) {
        viewModelScope.launch {
            repository.saveRoom(room)
            _userMessage.value = "Habitación '${room.name}' guardada exitosamente"
        }
    }

    fun deleteRoom(room: RoomEntity) {
        viewModelScope.launch {
            repository.deleteRoom(room)
            _userMessage.value = "Habitación '${room.name}' eliminada"
        }
    }

    fun updateRoomStatus(room: RoomEntity, newStatus: String) {
        viewModelScope.launch {
            repository.saveRoom(room.copy(status = newStatus))
            _userMessage.value = "Estado de ${room.name} actualizado a $newStatus"
        }
    }

    // Guests
    fun saveGuest(guest: GuestEntity) {
        viewModelScope.launch {
            repository.saveGuest(guest)
            _userMessage.value = "Huésped '${guest.name}' guardado"
        }
    }

    suspend fun saveGuestAndGetId(guest: GuestEntity): Long {
        val id = repository.saveGuest(guest)
        _userMessage.value = "Huésped '${guest.name}' guardado"
        return id
    }

    // Reservations
    fun saveReservation(
        reservation: ReservationEntity,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val room = rooms.value.find { it.id == reservation.roomId }
            if (room?.status == RoomEntity.ROOM_STATUS_MAINTENANCE) {
                onError("❌ La habitación '${room.name}' está en Mantenimiento y no puede ser reservada.")
                return@launch
            }

            if (reservation.checkOutDate <= reservation.checkInDate) {
                onError("La fecha de salida debe ser posterior a la fecha de entrada.")
                return@launch
            }

            val conflict = repository.checkDateConflict(
                roomId = reservation.roomId,
                checkInDate = reservation.checkInDate,
                checkOutDate = reservation.checkOutDate,
                excludeReservationId = reservation.id
            )

            if (conflict) {
                onError("❌ Conflicto de fechas: La habitación ya tiene una reserva en ese rango de fechas.")
                return@launch
            }

            repository.saveReservation(reservation)
            _userMessage.value = "Reserva guardada con éxito"
            onSuccess()
        }
    }

    fun deleteReservation(reservation: ReservationEntity) {
        viewModelScope.launch {
            repository.deleteReservation(reservation)
            _userMessage.value = "Reserva eliminada"
        }
    }

    // Payments
    fun addPayment(reservationId: Long, amount: Double, currency: String, paymentType: String, notes: String) {
        viewModelScope.launch {
            if (amount <= 0) {
                _userMessage.value = "Ingrese un monto válido"
                return@launch
            }
            repository.addPayment(
                PaymentEntity(
                    reservationId = reservationId,
                    amount = amount,
                    currency = currency,
                    paymentType = paymentType,
                    notes = notes
                )
            )
            _userMessage.value = "Pago de $amount $currency registrado"
        }
    }

    // Expenses
    fun addExpense(
        categoryName: String,
        description: String,
        amount: Double,
        currency: String = "USD",
        roomId: Long? = null,
        reservationId: Long? = null,
        supplier: String? = null
    ) {
        viewModelScope.launch {
            if (amount <= 0) {
                _userMessage.value = "Monto de gasto inválido"
                return@launch
            }
            repository.addExpense(
                ExpenseEntity(
                    categoryName = categoryName,
                    description = description,
                    amount = amount,
                    currency = currency,
                    roomId = roomId,
                    reservationId = reservationId,
                    supplier = supplier
                )
            )
            _userMessage.value = "Gasto de $amount $currency registrado"
        }
    }

    // Supply & Inventory
    fun saveSupplyItem(item: SupplyItemEntity) {
        viewModelScope.launch {
            repository.saveSupplyItem(item)
            _userMessage.value = "Insumo '${item.name}' guardado"
        }
    }

    fun recordInventoryMovement(
        supplyItemId: Long,
        type: String,
        quantity: Double,
        roomId: Long? = null,
        notes: String = ""
    ) {
        viewModelScope.launch {
            if (quantity <= 0) {
                _userMessage.value = "Ingrese una cantidad válida"
                return@launch
            }
            repository.recordInventoryMovement(
                supplyItemId = supplyItemId,
                movementType = type,
                quantity = quantity,
                roomId = roomId,
                notes = notes
            )
            _userMessage.value = "Movimiento de inventario registrado ($type $quantity)"
        }
    }

    // Cleaning & Maintenance
    fun completeCleaning(roomId: Long, productsUsed: String, notes: String) {
        viewModelScope.launch {
            repository.recordCleaning(roomId, productsUsed, notes)
            _userMessage.value = "Limpieza completada. Habitación disponible."
        }
    }

    fun reportMaintenance(
        roomId: Long,
        issue: String,
        priority: String,
        cost: Double,
        technician: String?,
        notes: String
    ) {
        viewModelScope.launch {
            repository.recordMaintenance(
                roomId = roomId,
                issue = issue,
                priority = priority,
                cost = cost,
                technician = technician,
                notes = notes,
                blockRoom = true
            )
            _userMessage.value = "Incidencia de mantenimiento registrada"
        }
    }

    fun resolveMaintenance(record: MaintenanceRecordEntity) {
        viewModelScope.launch {
            repository.resolveMaintenance(record)
            _userMessage.value = "Mantenimiento resuelto."
        }
    }

    // Exchange Rates
    fun updateExchangeRate(currencyCode: String, rate: Double) {
        viewModelScope.launch {
            repository.setExchangeRate(currencyCode, rate)
            _userMessage.value = "Tipo de cambio para $currencyCode actualizado a $rate"
        }
    }

    // Demo Data Seeding & Reset
    fun loadDemoData() {
        seedDemoData()
    }

    // CSV Report Export
    fun exportReportCsv(context: Context) {
        viewModelScope.launch {
            try {
                val resList = reservationsWithDetails.value
                val expList = expenses.value
                val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

                val csvContent = StringBuilder()
                csvContent.append("REPORTES DE VARANOVA HOSTAL\n")
                csvContent.append("Fecha de reporte: ${sdf.format(Date())}\n\n")

                csvContent.append("RESERVAS Y COBROS\n")
                csvContent.append("ID,Huesped,Habitacion,Entrada,Salida,Total,Pagado,Pendiente,Estado\n")
                resList.forEach { r ->
                    csvContent.append("${r.reservation.id},\"${r.guest.name}\",\"${r.room.name}\",${sdf.format(Date(r.reservation.checkInDate))},${sdf.format(Date(r.reservation.checkOutDate))},${r.reservation.totalPrice},${r.totalPaid},${r.pendingBalance},${r.reservation.status}\n")
                }

                csvContent.append("\nGASTOS\n")
                csvContent.append("Fecha,Categoria,Descripcion,Importe,Moneda\n")
                expList.forEach { e ->
                    csvContent.append("${sdf.format(Date(e.date))},\"${e.categoryName}\",\"${e.description}\",${e.amount},${e.currency}\n")
                }

                val cacheDir = context.cacheDir
                val file = File(cacheDir, "VaraNova_Reporte_${System.currentTimeMillis()}.csv")
                file.writeText(csvContent.toString())

                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(intent, "Compartir Reporte VaraNova Hostal")
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(chooser)

                _userMessage.value = "Reporte exportado en formato CSV"
            } catch (e: Exception) {
                _userMessage.value = "Error al exportar reporte: ${e.localizedMessage}"
            }
        }
    }

    // Database Integrity Check
    fun runDatabaseIntegrityCheck() {
        viewModelScope.launch {
            try {
                val report = com.example.varanova.data.utils.DatabaseIntegrityChecker.validateAndFixDatabase(dao)
                _integrityReport.value = report
                _userMessage.value = "Diagnóstico completado: ${report.issuesFoundCount} problemas hallados, ${report.issuesFixedCount} corregidos."
            } catch (e: Exception) {
                _userMessage.value = "Error en diagnóstico de BD: ${e.localizedMessage}"
            }
        }
    }

    private suspend fun runIntegrityCheckSilent() {
        try {
            val report = com.example.varanova.data.utils.DatabaseIntegrityChecker.validateAndFixDatabase(dao)
            _integrityReport.value = report
        } catch (_: Exception) {}
    }

    // Backup & Restore
    fun generateBackupJson(context: Context, shareAfter: Boolean = false) {
        viewModelScope.launch {
            try {
                val (file, _) = com.example.varanova.data.utils.BackupManager.generateBackupJson(context, dao)
                val ts = System.currentTimeMillis()
                _lastBackupTimestamp.value = ts
                _userMessage.value = "Copia de seguridad guardada con éxito en ${file.name}"

                if (shareAfter) {
                    com.example.varanova.data.utils.BackupManager.shareBackupFile(context, file)
                }
            } catch (e: Exception) {
                _userMessage.value = "Error al crear backup: ${e.localizedMessage}"
            }
        }
    }

    fun backupToGoogleDrive(context: Context) {
        viewModelScope.launch {
            try {
                val (file, _) = com.example.varanova.data.utils.BackupManager.generateBackupJson(context, dao)
                val ts = System.currentTimeMillis()
                _lastBackupTimestamp.value = ts
                _userMessage.value = "Abriendo Google Drive para guardar copia..."
                com.example.varanova.data.utils.BackupManager.shareToGoogleDrive(context, file)
            } catch (e: Exception) {
                _userMessage.value = "Error al guardar en Google Drive: ${e.localizedMessage}"
            }
        }
    }

    fun restoreBackupJson(context: Context, jsonText: String) {
        viewModelScope.launch {
            try {
                val success = com.example.varanova.data.utils.BackupManager.restoreBackupFromJson(context, dao, jsonText)
                if (success) {
                    _lastBackupTimestamp.value = System.currentTimeMillis()
                    _userMessage.value = "Base de datos restaurada correctamente desde el archivo de copia."
                } else {
                    _userMessage.value = "El archivo JSON no tiene un formato válido para VaraNova Hostal."
                }
            } catch (e: Exception) {
                _userMessage.value = "Error al restaurar copia: ${e.localizedMessage}"
            }
        }
    }

    fun seedDemoData() {
        viewModelScope.launch {
            try {
                repository.seedDemoData()
                _lastBackupTimestamp.value = System.currentTimeMillis()
                com.example.varanova.data.utils.BackupManager.setLastBackupTimestamp(getApplication(), System.currentTimeMillis())
                _userMessage.value = "Datos de prueba Casa Nova cargados con éxito."
            } catch (e: Exception) {
                _userMessage.value = "Error al cargar datos demo: ${e.localizedMessage}"
            }
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            try {
                repository.clearAllData()
                _userMessage.value = "Todos los datos locales han sido borrados."
            } catch (e: Exception) {
                _userMessage.value = "Error al borrar datos: ${e.localizedMessage}"
            }
        }
    }

    private fun getTodayStartMillis(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
