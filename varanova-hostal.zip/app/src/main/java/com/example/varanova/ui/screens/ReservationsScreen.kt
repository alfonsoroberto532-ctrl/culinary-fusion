package com.example.varanova.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.varanova.data.model.GuestEntity
import com.example.varanova.data.model.ReservationEntity
import com.example.varanova.data.model.ReservationWithDetails
import com.example.varanova.data.model.RoomEntity
import com.example.varanova.ui.components.SectionHeader
import com.example.varanova.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.varanova.ui.viewmodel.HostalViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReservationsScreen(
    viewModel: HostalViewModel,
    initialOpenCreate: Boolean = false
) {
    val coroutineScope = rememberCoroutineScope()
    val reservations by viewModel.reservationsWithDetails.collectAsStateWithLifecycle()
    val rooms by viewModel.rooms.collectAsStateWithLifecycle()
    val guests by viewModel.guests.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Lista, 1: Calendario
    var searchQuery by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(initialOpenCreate) }
    var selectedResForDetail by remember { mutableStateOf<ReservationWithDetails?>(null) }
    var resToDeleteConfirm by remember { mutableStateOf<ReservationWithDetails?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val filteredReservations = remember(reservations, searchQuery) {
        if (searchQuery.isBlank()) {
            reservations
        } else {
            val q = searchQuery.trim().lowercase(Locale.getDefault())
            reservations.filter { res ->
                res.guest.name.lowercase(Locale.getDefault()).contains(q) ||
                        res.room.name.lowercase(Locale.getDefault()).contains(q) ||
                        res.room.id.toString() == q ||
                        res.reservation.id.toString() == q
            }
        }
    }

    val sdf = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    errorMessage = null
                    showCreateDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = "Nueva Reserva") },
                text = { Text("Nueva Reserva", fontWeight = FontWeight.Bold) },
                containerColor = TealPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_reservation")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            SectionHeader(
                title = "Calendario y Reservas",
                subtitle = "${reservations.size} reservas gestionadas"
            )

            // Tabs Header
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text("Lista de Reservas", fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("Calendario Visual", fontWeight = FontWeight.SemiBold) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (selectedTabIndex == 0) {
                // LIST VIEW WITH SEARCH
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .testTag("input_search_reservations"),
                    placeholder = { Text("Buscar por nombre de huésped o habitación...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Buscar") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Limpiar")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TealPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )

                if (filteredReservations.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.SearchOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (searchQuery.isNotBlank()) "Sin resultados para \"$searchQuery\"" else "No hay reservas registradas.",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = { showCreateDialog = true }) {
                                Text("Crear Nueva Reserva")
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        items(filteredReservations) { res ->
                            ReservationCard(
                                res = res,
                                sdf = sdf,
                                onClick = { selectedResForDetail = res }
                            )
                        }
                    }
                }
            } else {
                // CALENDAR VISUAL VIEW
                VisualCalendarView(rooms = rooms, reservations = reservations, sdf = sdf) { res ->
                    selectedResForDetail = res
                }
            }
        }
    }

    // CREATE RESERVATION DIALOG
    if (showCreateDialog) {
        CreateReservationDialog(
            rooms = rooms,
            guests = guests,
            errorMessage = errorMessage,
            onDismiss = { showCreateDialog = false },
            onSave = { res, newGuestName, newGuestPhone ->
                coroutineScope.launch {
                    var guestId = res.guestId
                    if (guestId == 0L && newGuestName.isNotBlank()) {
                        guestId = viewModel.saveGuestAndGetId(GuestEntity(name = newGuestName, phone = newGuestPhone))
                    }

                    if (guestId == 0L) {
                        errorMessage = "Seleccione o ingrese el nombre del huésped"
                        return@launch
                    }

                    val finalRes = res.copy(guestId = guestId)
                    viewModel.saveReservation(
                        reservation = finalRes,
                        onSuccess = {
                            showCreateDialog = false
                        },
                        onError = { err ->
                            errorMessage = err
                        }
                    )
                }
            }
        )
    }

    // RESERVATION DETAIL SHEET / DIALOG
    selectedResForDetail?.let { res ->
        ReservationDetailDialog(
            resWithDetails = res,
            sdf = sdf,
            onDismiss = { selectedResForDetail = null },
            onAddPayment = { amount, currency, type, notes ->
                viewModel.addPayment(res.reservation.id, amount, currency, type, notes)
                selectedResForDetail = null
            },
            onDelete = {
                resToDeleteConfirm = res
            },
            onUpdateStatus = { newStatus ->
                viewModel.saveReservation(res.reservation.copy(status = newStatus))
                selectedResForDetail = null
            }
        )
    }

    // CONFIRM DELETE DIALOG
    resToDeleteConfirm?.let { resToDelete ->
        AlertDialog(
            onDismissRequest = { resToDeleteConfirm = null },
            title = { Text("Confirmar Eliminación", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "¿Estás seguro de que deseas eliminar permanentemente la reserva de " +
                            "${resToDelete.guest.name} (${resToDelete.room.name})? Esta acción no se puede deshacer.",
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteReservation(resToDelete.reservation)
                        resToDeleteConfirm = null
                        selectedResForDetail = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusOccupied),
                    modifier = Modifier.testTag("confirm_delete_reservation_btn")
                ) {
                    Text("Eliminar Reserva", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { resToDeleteConfirm = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
private fun ReservationCard(
    res: ReservationWithDetails,
    sdf: SimpleDateFormat,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(TealPrimaryContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = TealPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = res.guest.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "🚪 ${res.room.name}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = TealPrimary
                        )
                    }
                }
                StatusBadge(status = res.reservation.status)
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Event, contentDescription = null, tint = TealPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("FECHAS Y ESTANCIA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Login, contentDescription = "Check-in", tint = StatusAvailable, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(sdf.format(Date(res.reservation.checkInDate)), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(" ➔ ", fontSize = 12.sp, color = Color.Gray)
                        Icon(Icons.Default.Logout, contentDescription = "Check-out", tint = StatusOccupied, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(sdf.format(Date(res.reservation.checkOutDate)), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Text("${res.nights} noches • $${res.reservation.pricePerNight.toInt()}/noche", fontSize = 11.sp, color = Color.Gray)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountBalance, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("FINANZAS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("Total: $${res.reservation.totalPrice.toInt()} ${res.reservation.currency}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    if (res.pendingBalance > 0) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = StatusOccupied, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("Debe: $${res.pendingBalance.toInt()} ${res.reservation.currency}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StatusOccupied)
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusAvailable, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("Pagado", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StatusAvailable)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VisualCalendarView(
    rooms: List<RoomEntity>,
    reservations: List<ReservationWithDetails>,
    sdf: SimpleDateFormat,
    onSelectRes: (ReservationWithDetails) -> Unit
) {
    val scrollState = rememberScrollState()

    // Calculate days for the timeline (Next 14 days)
    val calendarDays = remember {
        val list = mutableListOf<Long>()
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)

        for (i in 0..14) {
            list.add(cal.timeInMillis)
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        list
    }

    val dayFormat = remember { SimpleDateFormat("EEE dd", Locale.getDefault()) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Ocupación Visual por Habitación",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.horizontalScroll(scrollState)) {
                Column {
                    // Header Row with Dates
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .width(120.dp)
                                .padding(8.dp)
                        ) {
                            Text("Habitación", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        calendarDays.forEach { dayMillis ->
                            Box(
                                modifier = Modifier
                                    .width(70.dp)
                                    .border(0.5.dp, MaterialTheme.colorScheme.surfaceVariant)
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = dayFormat.format(Date(dayMillis)),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Room Rows
                    rooms.forEach { room ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.border(0.5.dp, MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(120.dp)
                                    .padding(8.dp)
                            ) {
                                Text(room.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }

                            calendarDays.forEach { dayMillis ->
                                val dayEnd = dayMillis + 86400000L
                                val matchingRes = reservations.find { res ->
                                    res.room.id == room.id &&
                                            res.reservation.status != ReservationEntity.STATUS_CANCELLED &&
                                            maxOf(res.reservation.checkInDate, dayMillis) < minOf(res.reservation.checkOutDate, dayEnd)
                                }

                                Box(
                                    modifier = Modifier
                                        .width(70.dp)
                                        .height(44.dp)
                                        .border(0.5.dp, MaterialTheme.colorScheme.surfaceVariant)
                                        .background(
                                            if (matchingRes != null) StatusReserved.copy(alpha = 0.25f)
                                            else Color.Transparent
                                        )
                                        .clickable(enabled = matchingRes != null) {
                                            matchingRes?.let { onSelectRes(it) }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (matchingRes != null) {
                                        Text(
                                            text = matchingRes.guest.name.take(6),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = StatusReserved
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CreateReservationDialog(
    rooms: List<RoomEntity>,
    guests: List<GuestEntity>,
    errorMessage: String?,
    onDismiss: () -> Unit,
    onSave: (ReservationEntity, String, String) -> Unit
) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance()

    var selectedRoomId by remember { mutableLongStateOf(rooms.firstOrNull()?.id ?: 0L) }
    var selectedGuestId by remember { mutableLongStateOf(guests.firstOrNull()?.id ?: 0L) }
    var newGuestName by remember { mutableStateOf("") }
    var newGuestPhone by remember { mutableStateOf("") }

    var checkInMillis by remember { mutableLongStateOf(calendar.timeInMillis) }
    var checkOutMillis by remember { mutableLongStateOf(calendar.timeInMillis + (3 * 86400000L)) }

    val selectedRoom = rooms.find { it.id == selectedRoomId }
    var pricePerNight by remember(selectedRoomId) { mutableDoubleStateOf(selectedRoom?.pricePerNight ?: 40.0) }
    var advancePayment by remember { mutableDoubleStateOf(0.0) }
    var currency by remember { mutableStateOf("USD") }
    var notes by remember { mutableStateOf("") }

    val nights = remember(checkInMillis, checkOutMillis) {
        val diff = checkOutMillis - checkInMillis
        val days = (diff / 86400000L).toInt()
        if (days > 0) days else 1
    }

    val totalPrice = nights * pricePerNight
    val pendingBalance = if (totalPrice > advancePayment) totalPrice - advancePayment else 0.0

    val sdf = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva Reserva", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (errorMessage != null) {
                    item {
                        Surface(
                            color = StatusOccupied.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = errorMessage,
                                color = StatusOccupied,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }

                item {
                    Text("Habitación o Casa", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    DropdownMenuBox(
                        options = rooms.map { "${it.name} ($${it.pricePerNight.toInt()}/noche)" },
                        selectedIndex = rooms.indexOfFirst { it.id == selectedRoomId }.coerceAtLeast(0),
                        onSelect = { idx -> selectedRoomId = rooms[idx].id }
                    )
                }

                item {
                    Text("Huésped", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    if (guests.isNotEmpty()) {
                        DropdownMenuBox(
                            options = listOf("➕ Crear Nuevo Huésped") + guests.map { "${it.name} (${it.phone})" },
                            selectedIndex = if (selectedGuestId == 0L) 0 else guests.indexOfFirst { it.id == selectedGuestId } + 1,
                            onSelect = { idx ->
                                selectedGuestId = if (idx == 0) 0L else guests[idx - 1].id
                            }
                        )
                    }

                    if (selectedGuestId == 0L) {
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = newGuestName,
                            onValueChange = { newGuestName = it },
                            label = { Text("Nombre del Huésped") },
                            modifier = Modifier.fillMaxWidth().testTag("input_guest_name")
                        )
                        OutlinedTextField(
                            value = newGuestPhone,
                            onValueChange = { newGuestPhone = it },
                            label = { Text("Teléfono de contacto") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val c = Calendar.getInstance()
                                c.timeInMillis = checkInMillis
                                DatePickerDialog(context, { _, y, m, d ->
                                    val sel = Calendar.getInstance()
                                    sel.set(y, m, d)
                                    checkInMillis = sel.timeInMillis
                                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Entrada: ${sdf.format(Date(checkInMillis))}", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                val c = Calendar.getInstance()
                                c.timeInMillis = checkOutMillis
                                DatePickerDialog(context, { _, y, m, d ->
                                    val sel = Calendar.getInstance()
                                    sel.set(y, m, d)
                                    checkOutMillis = sel.timeInMillis
                                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Salida: ${sdf.format(Date(checkOutMillis))}", fontSize = 11.sp)
                        }
                    }
                }

                item {
                    Card(colors = CardDefaults.cardColors(containerColor = TealPrimaryContainer)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("🌙 $nights noches calculadas", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TealPrimary)
                            Text("Total Alojamiento: $$totalPrice $currency", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TealPrimary)
                            Text("Saldo Pendiente: $$pendingBalance $currency", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = StatusOccupied)
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = pricePerNight.toString(),
                        onValueChange = { pricePerNight = it.toDoubleOrNull() ?: pricePerNight },
                        label = { Text("Precio por Noche ($)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = advancePayment.toString(),
                        onValueChange = { advancePayment = it.toDoubleOrNull() ?: 0.0 },
                        label = { Text("Adelanto Recibido ($)") },
                        modifier = Modifier.fillMaxWidth().testTag("input_advance_payment")
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notas u observaciones") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val res = ReservationEntity(
                        guestId = selectedGuestId,
                        roomId = selectedRoomId,
                        checkInDate = checkInMillis,
                        checkOutDate = checkOutMillis,
                        pricePerNight = pricePerNight,
                        totalPrice = totalPrice,
                        advancePayment = advancePayment,
                        currency = currency,
                        notes = notes
                    )
                    onSave(res, newGuestName, newGuestPhone)
                },
                modifier = Modifier.testTag("save_reservation_btn")
            ) {
                Text("Guardar Reserva")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
private fun ReservationDetailDialog(
    resWithDetails: ReservationWithDetails,
    sdf: SimpleDateFormat,
    onDismiss: () -> Unit,
    onAddPayment: (Double, String, String, String) -> Unit,
    onDelete: () -> Unit,
    onUpdateStatus: (String) -> Unit
) {
    var showPaymentInput by remember { mutableStateOf(false) }
    var payAmount by remember { mutableStateOf("") }
    var payType by remember { mutableStateOf("Pago Parcial") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Reserva #${resWithDetails.reservation.id}", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.weight(1f))
                StatusBadge(status = resWithDetails.reservation.status)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("👤 Huésped: ${resWithDetails.guest.name}", fontWeight = FontWeight.Bold)
                Text("🚪 Habitación: ${resWithDetails.room.name}", fontWeight = FontWeight.SemiBold)
                Text("📅 Fechas: ${sdf.format(Date(resWithDetails.reservation.checkInDate))} ➔ ${sdf.format(Date(resWithDetails.reservation.checkOutDate))}")
                Text("🌙 Noches: ${resWithDetails.nights}")

                Divider()

                Text("💰 ESTADO FINANCIERO", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TealPrimary)
                Text("Total Reserva: $${resWithDetails.reservation.totalPrice} ${resWithDetails.reservation.currency}")
                Text("Total Cobrado: $${resWithDetails.totalPaid} ${resWithDetails.reservation.currency}", color = StatusAvailable)
                Text("Saldo Pendiente: $${resWithDetails.pendingBalance} ${resWithDetails.reservation.currency}", fontWeight = FontWeight.Bold, color = if (resWithDetails.pendingBalance > 0) StatusOccupied else StatusAvailable)

                Divider()

                Text("HISTORIAL DE PAGOS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                if (resWithDetails.payments.isEmpty()) {
                    Text("No hay pagos registrados.", fontSize = 11.sp, color = Color.Gray)
                } else {
                    resWithDetails.payments.forEach { pay ->
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("${pay.paymentType}: $${pay.amount} ${pay.currency}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(sdf.format(Date(pay.date)), fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }

                if (showPaymentInput) {
                    OutlinedTextField(
                        value = payAmount,
                        onValueChange = { payAmount = it },
                        label = { Text("Monto a cobrar ($)") },
                        modifier = Modifier.fillMaxWidth().testTag("input_payment_amount")
                    )
                    Button(
                        onClick = {
                            val amt = payAmount.toDoubleOrNull() ?: 0.0
                            if (amt > 0) {
                                onAddPayment(amt, resWithDetails.reservation.currency, payType, "Pago desde detalle")
                                showPaymentInput = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("confirm_add_payment")
                    ) {
                        Text("Confirmar Pago")
                    }
                } else if (resWithDetails.pendingBalance > 0) {
                    Button(
                        onClick = { showPaymentInput = true },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                        modifier = Modifier.fillMaxWidth().testTag("btn_add_payment")
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Registrar Pago")
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { onUpdateStatus(ReservationEntity.STATUS_CHECKED_IN) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Entrada", fontSize = 10.sp)
                    }
                    OutlinedButton(
                        onClick = { onUpdateStatus(ReservationEntity.STATUS_CHECKED_OUT) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Salida", fontSize = 10.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cerrar") }
        },
        dismissButton = {
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = StatusOccupied)
            }
        }
    )
}

@Composable
private fun DropdownMenuBox(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(options.getOrElse(selectedIndex) { "Seleccionar" })
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEachIndexed { idx, item ->
                DropdownMenuItem(
                    text = { Text(item) },
                    onClick = {
                        onSelect(idx)
                        expanded = false
                    }
                )
            }
        }
    }
}
