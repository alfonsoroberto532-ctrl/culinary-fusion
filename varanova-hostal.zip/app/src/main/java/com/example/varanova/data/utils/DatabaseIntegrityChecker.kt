package com.example.varanova.data.utils

import com.example.varanova.data.dao.HostalDao
import com.example.varanova.data.model.AuditLogEntity
import com.example.varanova.data.model.ReservationEntity
import com.example.varanova.data.model.RoomEntity
import kotlinx.coroutines.flow.first

data class IntegrityReport(
    val isValid: Boolean,
    val issuesFoundCount: Int,
    val issuesFixedCount: Int,
    val details: List<String>,
    val timestamp: Long = System.currentTimeMillis()
)

object DatabaseIntegrityChecker {

    suspend fun validateAndFixDatabase(dao: HostalDao): IntegrityReport {
        val details = mutableListOf<String>()
        var issuesFound = 0
        var issuesFixed = 0

        val rooms = dao.getAllRooms().first()
        val reservations = dao.getAllReservations().first()
        val payments = dao.getAllPayments().first()
        val expenses = dao.getAllExpenses().first()
        val supplies = dao.getAllSupplyItems().first()

        val roomIds = rooms.map { it.id }.toSet()
        val resMap = reservations.associateBy { it.id }

        // 1. Check for orphaned payments
        payments.forEach { pay ->
            if (!resMap.containsKey(pay.reservationId)) {
                issuesFound++
                details.add("⚠️ Pago #${pay.id} ($${pay.amount}) hace referencia a una reserva inexistente #${pay.reservationId}.")
            }
        }

        // 2. Check for invalid reservation date ranges
        reservations.forEach { res ->
            if (res.checkOutDate <= res.checkInDate && res.status != ReservationEntity.STATUS_CANCELLED) {
                issuesFound++
                details.add("❌ Reserva #${res.id}: La fecha de salida es anterior o igual a la de entrada.")
            }
            if (!roomIds.contains(res.roomId)) {
                issuesFound++
                details.add("⚠️ Reserva #${res.id} está asignada a una habitación borrada (ID ${res.roomId}).")
            }
        }

        // 3. Check for overlapping reservations on the same room
        val activeResByRoom = reservations
            .filter { it.status == ReservationEntity.STATUS_CONFIRMED || it.status == ReservationEntity.STATUS_CHECKED_IN }
            .groupBy { it.roomId }

        activeResByRoom.forEach { (roomId, resList) ->
            for (i in resList.indices) {
                for (j in i + 1 until resList.size) {
                    val r1 = resList[i]
                    val r2 = resList[j]
                    val overlap = (r1.checkInDate < r2.checkOutDate && r1.checkOutDate > r2.checkInDate)
                    if (overlap) {
                        issuesFound++
                        val roomName = rooms.find { it.id == roomId }?.name ?: "ID $roomId"
                        details.add("🚨 Solapamiento de fechas en '$roomName': Reserva #${r1.id} y Reserva #${r2.id}.")
                    }
                }
            }
        }

        // 4. Check Room Status consistency
        rooms.forEach { room ->
            val checkedInRes = reservations.find {
                it.roomId == room.id && it.status == ReservationEntity.STATUS_CHECKED_IN
            }
            if (checkedInRes != null && room.status == RoomEntity.ROOM_STATUS_MAINTENANCE) {
                issuesFound++
                details.add("⚠️ Habitación '${room.name}' está en MANTENIMIENTO pero tiene un huésped registrado (Reserva #${checkedInRes.id}).")
            } else if (checkedInRes != null && room.status == RoomEntity.ROOM_STATUS_AVAILABLE) {
                // Auto-fix status to OCCUPIED
                issuesFound++
                dao.updateRoom(room.copy(status = RoomEntity.ROOM_STATUS_OCCUPIED))
                issuesFixed++
                details.add("🔧 Corregido: Estado de '${room.name}' actualizado de DISPONIBLE a OCUPADA (Reserva #${checkedInRes.id}).")
            }
        }

        // 5. Negative stock or amounts check
        supplies.forEach { supply ->
            if (supply.currentStock < 0) {
                issuesFound++
                dao.updateSupplyItem(supply.copy(currentStock = 0.0))
                issuesFixed++
                details.add("🔧 Corregido: Stock negativo en '${supply.name}' reseteado a 0.0.")
            }
        }

        expenses.forEach { exp ->
            if (exp.amount < 0) {
                issuesFound++
                details.add("⚠️ Gasto #${exp.id} tiene un monto negativo ($${exp.amount}).")
            }
        }

        if (issuesFound == 0) {
            details.add("✅ Integridad de base de datos verificada. No se encontraron incoherencias.")
        }

        // Log audit entry
        dao.insertAuditLog(
            AuditLogEntity(
                entityType = "INTEGRITY_CHECK",
                entityId = 0,
                action = "AUDIT",
                details = "Diagnóstico completado: $issuesFound problemas hallados, $issuesFixed corregidos automáticamente."
            )
        )

        return IntegrityReport(
            isValid = (issuesFound == 0 || issuesFound == issuesFixed),
            issuesFoundCount = issuesFound,
            issuesFixedCount = issuesFixed,
            details = details
        )
    }
}
