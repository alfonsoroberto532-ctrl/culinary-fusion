package com.example.varanova.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.varanova.data.model.CleaningRecordEntity
import com.example.varanova.data.model.MaintenanceRecordEntity
import com.example.varanova.data.model.RoomEntity
import com.example.varanova.ui.components.SectionHeader
import com.example.varanova.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.varanova.ui.viewmodel.HostalViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperationsScreen(
    viewModel: HostalViewModel,
    initialOpenMaintenance: Boolean = false
) {
    val rooms by viewModel.rooms.collectAsStateWithLifecycle()
    val cleaningRecords by viewModel.cleaningRecords.collectAsStateWithLifecycle()
    val maintenanceRecords by viewModel.maintenanceRecords.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(if (initialOpenMaintenance) 1 else 0) } // 0: Limpieza, 1: Mantenimiento
    var showReportMaintDialog by remember { mutableStateOf(initialOpenMaintenance) }
    var roomToClean by remember { mutableStateOf<RoomEntity?>(null) }

    val sdf = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }

    Scaffold(
        floatingActionButton = {
            if (selectedTabIndex == 1) {
                ExtendedFloatingActionButton(
                    onClick = { showReportMaintDialog = true },
                    icon = { Icon(Icons.Default.Build, contentDescription = "Reportar Incidencia") },
                    text = { Text("Reportar Mantenimiento", fontWeight = FontWeight.Bold) },
                    containerColor = AmberSecondary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("fab_report_maint")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            SectionHeader(
                title = "Operaciones del Hostal",
                subtitle = "Limpieza y mantenimiento de habitaciones"
            )

            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(selected = selectedTabIndex == 0, onClick = { selectedTabIndex = 0 }, text = { Text("🧹 Limpieza", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTabIndex == 1, onClick = { selectedTabIndex = 1 }, text = { Text("⚠️ Mantenimiento", fontWeight = FontWeight.Bold) })
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (selectedTabIndex == 0) {
                // CLEANING SECTION
                val roomsNeedingClean = rooms.filter {
                    it.status == RoomEntity.ROOM_STATUS_CLEANING_PENDING ||
                            it.status == RoomEntity.ROOM_STATUS_OCCUPIED ||
                            it.status == RoomEntity.ROOM_STATUS_CLEANING
                }

                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                    item {
                        Text("ESTADO DE LIMPIEZA DE HABITACIONES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    }

                    items(rooms) { room ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(StatusCleaning.copy(alpha = 0.15f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.CleaningServices, contentDescription = null, tint = StatusCleaning)
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(room.name, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                        StatusBadge(status = room.status)
                                    }
                                }

                                if (room.status == RoomEntity.ROOM_STATUS_CLEANING_PENDING || room.status == RoomEntity.ROOM_STATUS_OCCUPIED) {
                                    Button(
                                        onClick = { roomToClean = room },
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                                        modifier = Modifier.testTag("btn_clean_room_${room.id}")
                                    ) {
                                        Text("Completar Limpieza", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // MAINTENANCE SECTION
                if (maintenanceRecords.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No hay incidencias de mantenimiento registradas.")
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                        items(maintenanceRecords) { maint ->
                            val room = rooms.find { it.id == maint.roomId }
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("⚠️ ${room?.name ?: "Habitación"}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        StatusBadge(status = if (maint.status == MaintenanceRecordEntity.STATUS_RESOLVED) "FINALIZADA" else "PENDIENTE")
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(maint.issue, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                    if (maint.technician != null) {
                                        Text("Técnico: ${maint.technician} • Costo: $${maint.cost}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    if (maint.status != MaintenanceRecordEntity.STATUS_RESOLVED) {
                                        Button(
                                            onClick = { viewModel.resolveMaintenance(maint) },
                                            colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                                            modifier = Modifier.fillMaxWidth().testTag("resolve_maint_btn_${maint.id}")
                                        ) {
                                            Text("Marcar Resuelto")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    roomToClean?.let { room ->
        var productsUsed by remember { mutableStateOf("2 jabones, 1 rollo de papel sanitario, detergente") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { roomToClean = null },
            title = { Text("Completar Limpieza: ${room.name}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = productsUsed,
                        onValueChange = { productsUsed = it },
                        label = { Text("Insumos/Productos utilizados") },
                        modifier = Modifier.fillMaxWidth().testTag("input_clean_products")
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Observaciones / Estado final") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.completeCleaning(room.id, productsUsed, notes)
                        roomToClean = null
                    },
                    modifier = Modifier.testTag("confirm_clean_btn")
                ) {
                    Text("Marcar Limpia y Disponible")
                }
            },
            dismissButton = {
                TextButton(onClick = { roomToClean = null }) { Text("Cancelar") }
            }
        )
    }

    if (showReportMaintDialog) {
        var selectedRoomId by remember { mutableStateOf(rooms.firstOrNull()?.id ?: 0L) }
        var issue by remember { mutableStateOf("") }
        var technician by remember { mutableStateOf("") }
        var cost by remember { mutableStateOf("0") }

        AlertDialog(
            onDismissRequest = { showReportMaintDialog = false },
            title = { Text("Reportar Mantenimiento", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Habitación", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    DropdownMenuBox(
                        options = rooms.map { it.name },
                        selectedIndex = rooms.indexOfFirst { it.id == selectedRoomId }.coerceAtLeast(0),
                        onSelect = { idx -> selectedRoomId = rooms[idx].id }
                    )

                    OutlinedTextField(
                        value = issue,
                        onValueChange = { issue = it },
                        label = { Text("Descripción del problema") },
                        modifier = Modifier.fillMaxWidth().testTag("input_maint_issue")
                    )

                    OutlinedTextField(
                        value = technician,
                        onValueChange = { technician = it },
                        label = { Text("Técnico o responsable") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = cost,
                        onValueChange = { cost = it },
                        label = { Text("Costo estimado ($)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (issue.isNotBlank()) {
                            viewModel.reportMaintenance(
                                roomId = selectedRoomId,
                                issue = issue,
                                priority = MaintenanceRecordEntity.PRIORITY_HIGH,
                                cost = cost.toDoubleOrNull() ?: 0.0,
                                technician = technician,
                                notes = ""
                            )
                            showReportMaintDialog = false
                        }
                    },
                    modifier = Modifier.testTag("save_maint_btn")
                ) {
                    Text("Guardar Mantenimiento")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportMaintDialog = false }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun DropdownMenuBox(options: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(options.getOrElse(selectedIndex) { "Seleccionar" })
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEachIndexed { idx, item ->
                DropdownMenuItem(text = { Text(item) }, onClick = { onSelect(idx); expanded = false })
            }
        }
    }
}
