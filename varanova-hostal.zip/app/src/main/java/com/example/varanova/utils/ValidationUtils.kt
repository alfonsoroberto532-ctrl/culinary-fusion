package com.example.varanova.utils

import com.example.data.utils.ValidationUtils

typealias ValidationUtils = ValidationUtils
