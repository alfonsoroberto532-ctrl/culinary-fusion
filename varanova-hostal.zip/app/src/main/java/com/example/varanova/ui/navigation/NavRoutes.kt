package com.example.varanova.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class NavRoutes(val route: String, val title: String, val icon: ImageVector) {
    object Dashboard : NavRoutes("dashboard", "Inicio", Icons.Default.Home)
    object Reservations : NavRoutes("reservations", "Reservas", Icons.Default.CalendarMonth)
    object Rooms : NavRoutes("rooms", "Habitaciones", Icons.Default.MeetingRoom)
    object Guests : NavRoutes("guests", "Huéspedes", Icons.Default.People)
    object Finances : NavRoutes("finances", "Finanzas", Icons.Default.AttachMoney)
    object Supplies : NavRoutes("supplies", "Suministros", Icons.Default.Inventory2)
    object Operations : NavRoutes("operations", "Operaciones", Icons.Default.CleaningServices)
    object Statistics : NavRoutes("statistics", "Estadísticas", Icons.Default.BarChart)
    object Settings : NavRoutes("settings", "Ajustes", Icons.Default.Settings)

    companion object {
        val bottomNavItems: List<NavRoutes>
            get() = listOf(
                Dashboard,
                Reservations,
                Rooms,
                Guests,
                Finances,
                Supplies,
                Operations,
                Statistics,
                Settings
            )
    }
}
