package com.example.varanova.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.varanova.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.varanova.ui.viewmodel.HostalViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun SettingsScreen(
    viewModel: HostalViewModel
) {
    val lastBackupTimestamp by viewModel.lastBackupTimestamp.collectAsStateWithLifecycle()
    val integrityReport by viewModel.integrityReport.collectAsStateWithLifecycle()
    val rooms by viewModel.rooms.collectAsStateWithLifecycle()
    val reservations by viewModel.reservationsWithDetails.collectAsStateWithLifecycle()

    var showConfirmClearDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var showIntegrityReportDialog by remember { mutableStateOf(false) }
    var restoreJsonInput by remember { mutableStateOf("") }

    val context = LocalContext.current
    val sdf = remember { SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()) }

    // File Picker Launcher for JSON Restore
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            try {
                val inputStream = context.contentResolver.openInputStream(it)
                val jsonString = inputStream?.bufferedReader()?.use { reader -> reader.readText() }
                if (!jsonString.isNullOrBlank()) {
                    viewModel.restoreBackupJson(context, jsonString)
                } else {
                    Toast.makeText(context, "Archivo JSON vacío", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error al leer archivo: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Configuración y Seguridad",
                subtitle = "Copias de seguridad, integridad y auditoría de base de datos"
            )
        }

        // Hostal Identity & System Health
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text("🏠 VaraNova Hostal", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TealPrimary)
                            Text("Versión 2.0 • Base de Datos Room (v4)", fontSize = 12.sp, color = Color.Gray)
                        }
                        Surface(
                            color = StatusAvailable.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                "Offline-First",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = StatusAvailable,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Resumen de base de datos: ${rooms.size} habitaciones registradas, ${reservations.size} reservas guardadas.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // BACKUP AND RESTORE SECTION
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Backup, contentDescription = null, tint = TealPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("RESPALDO Y RESTAURACIÓN", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TealPrimary)
                        }
                        Icon(
                            imageVector = if (lastBackupTimestamp > 0) Icons.Default.CloudDone else Icons.Default.CloudOff,
                            contentDescription = null,
                            tint = if (lastBackupTimestamp > 0) StatusAvailable else AmberSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (lastBackupTimestamp > 0)
                            "Último respaldo: ${sdf.format(Date(lastBackupTimestamp))}"
                        else
                            "⚠️ Sin copias de seguridad locales registradas aún.",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (lastBackupTimestamp > 0) MaterialTheme.colorScheme.onSurface else StatusOccupied
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.backupToGoogleDrive(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)), // Drive Green Accent
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_google_drive_backup")
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Guardar en Google Drive", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.generateBackupJson(context, shareAfter = false) },
                            colors = ButtonDefaults.buttonColors(containerColor = TealPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_generate_backup_json")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Generar Copia Local (JSON)")
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { viewModel.generateBackupJson(context, shareAfter = true) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_share_backup_json")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Compartir", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { filePickerLauncher.launch("application/json") },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusReserved),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_restore_from_file")
                            ) {
                                Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Restaurar JSON", fontSize = 12.sp)
                            }
                        }

                        TextButton(
                            onClick = { showRestoreDialog = true },
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        ) {
                            Text("Pegar texto JSON de respaldo manualmente", fontSize = 11.sp, color = TealPrimary)
                        }
                    }
                }
            }
        }

        // DATABASE INTEGRITY CHECK SECTION
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusAvailable)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("DIAGNÓSTICO E INTEGRIDAD DE BASE DE DATOS", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = StatusAvailable)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Valida inconsistencias, fechas solapadas, pagos huérfanos o estados inconsistentes en las tablas.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.runDatabaseIntegrityCheck()
                            showIntegrityReportDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_run_integrity_check")
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ejecutar Verificación de Integridad")
                    }

                    if (integrityReport != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        val report = integrityReport!!
                        Text(
                            text = if (report.isValid) "✅ Estado de Base de Datos Saludable" else "⚠️ Problemas detectados en la BD",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (report.isValid) StatusAvailable else StatusOccupied
                        )
                    }
                }
            }
        }

        // DEMO DATA & RESET SECTION
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("⚙️ REINICIO Y DATOS DE PRUEBA", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TealPrimary)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { viewModel.seedDemoData() },
                            colors = ButtonDefaults.buttonColors(containerColor = TealPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_load_demo_data")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Cargar Casa Nova", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { showConfirmClearDialog = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusOccupied),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_clear_all_data")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Borrar Todo", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }

    // Integrity Dialog Report
    if (showIntegrityReportDialog && integrityReport != null) {
        val rep = integrityReport!!
        AlertDialog(
            onDismissRequest = { showIntegrityReportDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (rep.isValid) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (rep.isValid) StatusAvailable else AmberSecondary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Reporte de Integridad BD")
                }
            },
            text = {
                Column {
                    Text("Problemas hallados: ${rep.issuesFoundCount} • Corregidos: ${rep.issuesFixedCount}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    rep.details.forEach { detail ->
                        Text("• $detail", fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showIntegrityReportDialog = false }) {
                    Text("Entendido")
                }
            }
        )
    }

    // Manual JSON Restore Text Paste Dialog
    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("Restaurar desde JSON (Texto)") },
            text = {
                Column {
                    Text("Pega el contenido del archivo JSON de respaldo:", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = restoreJsonInput,
                        onValueChange = { restoreJsonInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        placeholder = { Text("{ \"appName\": \"VaraNova Hostal\" ... }") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (restoreJsonInput.isNotBlank()) {
                            viewModel.restoreBackupJson(context, restoreJsonInput)
                            showRestoreDialog = false
                            restoreJsonInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusReserved)
                ) {
                    Text("Restaurar Ahora")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) { Text("Cancelar") }
            }
        )
    }

    // Confirm Clear Dialog
    if (showConfirmClearDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmClearDialog = false },
            title = { Text("⚠️ ¿Borrar todos los datos?", fontWeight = FontWeight.Bold) },
            text = { Text("Esta acción eliminará todas las habitaciones, reservas, pagos y gastos. Se recomienda realizar una copia de seguridad primero.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllData()
                        showConfirmClearDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusOccupied),
                    modifier = Modifier.testTag("confirm_clear_all_data_btn")
                ) {
                    Text("Sí, Borrar Todo")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmClearDialog = false }) { Text("Cancelar") }
            }
        )
    }
}
