package com.example.varanova.utils

import com.example.varanova.data.model.*
import java.util.Calendar

data class TaskPriorityItem(
    val id: String,
    val title: String,
    val description: String,
    val category: TaskCategory,
    val urgencyScore: Int, // Higher score = higher priority
    val actionLabel: String,
    val targetTabRoute: String,
    val actionType: SmartDashboardAlert.ActionType,
    val entityId: Long? = null,
    val secondaryAmount: Double = 0.0,
    val secondaryText: String = ""
) {
    enum class TaskCategory {
        CHECK_IN,
        CLEANING,
        MAINTENANCE,
        PREDICTIVE_SUPPLY,
        PAYMENT
    }
}

object TaskSmartRouter {

    /**
     * Evaluates all operational state and computes the top 3 highest priority tasks for the current shift.
     */
    fun evaluateTop3Tasks(
        rooms: List<RoomEntity>,
        reservations: List<ReservationWithDetails>,
        maintenanceRecords: List<MaintenanceRecordEntity>,
        supplies: List<SupplyItemEntity>,
        movements: List<InventoryMovementEntity>
    ): List<TaskPriorityItem> {
        val today = Calendar.getInstance()
        val todayStart = today.apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val todayEnd = todayStart + 86400000L

        val candidates = mutableListOf<TaskPriorityItem>()

        // 1. Cleaning tasks for rooms with CHECK-IN TODAY (Highest operational friction)
        val dirtyRooms = rooms.filter { it.status == RoomEntity.ROOM_STATUS_CLEANING_PENDING }
        dirtyRooms.forEach { room ->
            val hasCheckInToday = reservations.any { res ->
                res.room.id == room.id &&
                res.reservation.status != ReservationEntity.STATUS_CANCELLED &&
                res.reservation.checkInDate in todayStart until todayEnd
            }
            val score = if (hasCheckInToday) 100 else 75
            val guestName = reservations.find {
                it.room.id == room.id && it.reservation.checkInDate in todayStart until todayEnd
            }?.guest?.name

            val desc = if (guestName != null) {
                "🧹 Limpieza URGENTE en ${room.name}: Check-in programado hoy para $guestName."
            } else {
                "🧹 Limpieza pendiente en ${room.name} para habilitar disponibilidad."
            }

            candidates.add(
                TaskPriorityItem(
                    id = "task_clean_${room.id}",
                    title = if (hasCheckInToday) "Check-in Próximo: Limpieza Hab." else "Limpieza de Habitación",
                    description = desc,
                    category = TaskPriorityItem.TaskCategory.CLEANING,
                    urgencyScore = score,
                    actionLabel = "⚡ Marcar Limpia",
                    targetTabRoute = "operations",
                    actionType = SmartDashboardAlert.ActionType.QUICK_CLEAN_ROOM,
                    entityId = room.id
                )
            )
        }

        // 2. Urgent / High Priority Maintenance
        val pendingMaintenance = maintenanceRecords.filter { it.status != MaintenanceRecordEntity.STATUS_RESOLVED }
        pendingMaintenance.forEach { maint ->
            val roomName = rooms.find { it.id == maint.roomId }?.name ?: "Habitación"
            val score = when (maint.priority) {
                "Urgente" -> 95
                "Alta" -> 85
                "Media" -> 60
                else -> 40
            }

            candidates.add(
                TaskPriorityItem(
                    id = "task_maint_${maint.id}",
                    title = "Reparación: $roomName",
                    description = "🛠️ ${maint.issue} [Prioridad ${maint.priority}]",
                    category = TaskPriorityItem.TaskCategory.MAINTENANCE,
                    urgencyScore = score,
                    actionLabel = "⚡ Resolver Repare",
                    targetTabRoute = "operations",
                    actionType = SmartDashboardAlert.ActionType.QUICK_RESOLVE_MAINTENANCE,
                    entityId = maint.id
                )
            )
        }

        // 3. Guest Check-In Today Pending Payment or Key Handover
        val todayCheckIns = reservations.filter {
            it.reservation.status == ReservationEntity.STATUS_CONFIRMED &&
            it.reservation.checkInDate in todayStart until todayEnd
        }
        todayCheckIns.forEach { res ->
            candidates.add(
                TaskPriorityItem(
                    id = "task_checkin_${res.reservation.id}",
                    title = "Entrada Huésped: ${res.guest.name}",
                    description = "🔑 Preparar llegada a ${res.room.name}. Pendiente cobro: $${res.pendingBalance.toInt()} ${res.reservation.currency}.",
                    category = TaskPriorityItem.TaskCategory.CHECK_IN,
                    urgencyScore = 80,
                    actionLabel = if (res.pendingBalance > 0) "⚡ Cobrar y Recibir" else "⚡ Registrar Check-in",
                    targetTabRoute = "reservations",
                    actionType = SmartDashboardAlert.ActionType.QUICK_COLLECT_PAYMENT,
                    entityId = res.reservation.id,
                    secondaryAmount = res.pendingBalance,
                    secondaryText = res.reservation.currency
                )
            )
        }

        // 4. Predictive Supply Shortages (Average 30 days calculation)
        supplies.forEach { item ->
            val isLowNow = item.currentStock <= item.minStock
            val isPredictiveLow = calculateIsPredictivelyLow(item, movements)
            if (isLowNow || isPredictiveLow) {
                val score = if (isLowNow) 70 else 55
                val desc = if (isLowNow) {
                    "📦 Stock Crítico: ${item.name} (${item.currentStock.toInt()} ${item.unit} restantes)."
                } else {
                    "🔮 Agotamiento Proyectado: ${item.name} se agotará en <3 días según consumo."
                }

                candidates.add(
                    TaskPriorityItem(
                        id = "task_supply_${item.id}",
                        title = if (isLowNow) "Stock Bajo Insumos" else "Agotamiento Proyectado",
                        description = desc,
                        category = TaskPriorityItem.TaskCategory.PREDICTIVE_SUPPLY,
                        urgencyScore = score,
                        actionLabel = "⚡ Reponer Stock (+10)",
                        targetTabRoute = "supplies",
                        actionType = SmartDashboardAlert.ActionType.QUICK_RESTOCK_SUPPLY,
                        entityId = item.id
                    )
                )
            }
        }

        // Sort candidates by urgencyScore descending and return top 3
        return candidates.sortedByDescending { it.urgencyScore }.take(3)
    }

    /**
     * Predictive threshold calculator based on recent inventory movement history.
     */
    private fun calculateIsPredictivelyLow(
        item: SupplyItemEntity,
        movements: List<InventoryMovementEntity>
    ): Boolean {
        val itemMovements = movements.filter {
            it.supplyItemId == item.id &&
            (it.movementType == InventoryMovementEntity.TYPE_CONSUMPTION || it.movementType == "CONSUMO" || it.movementType == "SALIDA" || it.movementType == InventoryMovementEntity.TYPE_WASTE)
        }
        if (itemMovements.isEmpty()) return false

        val thirtyDaysAgo = System.currentTimeMillis() - (30L * 24 * 3600 * 1000)
        val recentExits = itemMovements.filter { it.date >= thirtyDaysAgo }
        val totalConsumed30Days = recentExits.sumOf { it.quantity }
        val dailyAverageUsage = totalConsumed30Days / 30.0

        if (dailyAverageUsage <= 0) return false

        // Days remaining with current stock
        val daysRemaining = item.currentStock / dailyAverageUsage
        // If stock will last less than 3 days, trigger predictive alert
        return daysRemaining < 3.0
    }
}
