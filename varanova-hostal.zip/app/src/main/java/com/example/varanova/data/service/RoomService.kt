package com.example.varanova.data.service

import com.example.varanova.data.dao.HostalDao
import com.example.varanova.data.model.*
import kotlinx.coroutines.flow.Flow

class RoomService(private val dao: HostalDao) {

    val allRooms: Flow<List<RoomEntity>> = dao.getAllRooms()

    suspend fun getRoomById(id: Long): RoomEntity? {
        return dao.getRoomById(id)
    }

    suspend fun saveRoom(room: RoomEntity): Long {
        val id = if (room.id == 0L) {
            dao.insertRoom(room).also { newId ->
                dao.insertAuditLog(
                    AuditLogEntity(
                        entityType = "ROOM",
                        entityId = newId,
                        action = "CREATE",
                        details = "Habitación ${room.name} creada"
                    )
                )
            }
        } else {
            dao.updateRoom(room)
            dao.insertAuditLog(
                AuditLogEntity(
                    entityType = "ROOM",
                    entityId = room.id,
                    action = "UPDATE",
                    details = "Habitación ${room.name} actualizada"
                )
            )
            room.id
        }
        return id
    }

    suspend fun deleteRoom(room: RoomEntity) {
        dao.deleteRoom(room)
        dao.insertAuditLog(
            AuditLogEntity(
                entityType = "ROOM",
                entityId = room.id,
                action = "DELETE",
                details = "Habitación ${room.name} eliminada"
            )
        )
    }

    suspend fun updateRoomStatus(roomId: Long, newStatus: String) {
        val room = dao.getRoomById(roomId) ?: return
        if (room.status != newStatus) {
            dao.updateRoom(room.copy(status = newStatus))
            dao.insertAuditLog(
                AuditLogEntity(
                    entityType = "ROOM",
                    entityId = roomId,
                    action = "STATUS_CHANGE",
                    details = "Estado de habitación ${room.name} cambiado a $newStatus"
                )
            )
        }
    }

    suspend fun recordCleaning(roomId: Long, productsUsed: String, notes: String) {
        dao.insertCleaningRecord(
            CleaningRecordEntity(
                roomId = roomId,
                productsUsed = productsUsed,
                notes = notes,
                status = CleaningRecordEntity.STATUS_COMPLETED
            )
        )
        val room = dao.getRoomById(roomId)
        if (room != null) {
            dao.updateRoom(room.copy(status = RoomEntity.ROOM_STATUS_AVAILABLE))
            dao.insertAuditLog(
                AuditLogEntity(
                    entityType = "ROOM",
                    entityId = roomId,
                    action = "CLEANING",
                    details = "Habitación ${room.name} marcada como limpia y disponible"
                )
            )
        }
    }

    suspend fun recordMaintenance(
        roomId: Long,
        issue: String,
        priority: String,
        cost: Double = 0.0,
        technician: String? = null,
        notes: String = "",
        blockRoom: Boolean = true
    ) {
        val recordId = dao.insertMaintenanceRecord(
            MaintenanceRecordEntity(
                roomId = roomId,
                issue = issue,
                priority = priority,
                cost = cost,
                technician = technician,
                notes = notes,
                status = MaintenanceRecordEntity.STATUS_PENDING
            )
        )

        if (blockRoom) {
            val room = dao.getRoomById(roomId)
            if (room != null) {
                dao.updateRoom(room.copy(status = RoomEntity.ROOM_STATUS_MAINTENANCE))
            }
        }

        if (cost > 0) {
            dao.insertExpense(
                ExpenseEntity(
                    categoryName = "Reparaciones",
                    description = "Mantenimiento: $issue",
                    amount = cost,
                    roomId = roomId,
                    supplier = technician
                )
            )
        }

        dao.insertAuditLog(
            AuditLogEntity(
                entityType = "MAINTENANCE",
                entityId = recordId,
                action = "CREATE",
                details = "Mantenimiento reportado: $issue en habitación #$roomId"
            )
        )
    }

    suspend fun resolveMaintenance(record: MaintenanceRecordEntity) {
        dao.updateMaintenanceRecord(
            record.copy(
                status = MaintenanceRecordEntity.STATUS_RESOLVED,
                resolvedDate = System.currentTimeMillis()
            )
        )
        val room = dao.getRoomById(record.roomId)
        if (room != null && room.status == RoomEntity.ROOM_STATUS_MAINTENANCE) {
            dao.updateRoom(room.copy(status = RoomEntity.ROOM_STATUS_CLEANING_PENDING))
        }
    }
}
