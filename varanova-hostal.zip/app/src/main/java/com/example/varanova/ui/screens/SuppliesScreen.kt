package com.example.varanova.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.varanova.data.model.InventoryMovementEntity
import com.example.varanova.data.model.SupplyItemEntity
import com.example.varanova.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.varanova.ui.viewmodel.HostalViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuppliesScreen(
    viewModel: HostalViewModel,
    initialOpenPurchase: Boolean = false
) {
    val supplyItems by viewModel.supplyItems.collectAsStateWithLifecycle()
    val movements by viewModel.inventoryMovements.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Insumos, 1: Historial
    var showAddItemDialog by remember { mutableStateOf(false) }
    var selectedItemForMovement by remember { mutableStateOf<Pair<SupplyItemEntity, String>?>(null) }

    val sdf = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddItemDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = "Nuevo Insumo") },
                text = { Text("Nuevo Insumo", fontWeight = FontWeight.Bold) },
                containerColor = TealPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_supply")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            SectionHeader(
                title = "Inventario de Suministros",
                subtitle = "${supplyItems.size} productos registrados"
            )

            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(selected = selectedTabIndex == 0, onClick = { selectedTabIndex = 0 }, text = { Text("Existencias", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTabIndex == 1, onClick = { selectedTabIndex = 1 }, text = { Text("Historial Movimientos", fontWeight = FontWeight.Bold) })
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedTabIndex == 0) {
                if (supplyItems.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No hay suministros registrados. Presiona el botón para agregar uno.")
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                        items(supplyItems) { item ->
                            SupplyItemCard(
                                item = item,
                                onPurchase = { selectedItemForMovement = Pair(item, InventoryMovementEntity.TYPE_PURCHASE) },
                                onConsume = { selectedItemForMovement = Pair(item, InventoryMovementEntity.TYPE_CONSUMPTION) }
                            )
                        }
                    }
                }
            } else {
                if (movements.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No hay movimientos de inventario registrados.")
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                        items(movements) { mov ->
                            val item = supplyItems.find { it.id == mov.supplyItemId }
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("${mov.movementType}: ${item?.name ?: "Insumo"}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("${mov.quantity} ${item?.unit ?: "unidades"} • ${sdf.format(Date(mov.date))}", fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Text(
                                        text = if (mov.movementType == InventoryMovementEntity.TYPE_PURCHASE) "+${mov.quantity}" else "-${mov.quantity}",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (mov.movementType == InventoryMovementEntity.TYPE_PURCHASE) StatusAvailable else StatusOccupied
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddItemDialog) {
        AddSupplyItemDialog(
            viewModel = viewModel,
            onDismiss = { showAddItemDialog = false },
            onSave = { item ->
                viewModel.saveSupplyItem(item)
                showAddItemDialog = false
            }
        )
    }

    selectedItemForMovement?.let { (item, type) ->
        var quantityInput by remember { mutableStateOf("1") }
        var notesInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { selectedItemForMovement = null },
            title = { Text("Registrar $type: ${item.name}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Stock actual: ${item.currentStock} ${item.unit}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = quantityInput,
                        onValueChange = { quantityInput = it },
                        label = { Text("Cantidad (${item.unit})") },
                        modifier = Modifier.fillMaxWidth().testTag("input_movement_quantity")
                    )
                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        label = { Text("Notas o motivo") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val q = quantityInput.toDoubleOrNull() ?: 0.0
                        if (q > 0) {
                            viewModel.recordInventoryMovement(item.id, type, q, notes = notesInput)
                            selectedItemForMovement = null
                        }
                    },
                    modifier = Modifier.testTag("confirm_movement_btn")
                ) {
                    Text("Confirmar")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedItemForMovement = null }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun SupplyItemCard(
    item: SupplyItemEntity,
    onPurchase: () -> Unit,
    onConsume: () -> Unit
) {
    val isLowStock = item.currentStock <= item.minStock

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(if (isLowStock) StatusOccupied.copy(alpha = 0.15f) else StatusAvailable.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Inventory2,
                            contentDescription = null,
                            tint = if (isLowStock) StatusOccupied else StatusAvailable,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(item.name, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("Categoría: ${item.category} • Mínimo: ${item.minStock.toInt()} ${item.unit}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        // Predictive threshold estimation badge
                        val estUsage30 = item.minStock * 1.5
                        val daysEst = if (estUsage30 > 0) ((item.currentStock / (estUsage30 / 30.0)).coerceIn(1.0, 99.0)).toInt() else 30
                        Text(
                            text = "🔮 Proyección: ~$daysEst días de stock según consumo medio",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (daysEst < 5) StatusOccupied else TealPrimary
                        )
                    }
                }

                Surface(
                    color = if (isLowStock) StatusOccupied.copy(alpha = 0.15f) else StatusAvailable.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text(
                        text = if (isLowStock) "⚠️ Stock Bajo" else "🟢 OK",
                        color = if (isLowStock) StatusOccupied else StatusAvailable,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("EXISTENCIA ACTUAL", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text("${item.currentStock.toInt()} ${item.unit}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = if (isLowStock) StatusOccupied else TealPrimary)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onPurchase,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                        modifier = Modifier.testTag("btn_buy_supply_${item.id}")
                    ) {
                        Text("+ Compra", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = onConsume,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusOccupied),
                        modifier = Modifier.testTag("btn_consume_supply_${item.id}")
                    ) {
                        Text("- Consumo", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun AddSupplyItemDialog(
    viewModel: HostalViewModel,
    onDismiss: () -> Unit,
    onSave: (SupplyItemEntity) -> Unit
) {
    var nlInput by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Limpieza") }
    var unit by remember { mutableStateOf("Unidad") }
    var currentStock by remember { mutableStateOf("10") }
    var minStock by remember { mutableStateOf("5") }

    val units = listOf("Unidad", "Rollo", "Litro", "Kg", "Caja", "Paquete", "Botella", "Otro")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo Insumo de Inventario", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = nlInput,
                    onValueChange = { text ->
                        nlInput = text
                        val parsed = viewModel.parseSupplyText(text)
                        if (parsed.itemName.isNotBlank()) name = parsed.itemName
                        if (parsed.quantity > 0) currentStock = parsed.quantity.toInt().toString()
                        if (parsed.unit.isNotBlank()) {
                            val matchedUnit = units.find { it.equals(parsed.unit, ignoreCase = true) } ?: "Unidad"
                            unit = matchedUnit
                        }
                    },
                    label = { Text("⚡ Entrada en Lenguaje Natural") },
                    placeholder = { Text("Ej: Jabon Liquido 15 litros") },
                    leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = TealPrimary) },
                    modifier = Modifier.fillMaxWidth().testTag("input_supply_nl"),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nombre del Producto (ej. Papel Sanitario)") },
                    modifier = Modifier.fillMaxWidth().testTag("input_supply_name")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = currentStock,
                        onValueChange = { currentStock = it },
                        label = { Text("Existencia Inicial") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minStock,
                        onValueChange = { minStock = it },
                        label = { Text("Mínimo Alerta") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Text("Unidad de Medida", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                DropdownMenuBox(
                    options = units,
                    selectedIndex = units.indexOf(unit).coerceAtLeast(0),
                    onSelect = { idx -> unit = units[idx] }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val item = SupplyItemEntity(
                            name = name,
                            category = category,
                            unit = unit,
                            currentStock = currentStock.toDoubleOrNull() ?: 0.0,
                            minStock = minStock.toDoubleOrNull() ?: 5.0
                        )
                        onSave(item)
                    }
                },
                modifier = Modifier.testTag("save_supply_btn")
            ) {
                Text("Guardar Insumo")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
private fun DropdownMenuBox(options: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(options.getOrElse(selectedIndex) { "Seleccionar" })
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEachIndexed { idx, item ->
                DropdownMenuItem(text = { Text(item) }, onClick = { onSelect(idx); expanded = false })
            }
        }
    }
}
