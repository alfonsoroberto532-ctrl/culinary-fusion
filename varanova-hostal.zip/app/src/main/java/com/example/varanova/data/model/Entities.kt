package com.example.varanova.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Categorías / Tipos de Habitación
 */
enum class RoomType(val label: String, val code: String) {
    SINGLE("Individual", "SINGLE"),
    DOUBLE("Doble Matrimonial", "DOUBLE"),
    DORMITORY("Compartida / Litera", "DORMITORY"),
    SUITE("Suite Premium", "SUITE"),
    ENTIRE_HOUSE("Casa / Propiedad Completa", "ENTIRE_HOUSE");

    companion object {
        fun fromCode(code: String): RoomType {
            return entries.find { it.code.equals(code, ignoreCase = true) || it.name.equals(code, ignoreCase = true) } ?: DOUBLE
        }
    }
}

/**
 * Habitaciones o Casa Completa
 */
@Entity(tableName = "rooms")
data class RoomEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, // ej. "Habitación 1", "Habitación Azul", "Casa completa"
    val description: String = "",
    val capacity: Int = 2,
    val pricePerNight: Double = 30.0,
    val currency: String = "USD", // Moneda base del precio
    val status: String = ROOM_STATUS_AVAILABLE, // DISPONIBLE, RESERVADA, OCUPADA, LIMPIEZA_PENDIENTE, LIMPIANDO, MANTENIMIENTO
    val roomType: String = RoomType.DOUBLE.code, // SINGLE, DOUBLE, DORMITORY, SUITE, ENTIRE_HOUSE
    val isEntireProperty: Boolean = false,
    val features: String = "Aire Acondicionado, Baño Privado, Wi-Fi", // separadas por coma
    val notes: String = "",
    val photoUri: String? = null
) {
    companion object {
        const val ROOM_STATUS_AVAILABLE = "AVAILABLE"             // 🟢 Disponible
        const val ROOM_STATUS_RESERVED = "RESERVED"               // 🔵 Reservada
        const val ROOM_STATUS_OCCUPIED = "OCCUPIED"               // 🔴 Ocupada
        const val ROOM_STATUS_CLEANING_PENDING = "CLEANING_PENDING"// 🟡 Pendiente de limpieza
        const val ROOM_STATUS_CLEANING = "CLEANING"               // 🟢 Limpiando
        const val ROOM_STATUS_MAINTENANCE = "MAINTENANCE"         // ⚠️ Mantenimiento
    }
}

/**
 * Huéspedes
 */
@Entity(tableName = "guests")
data class GuestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val nationality: String = "",
    val documentId: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Reservas
 */
@Entity(
    tableName = "reservations",
    foreignKeys = [
        ForeignKey(
            entity = RoomEntity::class,
            parentColumns = ["id"],
            childColumns = ["roomId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = GuestEntity::class,
            parentColumns = ["id"],
            childColumns = ["guestId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("roomId"), Index("guestId")]
)
data class ReservationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val guestId: Long,
    val roomId: Long,
    val checkInDate: Long,  // Epoch millis or date
    val checkOutDate: Long, // Epoch millis or date
    val checkInTime: String = "14:00",
    val checkOutTime: String = "11:00",
    val guestCount: Int = 1,
    val pricePerNight: Double = 0.0,
    val totalPrice: Double = 0.0,
    val advancePayment: Double = 0.0,
    val currency: String = "USD",
    val status: String = STATUS_CONFIRMED, // CONFIRMED, CHECKED_IN, CHECKED_OUT, CANCELLED
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val STATUS_CONFIRMED = "CONFIRMED"
        const val STATUS_CHECKED_IN = "CHECKED_IN"
        const val STATUS_CHECKED_OUT = "CHECKED_OUT"
        const val STATUS_CANCELLED = "CANCELLED"
    }
}

/**
 * Historial de Pagos de Reservas
 */
@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = ReservationEntity::class,
            parentColumns = ["id"],
            childColumns = ["reservationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("reservationId")]
)
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reservationId: Long,
    val amount: Double,
    val currency: String = "USD",
    val exchangeRateToPrimary: Double = 1.0,
    val date: Long = System.currentTimeMillis(),
    val paymentType: String = "Adelanto", // "Adelanto", "Pago Final", "Parcial"
    val notes: String = ""
)

/**
 * Categorías de Gastos
 */
@Entity(tableName = "expense_categories")
data class ExpenseCategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val iconName: String = "receipt",
    val isSystem: Boolean = false
)

/**
 * Gastos (Generales o Relacionados a Habitación / Reserva)
 */
@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long = System.currentTimeMillis(),
    val categoryName: String,
    val description: String,
    val amount: Double,
    val currency: String = "USD",
    val exchangeRateToPrimary: Double = 1.0,
    val roomId: Long? = null,
    val reservationId: Long? = null,
    val supplier: String? = null,
    val notes: String = ""
)

/**
 * Suministros (Inventario de insumos del hostal)
 */
@Entity(tableName = "supply_items")
data class SupplyItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, // ej. "Papel Sanitario", "Jabón", "Detergente"
    val category: String = "Limpieza", // Limpieza, Baño, Cocina, Mantenimiento, Varios
    val unit: String = "Unidad", // Unidad, Rollo, Litro, Kg, Caja, Paquete, Botella
    val currentStock: Double = 0.0,
    val minStock: Double = 5.0,
    val lastPurchasePrice: Double = 0.0,
    val currency: String = "USD",
    val supplier: String? = null,
    val lastPurchaseDate: Long = System.currentTimeMillis()
)

/**
 * Movimientos de Inventario (Trazabilidad estricta)
 */
@Entity(
    tableName = "inventory_movements",
    foreignKeys = [
        ForeignKey(
            entity = SupplyItemEntity::class,
            parentColumns = ["id"],
            childColumns = ["supplyItemId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("supplyItemId")]
)
data class InventoryMovementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplyItemId: Long,
    val movementType: String, // COMPRA (+), CONSUMO (-), AJUSTE (+/-), MERMA (-)
    val quantity: Double,
    val date: Long = System.currentTimeMillis(),
    val roomId: Long? = null,
    val reservationId: Long? = null,
    val notes: String = ""
) {
    companion object {
        const val TYPE_PURCHASE = "COMPRA"
        const val TYPE_CONSUMPTION = "CONSUMO"
        const val TYPE_ADJUSTMENT = "AJUSTE"
        const val TYPE_WASTE = "MERMA"
    }
}

/**
 * Registro de Limpieza de Habitaciones
 */
@Entity(
    tableName = "cleaning_records",
    foreignKeys = [
        ForeignKey(
            entity = RoomEntity::class,
            parentColumns = ["id"],
            childColumns = ["roomId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("roomId")]
)
data class CleaningRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val roomId: Long,
    val date: Long = System.currentTimeMillis(),
    val status: String = STATUS_COMPLETED, // PENDING, IN_PROGRESS, COMPLETED
    val productsUsed: String = "", // ej. "2 jabones, 1 rollo papel"
    val notes: String = ""
) {
    companion object {
        const val STATUS_PENDING = "PENDING"
        const val STATUS_IN_PROGRESS = "IN_PROGRESS"
        const val STATUS_COMPLETED = "COMPLETED"
    }
}

/**
 * Registro de Mantenimiento de Habitaciones
 */
@Entity(
    tableName = "maintenance_records",
    foreignKeys = [
        ForeignKey(
            entity = RoomEntity::class,
            parentColumns = ["id"],
            childColumns = ["roomId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("roomId")]
)
data class MaintenanceRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val roomId: Long,
    val issue: String, // ej. "Aire acondicionado gotea"
    val priority: String = PRIORITY_MEDIUM, // LOW, MEDIUM, HIGH, CRITICAL
    val status: String = STATUS_PENDING, // PENDING, IN_REPAIR, RESOLVED
    val cost: Double = 0.0,
    val currency: String = "USD",
    val technician: String? = null,
    val reportedDate: Long = System.currentTimeMillis(),
    val resolvedDate: Long? = null,
    val notes: String = ""
) {
    companion object {
        const val PRIORITY_LOW = "LOW"
        const val PRIORITY_MEDIUM = "MEDIUM"
        const val PRIORITY_HIGH = "HIGH"
        const val PRIORITY_CRITICAL = "CRITICAL"

        const val STATUS_PENDING = "PENDING"
        const val STATUS_IN_REPAIR = "IN_REPAIR"
        const val STATUS_RESOLVED = "RESOLVED"
    }
}

/**
 * Tasas de Cambio de Monedas
 */
@Entity(tableName = "exchange_rates")
data class ExchangeRateEntity(
    @PrimaryKey val currencyCode: String, // CUP, USD, EUR, CAD, etc.
    val rateToPrimary: Double, // Cuántas unidades de esta moneda equivalen a 1 Moneda Base (ej. 1 USD = 500 CUP)
    val lastUpdated: Long = System.currentTimeMillis()
)

/**
 * Registro de Trazabilidad / Auditoría
 */
@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entityType: String, // RESERVATION, PAYMENT, EXPENSE, INVENTORY, ROOM
    val entityId: Long,
    val action: String, // CREATE, UPDATE, DELETE
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)
