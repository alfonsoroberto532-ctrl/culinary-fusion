package com.example.varanova.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.varanova.data.model.MaintenanceRecordEntity
import com.example.varanova.data.model.ReservationWithDetails
import java.util.Calendar

object NotificationHelper {

    private const val CHANNEL_ID = "hostal_alerts_channel"
    private const val CHANNEL_NAME = "Alertas del Hostal"
    private const val CHANNEL_DESC = "Notificaciones para entradas del día y mantenimientos pendientes"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESC
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun showNotification(context: Context, title: String, message: String, notificationId: Int = System.currentTimeMillis().toInt()) {
        createNotificationChannel(context)

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try {
            notificationManager.notify(notificationId, builder.build())
        } catch (e: SecurityException) {
            // Notification permission missing or revoked
        }
    }

    fun checkAndNotifyUpcomingEvents(
        context: Context,
        reservations: List<ReservationWithDetails>,
        maintenanceTasks: List<MaintenanceRecordEntity>
    ) {
        val today = Calendar.getInstance()
        val todayStart = today.apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val todayEnd = todayStart + 86400000L

        // Check-ins for today
        val todayCheckIns = reservations.filter { res ->
            res.reservation.checkInDate in todayStart until todayEnd
        }

        if (todayCheckIns.isNotEmpty()) {
            val names = todayCheckIns.take(2).joinToString { "${it.guest.name} (${it.room.name})" }
            showNotification(
                context = context,
                title = "🔔 Entradas para hoy (${todayCheckIns.size})",
                message = "Huéspedes llegando hoy: $names",
                notificationId = 1001
            )
        }

        // Pending maintenance tasks
        val pendingMaint = maintenanceTasks.filter { it.status != MaintenanceRecordEntity.STATUS_RESOLVED }
        if (pendingMaint.isNotEmpty()) {
            val taskSummary = pendingMaint.first().issue
            showNotification(
                context = context,
                title = "⚠️ Mantenimiento pendiente (${pendingMaint.size})",
                message = "Tarea pendiente: $taskSummary",
                notificationId = 1002
            )
        }
    }

    fun checkAndNotifyLowStock(
        context: Context,
        supplies: List<com.example.varanova.data.model.SupplyItemEntity>
    ) {
        val lowStockItems = supplies.filter { it.currentStock <= it.minStock }
        if (lowStockItems.isNotEmpty()) {
            val summary = lowStockItems.take(3).joinToString { "${it.name} (${it.currentStock.toInt()}/${it.minStock.toInt()} ${it.unit})" }
            showNotification(
                context = context,
                title = "📦 Alerta de Inventario (Suministros Bajos)",
                message = "Stock por debajo del mínimo: $summary",
                notificationId = 1003
            )
        }
    }

    fun sendDailyShiftSummaryNotification(
        context: Context,
        reservations: List<ReservationWithDetails>,
        maintenanceTasks: List<MaintenanceRecordEntity>,
        supplies: List<com.example.varanova.data.model.SupplyItemEntity>,
        rooms: List<com.example.varanova.data.model.RoomEntity>
    ) {
        val today = Calendar.getInstance()
        val todayStart = today.apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val todayEnd = todayStart + 86400000L

        val criticalTasks = mutableListOf<String>()

        val todayCheckIns = reservations.filter { it.reservation.checkInDate in todayStart until todayEnd }
        if (todayCheckIns.isNotEmpty()) {
            criticalTasks.add("🔑 ${todayCheckIns.size} Check-in(s) hoy (ej: ${todayCheckIns.first().guest.name})")
        }

        val dirtyRooms = rooms.filter { it.status == com.example.varanova.data.model.RoomEntity.ROOM_STATUS_CLEANING_PENDING }
        if (dirtyRooms.isNotEmpty()) {
            criticalTasks.add("🧹 Limpieza en ${dirtyRooms.size} hab(s): ${dirtyRooms.joinToString { it.name }}")
        }

        val pendingMaint = maintenanceTasks.filter { it.status != MaintenanceRecordEntity.STATUS_RESOLVED }
        if (pendingMaint.isNotEmpty()) {
            criticalTasks.add("🛠️ ${pendingMaint.size} Mantenimiento: ${pendingMaint.first().issue}")
        }

        val lowStock = supplies.filter { it.currentStock <= it.minStock }
        if (lowStock.isNotEmpty()) {
            criticalTasks.add("📦 Insumos bajos: ${lowStock.first().name}")
        }

        val top3 = criticalTasks.take(3)
        val message = if (top3.isNotEmpty()) {
            top3.joinToString(" • ")
        } else {
            "✨ ¡Todo en orden para tu turno! Sin tareas urgentes."
        }

        showNotification(
            context = context,
            title = "🌅 Resumen de Turno Varanova (3 Prioridades)",
            message = message,
            notificationId = 1005
        )
    }
}

