package com.example.varanova.utils

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.varanova.data.database.AppDatabase
import com.example.varanova.data.utils.BackupManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DailyBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val dao = AppDatabase.getDatabase(applicationContext).hostalDao()
            val (file, _) = BackupManager.generateBackupJson(applicationContext, dao)
            NotificationHelper.showNotification(
                applicationContext,
                title = "💾 Respaldo Automático Completado",
                message = "Base de datos respaldada diariamente: ${file.name}",
                notificationId = 2001
            )
            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }
}
