package com.example.varanova.data.model

import com.example.data.model.Room

typealias Room = com.example.data.model.Room
