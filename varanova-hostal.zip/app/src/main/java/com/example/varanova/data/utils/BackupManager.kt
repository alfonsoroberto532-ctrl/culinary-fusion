package com.example.varanova.data.utils

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.varanova.data.dao.HostalDao
import com.example.varanova.data.model.*
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object BackupManager {

    private const val PREFS_NAME = "varanova_backup_prefs"
    private const val KEY_LAST_BACKUP = "last_backup_timestamp"

    fun getLastBackupTimestamp(context: Context): Long {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getLong(KEY_LAST_BACKUP, 0L)
    }

    fun setLastBackupTimestamp(context: Context, timestamp: Long) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putLong(KEY_LAST_BACKUP, timestamp).apply()
    }

    suspend fun generateBackupJson(context: Context, dao: HostalDao): Pair<File, String> {
        val rooms = dao.getAllRooms().first()
        val guests = dao.getAllGuests().first()
        val reservations = dao.getAllReservations().first()
        val payments = dao.getAllPayments().first()
        val expenses = dao.getAllExpenses().first()
        val expenseCategories = dao.getAllExpenseCategories().first()
        val supplies = dao.getAllSupplyItems().first()
        val movements = dao.getAllInventoryMovements().first()
        val cleaning = dao.getAllCleaningRecords().first()
        val maintenance = dao.getAllMaintenanceRecords().first()
        val exchangeRates = dao.getAllExchangeRates().first()

        val rootJson = JSONObject()
        rootJson.put("appName", "VaraNova Hostal")
        rootJson.put("version", 4)
        val now = System.currentTimeMillis()
        rootJson.put("timestamp", now)
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        rootJson.put("formattedDate", sdf.format(Date(now)))

        // Rooms
        val roomsArray = JSONArray()
        rooms.forEach { r ->
            val obj = JSONObject()
            obj.put("id", r.id)
            obj.put("name", r.name)
            obj.put("description", r.description)
            obj.put("capacity", r.capacity)
            obj.put("pricePerNight", r.pricePerNight)
            obj.put("currency", r.currency)
            obj.put("status", r.status)
            obj.put("roomType", r.roomType)
            obj.put("isEntireProperty", r.isEntireProperty)
            obj.put("features", r.features)
            obj.put("notes", r.notes)
            roomsArray.put(obj)
        }
        rootJson.put("rooms", roomsArray)

        // Guests
        val guestsArray = JSONArray()
        guests.forEach { g ->
            val obj = JSONObject()
            obj.put("id", g.id)
            obj.put("name", g.name)
            obj.put("phone", g.phone)
            obj.put("nationality", g.nationality)
            obj.put("documentId", g.documentId)
            obj.put("notes", g.notes)
            obj.put("createdAt", g.createdAt)
            guestsArray.put(obj)
        }
        rootJson.put("guests", guestsArray)

        // Reservations
        val resArray = JSONArray()
        reservations.forEach { res ->
            val obj = JSONObject()
            obj.put("id", res.id)
            obj.put("guestId", res.guestId)
            obj.put("roomId", res.roomId)
            obj.put("checkInDate", res.checkInDate)
            obj.put("checkOutDate", res.checkOutDate)
            obj.put("checkInTime", res.checkInTime)
            obj.put("checkOutTime", res.checkOutTime)
            obj.put("guestCount", res.guestCount)
            obj.put("pricePerNight", res.pricePerNight)
            obj.put("totalPrice", res.totalPrice)
            obj.put("advancePayment", res.advancePayment)
            obj.put("currency", res.currency)
            obj.put("status", res.status)
            obj.put("notes", res.notes)
            obj.put("createdAt", res.createdAt)
            resArray.put(obj)
        }
        rootJson.put("reservations", resArray)

        // Payments
        val paymentsArray = JSONArray()
        payments.forEach { p ->
            val obj = JSONObject()
            obj.put("id", p.id)
            obj.put("reservationId", p.reservationId)
            obj.put("amount", p.amount)
            obj.put("currency", p.currency)
            obj.put("exchangeRateToPrimary", p.exchangeRateToPrimary)
            obj.put("date", p.date)
            obj.put("paymentType", p.paymentType)
            obj.put("notes", p.notes)
            paymentsArray.put(obj)
        }
        rootJson.put("payments", paymentsArray)

        // Expenses
        val expensesArray = JSONArray()
        expenses.forEach { e ->
            val obj = JSONObject()
            obj.put("id", e.id)
            obj.put("date", e.date)
            obj.put("categoryName", e.categoryName)
            obj.put("description", e.description)
            obj.put("amount", e.amount)
            obj.put("currency", e.currency)
            obj.put("exchangeRateToPrimary", e.exchangeRateToPrimary)
            obj.put("roomId", e.roomId ?: JSONObject.NULL)
            obj.put("reservationId", e.reservationId ?: JSONObject.NULL)
            obj.put("supplier", e.supplier ?: JSONObject.NULL)
            obj.put("notes", e.notes)
            expensesArray.put(obj)
        }
        rootJson.put("expenses", expensesArray)

        // Expense Categories
        val expCatArray = JSONArray()
        expenseCategories.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id)
            obj.put("name", c.name)
            obj.put("iconName", c.iconName)
            obj.put("isSystem", c.isSystem)
            expCatArray.put(obj)
        }
        rootJson.put("expenseCategories", expCatArray)

        // Supply Items
        val suppliesArray = JSONArray()
        supplies.forEach { s ->
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("name", s.name)
            obj.put("category", s.category)
            obj.put("unit", s.unit)
            obj.put("currentStock", s.currentStock)
            obj.put("minStock", s.minStock)
            obj.put("lastPurchasePrice", s.lastPurchasePrice)
            obj.put("currency", s.currency)
            obj.put("supplier", s.supplier ?: JSONObject.NULL)
            obj.put("lastPurchaseDate", s.lastPurchaseDate)
            suppliesArray.put(obj)
        }
        rootJson.put("supplyItems", suppliesArray)

        // Inventory Movements
        val movementsArray = JSONArray()
        movements.forEach { m ->
            val obj = JSONObject()
            obj.put("id", m.id)
            obj.put("supplyItemId", m.supplyItemId)
            obj.put("movementType", m.movementType)
            obj.put("quantity", m.quantity)
            obj.put("date", m.date)
            obj.put("roomId", m.roomId ?: JSONObject.NULL)
            obj.put("reservationId", m.reservationId ?: JSONObject.NULL)
            obj.put("notes", m.notes)
            movementsArray.put(obj)
        }
        rootJson.put("inventoryMovements", movementsArray)

        // Cleaning Records
        val cleaningArray = JSONArray()
        cleaning.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id)
            obj.put("roomId", c.roomId)
            obj.put("date", c.date)
            obj.put("status", c.status)
            obj.put("productsUsed", c.productsUsed)
            obj.put("notes", c.notes)
            cleaningArray.put(obj)
        }
        rootJson.put("cleaningRecords", cleaningArray)

        // Maintenance Records
        val maintArray = JSONArray()
        maintenance.forEach { m ->
            val obj = JSONObject()
            obj.put("id", m.id)
            obj.put("roomId", m.roomId)
            obj.put("issue", m.issue)
            obj.put("priority", m.priority)
            obj.put("status", m.status)
            obj.put("cost", m.cost)
            obj.put("currency", m.currency)
            obj.put("technician", m.technician ?: JSONObject.NULL)
            obj.put("reportedDate", m.reportedDate)
            obj.put("resolvedDate", if (m.resolvedDate != null) m.resolvedDate else JSONObject.NULL)
            obj.put("notes", m.notes)
            maintArray.put(obj)
        }
        rootJson.put("maintenanceRecords", maintArray)

        // Exchange Rates
        val ratesArray = JSONArray()
        exchangeRates.forEach { er ->
            val obj = JSONObject()
            obj.put("currencyCode", er.currencyCode)
            obj.put("rateToPrimary", er.rateToPrimary)
            obj.put("lastUpdated", er.lastUpdated)
            ratesArray.put(obj)
        }
        rootJson.put("exchangeRates", ratesArray)

        val jsonText = rootJson.toString(2)
        val file = File(context.filesDir, "Backup_VaraNova_${now}.json")
        file.writeText(jsonText)

        setLastBackupTimestamp(context, now)

        dao.insertAuditLog(
            AuditLogEntity(
                entityType = "BACKUP",
                entityId = now,
                action = "EXPORT",
                details = "Backup JSON generado en ${file.name} con ${rooms.size} habs, ${reservations.size} reservas, ${expenses.size} gastos."
            )
        )

        return Pair(file, jsonText)
    }

    suspend fun restoreBackupFromJson(context: Context, dao: HostalDao, jsonText: String): Boolean {
        return try {
            val root = JSONObject(jsonText)
            if (!root.has("appName") || !root.getString("appName").contains("Hostal", ignoreCase = true)) {
                return false
            }

            // Clear existing data
            dao.clearReservations()
            dao.clearRooms()
            dao.clearGuests()
            dao.clearPayments()
            dao.clearExpenses()
            dao.clearSupplyItems()
            dao.clearInventoryMovements()
            dao.clearCleaningRecords()
            dao.clearMaintenanceRecords()

            // Restore Rooms
            if (root.has("rooms")) {
                val arr = root.getJSONArray("rooms")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    dao.insertRoom(
                        RoomEntity(
                            id = obj.optLong("id", 0L),
                            name = obj.getString("name"),
                            description = obj.optString("description", ""),
                            capacity = obj.optInt("capacity", 2),
                            pricePerNight = obj.optDouble("pricePerNight", 30.0),
                            currency = obj.optString("currency", "USD"),
                            status = obj.optString("status", RoomEntity.ROOM_STATUS_AVAILABLE),
                            roomType = obj.optString("roomType", RoomType.DOUBLE.code),
                            isEntireProperty = obj.optBoolean("isEntireProperty", false),
                            features = obj.optString("features", ""),
                            notes = obj.optString("notes", "")
                        )
                    )
                }
            }

            // Restore Guests
            if (root.has("guests")) {
                val arr = root.getJSONArray("guests")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    dao.insertGuest(
                        GuestEntity(
                            id = obj.optLong("id", 0L),
                            name = obj.getString("name"),
                            phone = obj.optString("phone", ""),
                            nationality = obj.optString("nationality", ""),
                            documentId = obj.optString("documentId", ""),
                            notes = obj.optString("notes", ""),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            // Restore Reservations
            if (root.has("reservations")) {
                val arr = root.getJSONArray("reservations")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    dao.insertReservation(
                        ReservationEntity(
                            id = obj.optLong("id", 0L),
                            guestId = obj.getLong("guestId"),
                            roomId = obj.getLong("roomId"),
                            checkInDate = obj.getLong("checkInDate"),
                            checkOutDate = obj.getLong("checkOutDate"),
                            checkInTime = obj.optString("checkInTime", "14:00"),
                            checkOutTime = obj.optString("checkOutTime", "11:00"),
                            guestCount = obj.optInt("guestCount", 1),
                            pricePerNight = obj.optDouble("pricePerNight", 0.0),
                            totalPrice = obj.optDouble("totalPrice", 0.0),
                            advancePayment = obj.optDouble("advancePayment", 0.0),
                            currency = obj.optString("currency", "USD"),
                            status = obj.optString("status", ReservationEntity.STATUS_CONFIRMED),
                            notes = obj.optString("notes", ""),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            // Restore Payments
            if (root.has("payments")) {
                val arr = root.getJSONArray("payments")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    dao.insertPayment(
                        PaymentEntity(
                            id = obj.optLong("id", 0L),
                            reservationId = obj.getLong("reservationId"),
                            amount = obj.getDouble("amount"),
                            currency = obj.optString("currency", "USD"),
                            exchangeRateToPrimary = obj.optDouble("exchangeRateToPrimary", 1.0),
                            date = obj.optLong("date", System.currentTimeMillis()),
                            paymentType = obj.optString("paymentType", "Adelanto"),
                            notes = obj.optString("notes", "")
                        )
                    )
                }
            }

            // Restore Expenses
            if (root.has("expenses")) {
                val arr = root.getJSONArray("expenses")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    dao.insertExpense(
                        ExpenseEntity(
                            id = obj.optLong("id", 0L),
                            date = obj.optLong("date", System.currentTimeMillis()),
                            categoryName = obj.getString("categoryName"),
                            description = obj.optString("description", ""),
                            amount = obj.getDouble("amount"),
                            currency = obj.optString("currency", "USD"),
                            exchangeRateToPrimary = obj.optDouble("exchangeRateToPrimary", 1.0),
                            roomId = if (obj.isNull("roomId")) null else obj.optLong("roomId"),
                            reservationId = if (obj.isNull("reservationId")) null else obj.optLong("reservationId"),
                            supplier = if (obj.isNull("supplier")) null else obj.optString("supplier"),
                            notes = obj.optString("notes", "")
                        )
                    )
                }
            }

            // Restore Supplies
            if (root.has("supplyItems")) {
                val arr = root.getJSONArray("supplyItems")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    dao.insertSupplyItem(
                        SupplyItemEntity(
                            id = obj.optLong("id", 0L),
                            name = obj.getString("name"),
                            category = obj.optString("category", "Limpieza"),
                            unit = obj.optString("unit", "Unidad"),
                            currentStock = obj.optDouble("currentStock", 0.0),
                            minStock = obj.optDouble("minStock", 5.0),
                            lastPurchasePrice = obj.optDouble("lastPurchasePrice", 0.0),
                            currency = obj.optString("currency", "USD"),
                            supplier = if (obj.isNull("supplier")) null else obj.optString("supplier"),
                            lastPurchaseDate = obj.optLong("lastPurchaseDate", System.currentTimeMillis())
                        )
                    )
                }
            }

            // Restore Maintenance
            if (root.has("maintenanceRecords")) {
                val arr = root.getJSONArray("maintenanceRecords")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    dao.insertMaintenanceRecord(
                        MaintenanceRecordEntity(
                            id = obj.optLong("id", 0L),
                            roomId = obj.getLong("roomId"),
                            issue = obj.getString("issue"),
                            priority = obj.optString("priority", MaintenanceRecordEntity.PRIORITY_MEDIUM),
                            status = obj.optString("status", MaintenanceRecordEntity.STATUS_PENDING),
                            cost = obj.optDouble("cost", 0.0),
                            currency = obj.optString("currency", "USD"),
                            technician = if (obj.isNull("technician")) null else obj.optString("technician"),
                            reportedDate = obj.optLong("reportedDate", System.currentTimeMillis()),
                            resolvedDate = if (obj.isNull("resolvedDate")) null else obj.optLong("resolvedDate"),
                            notes = obj.optString("notes", "")
                        )
                    )
                }
            }

            // Update backup timestamp
            setLastBackupTimestamp(context, System.currentTimeMillis())

            dao.insertAuditLog(
                AuditLogEntity(
                    entityType = "BACKUP",
                    entityId = System.currentTimeMillis(),
                    action = "RESTORE",
                    details = "Base de datos restaurada exitosamente desde JSON de respaldo."
                )
            )

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun shareBackupFile(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "Compartir Copia de Seguridad Hostal")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    fun shareToGoogleDrive(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val driveIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Respaldo_VaraNova_Hostal.json")
            putExtra(Intent.EXTRA_TEXT, "Copia de seguridad local de base de datos VaraNova Hostal.")
            setPackage("com.google.android.apps.docs")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            driveIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(driveIntent)
        } catch (e: Exception) {
            val fallbackIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Respaldo_VaraNova_Hostal.json")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(fallbackIntent, "Guardar en Google Drive / Nube")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        }
    }
}
