package com.example.varanova.data.dao

import androidx.room.*
import com.example.varanova.data.model.SupplyItemEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO para la gestión del inventario y suministros del hostal,
 * soportando alertas de stock mínimo y reabastecimiento rápido.
 */
@Dao
interface SuministroDao {

    @Query("SELECT * FROM supply_items ORDER BY name ASC")
    fun getAllSuministros(): Flow<List<SupplyItemEntity>>

    @Query("SELECT * FROM supply_items WHERE currentStock <= minStock ORDER BY currentStock ASC")
    fun getLowStockSuministros(): Flow<List<SupplyItemEntity>>

    @Query("SELECT * FROM supply_items WHERE id = :id")
    suspend fun getSuministroById(id: Long): SupplyItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSuministro(suministro: SupplyItemEntity): Long

    @Update
    suspend fun updateSuministro(suministro: SupplyItemEntity)

    @Delete
    suspend fun deleteSuministro(suministro: SupplyItemEntity)

    @Query("UPDATE supply_items SET currentStock = :newStock WHERE id = :id")
    suspend fun updateStock(id: Long, newStock: Double)
}
