package com.example.varanova.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.varanova.ui.components.SectionHeader
import com.example.varanova.ui.components.StatCard
import com.example.ui.theme.*
import com.example.varanova.ui.viewmodel.HostalViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatisticsScreen(
    viewModel: HostalViewModel
) {
    val context = LocalContext.current
    val roomProfitabilityList by viewModel.roomProfitabilityList.collectAsStateWithLifecycle()
    val finSummary by viewModel.financialSummary.collectAsStateWithLifecycle()
    val expenses by viewModel.expenses.collectAsStateWithLifecycle()

    val mostProfitableRoom = remember(roomProfitabilityList) {
        roomProfitabilityList.maxByOrNull { it.netProfit }
    }

    val mostOccupiedRoom = remember(roomProfitabilityList) {
        roomProfitabilityList.maxByOrNull { it.totalNightsOccupied }
    }

    val expensesByCategory = remember(expenses) {
        expenses.groupBy { it.categoryName }.mapValues { entry -> entry.value.sumOf { it.amount } }
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { viewModel.exportReportCsv(context) },
                icon = { Icon(Icons.Default.Share, contentDescription = "Exportar Reporte") },
                text = { Text("Exportar CSV", fontWeight = FontWeight.Bold) },
                containerColor = TealPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_export_report")
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SectionHeader(
                    title = "Estadísticas y Rentabilidad",
                    subtitle = "Análisis completo de la salud de tu negocio"
                )
            }

            // Top Highlights
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    StatCard(
                        title = "Ingresos Totales",
                        value = "$${finSummary.totalIncomePeriod.toInt()}",
                        subtitle = "Cobros realizados",
                        icon = Icons.Default.TrendingUp,
                        containerColor = StatusAvailable.copy(alpha = 0.15f),
                        contentColor = StatusAvailable,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Gastos Totales",
                        value = "$${finSummary.totalExpensesPeriod.toInt()}",
                        subtitle = "Costos operativos",
                        icon = Icons.Default.TrendingDown,
                        containerColor = StatusOccupied.copy(alpha = 0.15f),
                        contentColor = StatusOccupied,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Best Performers
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = TealPrimaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("⭐ DESTACADOS DE TU HOSTAL", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TealPrimary)
                        Spacer(modifier = Modifier.height(8.dp))
                        if (mostProfitableRoom != null) {
                            Text(
                                text = "🥇 Habitación Más Rentable: ${mostProfitableRoom.room.name} ($${mostProfitableRoom.netProfit.toInt()} ganancia)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        if (mostOccupiedRoom != null) {
                            Text(
                                text = "🏨 Habitación Más Ocupada: ${mostOccupiedRoom.room.name} (${mostOccupiedRoom.totalNightsOccupied} noches reservadas)",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Room Rentability Breakdown
            item {
                Text("RENTABILIDAD POR HABITACIÓN", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            items(roomProfitabilityList) { prof ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(prof.room.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("${prof.totalReservationsCount} reservas", fontSize = 12.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("INGRESOS", fontSize = 10.sp, color = Color.Gray)
                                Text("$${prof.totalIncome.toInt()}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = StatusAvailable)
                            }
                            Column {
                                Text("GASTOS", fontSize = 10.sp, color = Color.Gray)
                                Text("$${prof.totalExpenses.toInt()}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = StatusOccupied)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("GANANCIA REAL", fontSize = 10.sp, color = Color.Gray)
                                Text("$${prof.netProfit.toInt()}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TealPrimary)
                            }
                        }
                    }
                }
            }

            // Expenses by Category
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text("GASTOS POR CATEGORÍA", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            items(expensesByCategory.toList()) { (cat, total) ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(cat, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("$${total.toInt()}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = StatusOccupied)
                    }
                }
            }
        }
    }
}
