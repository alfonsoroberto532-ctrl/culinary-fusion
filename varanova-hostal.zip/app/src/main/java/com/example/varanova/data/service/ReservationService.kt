package com.example.varanova.data.service

import com.example.varanova.data.dao.HostalDao
import com.example.varanova.data.model.*
import kotlinx.coroutines.flow.*

class ReservationService(
    private val dao: HostalDao,
    private val roomService: RoomService
) {

    val allReservations: Flow<List<ReservationEntity>> = dao.getAllReservations()

    suspend fun getReservationById(id: Long): ReservationEntity? {
        return dao.getReservationById(id)
    }

    fun getReservationsForRoom(roomId: Long): Flow<List<ReservationEntity>> {
        return dao.getReservationsForRoom(roomId)
    }

    fun getPaymentsForReservation(reservationId: Long): Flow<List<PaymentEntity>> {
        return dao.getPaymentsForReservation(reservationId)
    }

    fun getReservationsWithDetails(
        guestsFlow: Flow<List<GuestEntity>>,
        roomsFlow: Flow<List<RoomEntity>>,
        paymentsFlow: Flow<List<PaymentEntity>>,
        expensesFlow: Flow<List<ExpenseEntity>>
    ): Flow<List<ReservationWithDetails>> {
        return combine(
            allReservations,
            guestsFlow,
            roomsFlow,
            paymentsFlow,
            expensesFlow
        ) { reservations, guests, rooms, payments, expenses ->
            val guestMap = guests.associateBy { it.id }
            val roomMap = rooms.associateBy { it.id }
            val paymentGroup = payments.groupBy { it.reservationId }
            val expenseGroup = expenses.filter { it.reservationId != null }.groupBy { it.reservationId }

            reservations.mapNotNull { res ->
                val guest = guestMap[res.guestId] ?: return@mapNotNull null
                val room = roomMap[res.roomId] ?: return@mapNotNull null
                ReservationWithDetails(
                    reservation = res,
                    guest = guest,
                    room = room,
                    payments = paymentGroup[res.id] ?: emptyList(),
                    relatedExpenses = expenseGroup[res.id] ?: emptyList()
                )
            }
        }
    }

    suspend fun checkDateConflict(
        roomId: Long,
        checkInDate: Long,
        checkOutDate: Long,
        excludeReservationId: Long = 0
    ): Boolean {
        val reservations = dao.getAllReservations().first()
        return com.example.data.utils.ValidationUtils.hasEntityReservationConflict(
            roomId = roomId,
            checkInDate = checkInDate,
            checkOutDate = checkOutDate,
            existingReservations = reservations,
            excludeReservationId = excludeReservationId
        )
    }

    suspend fun saveReservation(reservation: ReservationEntity): Long {
        val isNew = reservation.id == 0L
        val resId = if (isNew) {
            val newId = dao.insertReservation(reservation)
            if (reservation.advancePayment > 0) {
                dao.insertPayment(
                    PaymentEntity(
                        reservationId = newId,
                        amount = reservation.advancePayment,
                        currency = reservation.currency,
                        paymentType = "Adelanto",
                        notes = "Adelanto al crear reserva"
                    )
                )
            }
            dao.insertAuditLog(
                AuditLogEntity(
                    entityType = "RESERVATION",
                    entityId = newId,
                    action = "CREATE",
                    details = "Reserva #$newId creada (${reservation.totalPrice} ${reservation.currency})"
                )
            )
            newId
        } else {
            dao.updateReservation(reservation)
            dao.insertAuditLog(
                AuditLogEntity(
                    entityType = "RESERVATION",
                    entityId = reservation.id,
                    action = "UPDATE",
                    details = "Reserva #${reservation.id} modificada"
                )
            )
            reservation.id
        }

        updateRoomStatusForReservation(reservation)
        return resId
    }

    suspend fun updateRoomStatusForReservation(reservation: ReservationEntity) {
        val room = dao.getRoomById(reservation.roomId) ?: return
        val now = System.currentTimeMillis()

        val newStatus = when (reservation.status) {
            ReservationEntity.STATUS_CHECKED_IN -> RoomEntity.ROOM_STATUS_OCCUPIED
            ReservationEntity.STATUS_CHECKED_OUT -> RoomEntity.ROOM_STATUS_CLEANING_PENDING
            ReservationEntity.STATUS_CONFIRMED -> {
                if (now in reservation.checkInDate..reservation.checkOutDate) RoomEntity.ROOM_STATUS_RESERVED
                else room.status
            }
            else -> room.status
        }

        if (room.status != newStatus && room.status != RoomEntity.ROOM_STATUS_MAINTENANCE) {
            roomService.updateRoomStatus(reservation.roomId, newStatus)
        }
    }

    suspend fun deleteReservation(reservation: ReservationEntity) {
        dao.deleteReservation(reservation)
        dao.insertAuditLog(
            AuditLogEntity(
                entityType = "RESERVATION",
                entityId = reservation.id,
                action = "DELETE",
                details = "Reserva #${reservation.id} eliminada"
            )
        )
    }

    suspend fun addPayment(payment: PaymentEntity): Long {
        val id = dao.insertPayment(payment)
        dao.insertAuditLog(
            AuditLogEntity(
                entityType = "PAYMENT",
                entityId = id,
                action = "CREATE",
                details = "Pago de ${payment.amount} ${payment.currency} registrado"
            )
        )
        return id
    }
}
