package com.example.varanova.data.repository

import com.example.varanova.data.dao.HostalDao
import com.example.varanova.data.dao.RoomDao
import com.example.varanova.data.model.*
import com.example.varanova.data.service.RoomService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.*

/**
 * Repository class responsible for managing Room data operations.
 * Bridges the gap between the [RoomDao] / [RoomService] and the application's UI / business logic layer.
 * Exposes data as reactive [StateFlow] streams for offline-first state observation.
 */
class RoomRepository(
    private val roomDao: RoomDao,
    private val roomService: RoomService? = (roomDao as? HostalDao)?.let { RoomService(it) },
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) {

    /**
     * StateFlow emitting the list of all rooms ordered by name.
     * Maintains offline-first cached state for immediate subscriber read.
     */
    val allRooms: StateFlow<List<RoomEntity>> = roomDao.getAllRooms()
        .stateIn(
            scope = scope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val roomsState: StateFlow<List<RoomEntity>> = allRooms

    /**
     * Retrieves rooms filtered by their current status.
     */
    fun getRoomsByStatus(status: String): Flow<List<RoomEntity>> {
        return roomDao.getRoomsByStatus(status)
    }

    /**
     * Fetches a specific room by its unique ID asynchronously.
     */
    suspend fun getRoomById(id: Long): RoomEntity? {
        return roomDao.getRoomById(id)
    }

    /**
     * Inserts a new room into the database directly.
     */
    suspend fun insertRoom(room: RoomEntity): Long {
        return roomDao.insertRoom(room)
    }

    /**
     * Updates an existing room record directly.
     */
    suspend fun updateRoom(room: RoomEntity) {
        roomDao.updateRoom(room)
    }

    /**
     * Saves a room entity (insert if new, update if exists) and records an audit log entry.
     */
    suspend fun saveRoom(room: RoomEntity): Long {
        return roomService?.saveRoom(room) ?: run {
            if (room.id == 0L) {
                roomDao.insertRoom(room)
            } else {
                roomDao.updateRoom(room)
                room.id
            }
        }
    }

    /**
     * Deletes a room and logs the deletion action.
     */
    suspend fun deleteRoom(room: RoomEntity) {
        if (roomService != null) {
            roomService.deleteRoom(room)
        } else {
            roomDao.deleteRoom(room)
        }
    }

    /**
     * Updates the status of a room (e.g., AVAILABLE, OCCUPIED, CLEANING_PENDING) and logs the change.
     */
    suspend fun updateRoomStatus(roomId: Long, newStatus: String) {
        if (roomService != null) {
            roomService.updateRoomStatus(roomId, newStatus)
        } else {
            val room = roomDao.getRoomById(roomId)
            if (room != null && room.status != newStatus) {
                roomDao.updateRoom(room.copy(status = newStatus))
            }
        }
    }

    /**
     * Records a cleaning event for a room and marks it as available.
     */
    suspend fun recordCleaning(roomId: Long, productsUsed: String, notes: String) {
        roomService?.recordCleaning(roomId, productsUsed, notes)
    }

    /**
     * Records a maintenance request for a room, optionally blocking the room and registering an expense.
     */
    suspend fun recordMaintenance(
        roomId: Long,
        issue: String,
        priority: String,
        cost: Double = 0.0,
        technician: String? = null,
        notes: String = "",
        blockRoom: Boolean = true
    ) {
        roomService?.recordMaintenance(roomId, issue, priority, cost, technician, notes, blockRoom)
    }

    suspend fun resolveMaintenance(record: MaintenanceRecordEntity) {
        roomService?.resolveMaintenance(record)
    }

    /**
     * Clears all room entries from local storage.
     */
    suspend fun clearRooms() {
        roomDao.clearRooms()
    }
}
