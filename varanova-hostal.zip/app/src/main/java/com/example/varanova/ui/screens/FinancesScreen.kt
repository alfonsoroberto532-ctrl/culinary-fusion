package com.example.varanova.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.varanova.data.model.ExpenseEntity
import com.example.varanova.data.model.PaymentEntity
import com.example.varanova.data.model.RoomEntity
import com.example.varanova.ui.components.SectionHeader
import com.example.varanova.ui.components.StatCard
import com.example.ui.theme.*
import com.example.varanova.ui.viewmodel.HostalViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinancesScreen(
    viewModel: HostalViewModel,
    initialOpenExpense: Boolean = false
) {
    val context = LocalContext.current
    val finSummary by viewModel.financialSummary.collectAsStateWithLifecycle()
    val expenses by viewModel.expenses.collectAsStateWithLifecycle()
    val payments by viewModel.payments.collectAsStateWithLifecycle()
    val rooms by viewModel.rooms.collectAsStateWithLifecycle()
    val exchangeRates by viewModel.exchangeRates.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Gastos, 1: Cobros, 2: Gráficos, 3: Tasas Cambio
    var showAddExpenseDialog by remember { mutableStateOf(initialOpenExpense) }
    var showExportOptions by remember { mutableStateOf(false) }

    val sdf = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    Scaffold(
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (showExportOptions) {
                    SmallFloatingActionButton(
                        onClick = {
                            viewModel.exportReportCsv(context)
                            showExportOptions = false
                        },
                        containerColor = TealPrimaryContainer,
                        contentColor = TealPrimary,
                        modifier = Modifier.testTag("fab_export_csv")
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FileDownload, contentDescription = "Exportar CSV")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("CSV", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    SmallFloatingActionButton(
                        onClick = {
                            viewModel.generateBackupJson(context, shareAfter = true)
                            showExportOptions = false
                        },
                        containerColor = AmberSecondaryContainer,
                        contentColor = AmberSecondary,
                        modifier = Modifier.testTag("fab_export_json")
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SaveAlt, contentDescription = "Exportar JSON")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("JSON", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FloatingActionButton(
                        onClick = { showExportOptions = !showExportOptions },
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.testTag("fab_toggle_export")
                    ) {
                        Icon(
                            imageVector = if (showExportOptions) Icons.Default.Close else Icons.Default.IosShare,
                            contentDescription = "Exportar Reportes"
                        )
                    }

                    ExtendedFloatingActionButton(
                        onClick = { showAddExpenseDialog = true },
                        icon = { Icon(Icons.Default.MoneyOff, contentDescription = "Registrar Gasto") },
                        text = { Text("Registrar Gasto", fontWeight = FontWeight.Bold) },
                        containerColor = StatusOccupied,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("fab_add_expense")
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            SectionHeader(title = "Finanzas del Hostal", subtitle = "Control de cobros, gastos y multimoneda")

            // Top Financial Overview Cards
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                StatCard(
                    title = "Total Cobrado",
                    value = "$${finSummary.totalIncomePeriod.toInt()}",
                    subtitle = "Ingreso realizado",
                    icon = Icons.Default.AccountBalanceWallet,
                    containerColor = StatusAvailable.copy(alpha = 0.15f),
                    contentColor = StatusAvailable,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Pendiente Cobrar",
                    value = "$${finSummary.pendingToCollect.toInt()}",
                    subtitle = "Cuentas activas",
                    icon = Icons.Default.AttachMoney,
                    containerColor = AmberSecondaryContainer,
                    contentColor = AmberSecondary,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                StatCard(
                    title = "Total Gastos",
                    value = "$${finSummary.totalExpensesPeriod.toInt()}",
                    subtitle = "Suministros y operacion",
                    icon = Icons.Default.ReceiptLong,
                    containerColor = StatusOccupied.copy(alpha = 0.15f),
                    contentColor = StatusOccupied,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Ganancia Neta",
                    value = "$${finSummary.netProfitPeriod.toInt()}",
                    subtitle = "Cobrado - Gastos",
                    icon = Icons.Default.TrendingUp,
                    containerColor = TealPrimaryContainer,
                    contentColor = TealPrimary,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(selected = selectedTabIndex == 0, onClick = { selectedTabIndex = 0 }, text = { Text("Gastos", fontWeight = FontWeight.Bold, fontSize = 12.sp) })
                Tab(selected = selectedTabIndex == 1, onClick = { selectedTabIndex = 1 }, text = { Text("Cobros", fontWeight = FontWeight.Bold, fontSize = 12.sp) })
                Tab(selected = selectedTabIndex == 2, onClick = { selectedTabIndex = 2 }, text = { Text("Gráficos", fontWeight = FontWeight.Bold, fontSize = 12.sp) })
                Tab(selected = selectedTabIndex == 3, onClick = { selectedTabIndex = 3 }, text = { Text("Tasas", fontWeight = FontWeight.Bold, fontSize = 12.sp) })
            }

            Spacer(modifier = Modifier.height(12.dp))

            when (selectedTabIndex) {
                0 -> {
                    // EXPENSES LIST
                    if (expenses.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No hay gastos registrados. Toca el botón para agregar uno.")
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                            items(expenses) { expense ->
                                ExpenseCard(expense = expense, sdf = sdf)
                            }
                        }
                    }
                }
                1 -> {
                    // PAYMENTS LIST
                    if (payments.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No hay cobros registrados.")
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                            items(payments) { pay ->
                                PaymentCard(payment = pay, sdf = sdf)
                            }
                        }
                    }
                }
                2 -> {
                    // CHARTS & ANALYTICS
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(bottom = 90.dp)
                    ) {
                        item {
                            DailyRevenueBarChart(payments = payments)
                        }
                        item {
                            ExpenseCategoryBreakdownChart(expenses = expenses)
                        }
                    }
                }
                3 -> {
                    // MULTICURRENCY & EXCHANGE RATES
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                        item {
                            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("💱 Configuración Multimoneda", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("Soporta CUP, USD, EUR, CAD y otras monedas con cálculo exacto sin perder los valores originales.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        items(exchangeRates) { rate ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(rate.currencyCode, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                        Text("1 USD = ${rate.rateToPrimary} ${rate.currencyCode}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    var editableRate by remember(rate) { mutableStateOf(rate.rateToPrimary.toString()) }
                                    OutlinedTextField(
                                        value = editableRate,
                                        onValueChange = {
                                            editableRate = it
                                            val d = it.toDoubleOrNull()
                                            if (d != null && d > 0) {
                                                viewModel.updateExchangeRate(rate.currencyCode, d)
                                            }
                                        },
                                        modifier = Modifier.width(110.dp),
                                        label = { Text("Tasa") }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddExpenseDialog) {
        ModalBottomSheet(
            onDismissRequest = { showAddExpenseDialog = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            ExpenseBottomSheetContent(
                rooms = rooms,
                onDismiss = { showAddExpenseDialog = false },
                onSave = { cat, desc, amount, curr, roomId ->
                    viewModel.addExpense(cat, desc, amount, curr, roomId)
                    showAddExpenseDialog = false
                }
            )
        }
    }
}

@Composable
private fun DailyRevenueBarChart(payments: List<PaymentEntity>) {
    val dayNames = listOf("Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb")
    val cal = Calendar.getInstance()

    // Calculate daily totals for last 7 days
    val dailyData = remember(payments) {
        val list = mutableListOf<Pair<String, Double>>()
        val today = Calendar.getInstance()
        today.set(Calendar.HOUR_OF_DAY, 0)
        today.set(Calendar.MINUTE, 0)
        today.set(Calendar.SECOND, 0)
        today.set(Calendar.MILLISECOND, 0)

        for (i in 6 downTo 0) {
            val dayStart = today.timeInMillis - (i * 86400000L)
            val dayEnd = dayStart + 86400000L

            cal.timeInMillis = dayStart
            val dayName = dayNames[cal.get(Calendar.DAY_OF_WEEK) - 1]

            val sum = payments.filter { it.date in dayStart until dayEnd }.sumOf { it.amount }
            list.add(dayName to sum)
        }
        list
    }

    val maxVal = remember(dailyData) { (dailyData.maxOfOrNull { it.second } ?: 100.0).coerceAtLeast(50.0) }
    val barColor = StatusAvailable

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📊 Tendencia de Ingresos Diarios (7 Días)",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Total: $${dailyData.sumOf { it.second }.toInt()}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = StatusAvailable
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height - 30.dp.toPx()
                val barWidth = (canvasWidth / dailyData.size) * 0.55f
                val spacing = canvasWidth / dailyData.size

                dailyData.forEachIndexed { index, (dayName, value) ->
                    val barHeight = ((value / maxVal) * canvasHeight).toFloat().coerceAtLeast(6.dp.toPx())
                    val x = index * spacing + (spacing - barWidth) / 2
                    val y = canvasHeight - barHeight

                    // Draw bar
                    drawRoundRect(
                        color = barColor,
                        topLeft = Offset(x, y),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                dailyData.forEach { (dayName, value) ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (value > 0) "$${value.toInt()}" else "$0",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (value > 0) StatusAvailable else Color.Gray
                        )
                        Text(
                            text = dayName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ExpenseCategoryBreakdownChart(expenses: List<ExpenseEntity>) {
    val categoryTotals = remember(expenses) {
        expenses.groupBy { it.categoryName }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
            .toList()
            .sortedByDescending { it.second }
    }

    val totalExpense = remember(categoryTotals) { categoryTotals.sumOf { it.second }.coerceAtLeast(1.0) }
    val colors = listOf(
        StatusOccupied, TealPrimary, AmberSecondary, StatusReserved, StatusAvailable,
        Color(0xFF9C27B0), Color(0xFF3F51B5), Color(0xFFFF9800)
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "📉 Desglose Mensual de Gastos por Categoría",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (categoryTotals.isEmpty()) {
                Text("No hay registros de gastos para visualizar.", fontSize = 12.sp, color = Color.Gray)
            } else {
                // Segmented Progress Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(16.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    categoryTotals.forEachIndexed { index, (cat, amount) ->
                        val weight = (amount / totalExpense).toFloat().coerceAtLeast(0.02f)
                        Box(
                            modifier = Modifier
                                .weight(weight)
                                .fillMaxHeight()
                                .background(colors[index % colors.size])
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Category List
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    categoryTotals.forEachIndexed { index, (cat, amount) ->
                        val percent = ((amount / totalExpense) * 100).toInt()
                        val color = colors[index % colors.size]

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(color, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(cat, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }

                            Text(
                                text = "$${amount.toInt()} ($percent%)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = color
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExpenseCard(expense: ExpenseEntity, sdf: SimpleDateFormat) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(StatusOccupied.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = StatusOccupied, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(expense.description, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Categoría: ${expense.categoryName} • ${sdf.format(Date(expense.date))}", fontSize = 11.sp, color = Color.Gray)
                }
            }
            Text("-$${expense.amount.toInt()} ${expense.currency}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = StatusOccupied)
        }
    }
}

@Composable
private fun PaymentCard(payment: PaymentEntity, sdf: SimpleDateFormat) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(StatusAvailable.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.AttachMoney, contentDescription = null, tint = StatusAvailable, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("${payment.paymentType} Reserva #${payment.reservationId}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text(sdf.format(Date(payment.date)), fontSize = 11.sp, color = Color.Gray)
                }
            }
            Text("+$${payment.amount.toInt()} ${payment.currency}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = StatusAvailable)
        }
    }
}

@Composable
private fun ExpenseBottomSheetContent(
    rooms: List<RoomEntity>,
    onDismiss: () -> Unit,
    onSave: (String, String, Double, String, Long?) -> Unit
) {
    var category by remember { mutableStateOf("Papel sanitario") }
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("USD") }
    var selectedRoomId by remember { mutableStateOf<Long?>(null) }

    val categories = listOf(
        "Jabón", "Detergente", "Papel sanitario", "Champú", "Pasta dental",
        "Electricidad", "Agua", "Gas", "Reparaciones", "Mantenimiento",
        "Lavandería", "Comida/desayuno", "Transporte", "Comisión", "Otros"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(StatusOccupied.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = StatusOccupied, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("Registro Rápido de Gastos", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Ingreso inmediato sin salir del resumen", fontSize = 11.sp, color = Color.Gray)
                }
            }
            IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "Cerrar")
            }
        }

        Divider()

        Text("Categoría de Gasto", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        DropdownMenuBox(
            options = categories,
            selectedIndex = categories.indexOf(category).coerceAtLeast(0),
            onSelect = { idx -> category = categories[idx] }
        )

        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Descripción o Concepto") },
            placeholder = { Text("ej. Compra urgente de bombillos") },
            modifier = Modifier.fillMaxWidth().testTag("input_expense_desc")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                label = { Text("Importe") },
                placeholder = { Text("0.00") },
                modifier = Modifier.weight(1f).testTag("input_expense_amount")
            )

            Box(modifier = Modifier.width(100.dp)) {
                DropdownMenuBox(
                    options = listOf("USD", "CUP", "EUR", "CAD"),
                    selectedIndex = listOf("USD", "CUP", "EUR", "CAD").indexOf(currency).coerceAtLeast(0),
                    onSelect = { idx -> currency = listOf("USD", "CUP", "EUR", "CAD")[idx] }
                )
            }
        }

        Text("Habitación Relacionada (Opcional)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        DropdownMenuBox(
            options = listOf("Gasto General (Sin habitación)") + rooms.map { it.name },
            selectedIndex = if (selectedRoomId == null) 0 else rooms.indexOfFirst { it.id == selectedRoomId } + 1,
            onSelect = { idx -> selectedRoomId = if (idx == 0) null else rooms[idx - 1].id }
        )

        Spacer(modifier = Modifier.height(6.dp))

        Button(
            onClick = {
                val amt = amount.toDoubleOrNull() ?: 0.0
                if (amt > 0 && description.isNotBlank()) {
                    onSave(category, description, amt, currency, selectedRoomId)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = StatusOccupied),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("save_expense_btn")
        ) {
            Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Guardar Gasto Rápido", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DropdownMenuBox(options: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(options.getOrElse(selectedIndex) { "Seleccionar" })
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEachIndexed { idx, item ->
                DropdownMenuItem(text = { Text(item) }, onClick = { onSelect(idx); expanded = false })
            }
        }
    }
}
