package com.example.varanova.data.model

data class ReservationWithDetails(
    val reservation: ReservationEntity,
    val guest: GuestEntity,
    val room: RoomEntity,
    val payments: List<PaymentEntity> = emptyList(),
    val relatedExpenses: List<ExpenseEntity> = emptyList()
) {
    val nights: Int
        get() {
            val diffMs = reservation.checkOutDate - reservation.checkInDate
            val days = (diffMs / (1000 * 60 * 60 * 24)).toInt()
            return if (days > 0) days else 1
        }

    val totalPaid: Double
        get() = payments.sumOf { it.amount }

    val pendingBalance: Double
        get() {
            val pending = reservation.totalPrice - totalPaid
            return if (pending > 0) pending else 0.0
        }

    val relatedExpensesTotal: Double
        get() = relatedExpenses.sumOf { it.amount }

    val netProfit: Double
        get() = reservation.totalPrice - relatedExpensesTotal

    val profitMarginPercent: Double
        get() = if (reservation.totalPrice > 0) (netProfit / reservation.totalPrice) * 100 else 0.0
}

data class PrimarySmartAction(
    val id: String,
    val title: String,
    val description: String,
    val badgeText: String,
    val actionLabel: String,
    val iconName: String,
    val actionType: SmartDashboardAlert.ActionType,
    val entityId: Long? = null,
    val amount: Double = 0.0,
    val currency: String = "USD"
)

data class OccupancyDayForecast(
    val dayName: String,
    val dateLabel: String,
    val timestamp: Long,
    val occupiedRooms: Int,
    val totalRooms: Int,
    val occupancyPercentage: Double,
    val isPeakDemand: Boolean
)

data class ParsedReservationInput(
    val guestName: String = "",
    val roomQuery: String = "",
    val nights: Int = 1,
    val estimatedPrice: Double? = null,
    val phone: String = ""
)

data class ParsedSupplyInput(
    val itemName: String = "",
    val quantity: Double = 10.0,
    val unit: String = "unidades"
)

data class RoomProfitability(
    val room: RoomEntity,
    val totalIncome: Double,
    val totalExpenses: Double,
    val netProfit: Double,
    val occupancyRatePercent: Double,
    val totalReservationsCount: Int,
    val totalNightsOccupied: Int
)

data class FinancialSummary(
    val collectedToday: Double,
    val pendingToCollect: Double,
    val expensesToday: Double,
    val estimatedProfitToday: Double,
    val totalIncomePeriod: Double,
    val totalExpensesPeriod: Double,
    val netProfitPeriod: Double,
    val primaryCurrency: String = "USD"
)

data class SmartDashboardAlert(
    val id: String,
    val title: String,
    val message: String,
    val type: AlertType, // CRITICAL, WARNING, INFO, SUCCESS
    val iconName: String,
    val targetTabRoute: String,
    val actionType: ActionType? = null,
    val actionLabel: String? = null,
    val entityId: Long? = null,
    val secondaryAmount: Double = 0.0,
    val secondaryText: String = ""
) {
    enum class AlertType {
        CRITICAL, WARNING, INFO, SUCCESS
    }

    enum class ActionType {
        QUICK_CLEAN_ROOM,
        QUICK_COLLECT_PAYMENT,
        QUICK_RESOLVE_MAINTENANCE,
        QUICK_RESTOCK_SUPPLY
    }
}
