package com.example.varanova.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.varanova.data.model.RoomEntity
import com.example.varanova.data.model.RoomProfitability
import com.example.varanova.ui.components.SectionHeader
import com.example.varanova.ui.components.StatusBadge
import com.example.ui.components.EmptyState
import com.example.ui.theme.*
import com.example.varanova.ui.viewmodel.HostalViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomsScreen(
    viewModel: HostalViewModel
) {
    val rooms by viewModel.rooms.collectAsStateWithLifecycle()
    val roomProfitabilityList by viewModel.roomProfitabilityList.collectAsStateWithLifecycle()

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedRoomForEdit by remember { mutableStateOf<RoomEntity?>(null) }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = "Nueva Habitación") },
                text = { Text("Añadir Habitación", fontWeight = FontWeight.Bold) },
                containerColor = TealPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_room")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            SectionHeader(
                title = "Habitaciones y Propiedad",
                subtitle = "${rooms.size} unidades registradas"
            )

            if (rooms.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyState(
                        title = "Sin Habitaciones",
                        message = "No hay habitaciones registradas en la propiedad. Toca el botón + para agregar una.",
                        icon = Icons.Default.MeetingRoom,
                        actionLabel = "Agregar Habitación",
                        onActionClick = { showAddDialog = true },
                        testTag = "varanova_rooms_empty_state"
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(rooms) { room ->
                        val profitability = roomProfitabilityList.find { it.room.id == room.id }
                        RoomCard(
                            room = room,
                            profitability = profitability,
                            onEdit = { selectedRoomForEdit = room },
                            onStatusChange = { newStatus -> viewModel.updateRoomStatus(room, newStatus) }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddEditRoomDialog(
            roomToEdit = null,
            onDismiss = { showAddDialog = false },
            onSave = { room ->
                viewModel.saveRoom(room)
                showAddDialog = false
            }
        )
    }

    selectedRoomForEdit?.let { room ->
        AddEditRoomDialog(
            roomToEdit = room,
            onDismiss = { selectedRoomForEdit = null },
            onSave = { updated ->
                viewModel.saveRoom(updated)
                selectedRoomForEdit = null
            },
            onDelete = {
                viewModel.deleteRoom(room)
                selectedRoomForEdit = null
            }
        )
    }
}

@Composable
private fun RoomCard(
    room: RoomEntity,
    profitability: RoomProfitability?,
    onEdit: () -> Unit,
    onStatusChange: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onEdit),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(if (room.isEntireProperty) AmberSecondaryContainer else TealPrimaryContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (room.isEntireProperty) Icons.Default.Villa else Icons.Default.Bed,
                            contentDescription = null,
                            tint = if (room.isEntireProperty) AmberSecondary else TealPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = room.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Capacidad: ${room.capacity} personas • $${room.pricePerNight.toInt()}/noche",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                StatusBadge(status = room.status)
            }

            if (room.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = room.description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(modifier = Modifier.height(12.dp))

            // RENTABILIDAD
            if (profitability != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Ingresos", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text("$${profitability.totalIncome.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = StatusAvailable)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Gastos", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text("$${profitability.totalExpenses.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = StatusOccupied)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Ganancia Real", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text("$${profitability.netProfit.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TealPrimary)
                    }
                }
            }

            // MAINTENANCE TOGGLE ROW
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (room.status == RoomEntity.ROOM_STATUS_MAINTENANCE) StatusOccupied.copy(alpha = 0.12f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "Mantenimiento",
                        tint = if (room.status == RoomEntity.ROOM_STATUS_MAINTENANCE) StatusOccupied else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Modo Mantenimiento",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (room.status == RoomEntity.ROOM_STATUS_MAINTENANCE) StatusOccupied else MaterialTheme.colorScheme.onSurface
                        )
                        if (room.status == RoomEntity.ROOM_STATUS_MAINTENANCE) {
                            Text(
                                text = "⚠️ No disponible • Reservas bloqueadas",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = StatusOccupied
                            )
                        } else {
                            Text(
                                text = "Inhabilitar para reparaciones",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Switch(
                    checked = room.status == RoomEntity.ROOM_STATUS_MAINTENANCE,
                    onCheckedChange = { isMaintenance ->
                        val newStatus = if (isMaintenance) RoomEntity.ROOM_STATUS_MAINTENANCE else RoomEntity.ROOM_STATUS_AVAILABLE
                        onStatusChange(newStatus)
                    },
                    modifier = Modifier.testTag("switch_maintenance_${room.id}")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // CAMBIO DE ESTADO
            Text("Cambiar Estado Rápido:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatusFilterChip("🟢 Disponible", room.status == RoomEntity.ROOM_STATUS_AVAILABLE) {
                    onStatusChange(RoomEntity.ROOM_STATUS_AVAILABLE)
                }
                StatusFilterChip("🔴 Ocupada", room.status == RoomEntity.ROOM_STATUS_OCCUPIED) {
                    onStatusChange(RoomEntity.ROOM_STATUS_OCCUPIED)
                }
                StatusFilterChip("🟡 Limpieza", room.status == RoomEntity.ROOM_STATUS_CLEANING_PENDING) {
                    onStatusChange(RoomEntity.ROOM_STATUS_CLEANING_PENDING)
                }
                StatusFilterChip("⚠️ Mantenimiento", room.status == RoomEntity.ROOM_STATUS_MAINTENANCE) {
                    onStatusChange(RoomEntity.ROOM_STATUS_MAINTENANCE)
                }
            }
        }
    }
}

@Composable
private fun StatusFilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = TealPrimaryContainer,
            selectedLabelColor = TealPrimary
        )
    )
}

@Composable
private fun AddEditRoomDialog(
    roomToEdit: RoomEntity?,
    onDismiss: () -> Unit,
    onSave: (RoomEntity) -> Unit,
    onDelete: (() -> Unit)? = null
) {
    var name by remember { mutableStateOf(roomToEdit?.name ?: "") }
    var description by remember { mutableStateOf(roomToEdit?.description ?: "") }
    var capacity by remember { mutableIntStateOf(roomToEdit?.capacity ?: 2) }
    var pricePerNight by remember { mutableDoubleStateOf(roomToEdit?.pricePerNight ?: 35.0) }
    var isEntireProperty by remember { mutableStateOf(roomToEdit?.isEntireProperty ?: false) }
    var features by remember { mutableStateOf(roomToEdit?.features ?: "Aire Acondicionado, Baño Privado, Wi-Fi") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (roomToEdit == null) "Agregar Habitación / Propiedad" else "Editar Habitación", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nombre (ej. Habitación 1, Casa Completa)") },
                    modifier = Modifier.fillMaxWidth().testTag("input_room_name")
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Descripción") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Alquiler de Casa Completa")
                    Switch(checked = isEntireProperty, onCheckedChange = { isEntireProperty = it })
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = capacity.toString(),
                        onValueChange = { capacity = it.toIntOrNull() ?: capacity },
                        label = { Text("Capacidad") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = pricePerNight.toString(),
                        onValueChange = { pricePerNight = it.toDoubleOrNull() ?: pricePerNight },
                        label = { Text("Precio/Noche ($)") },
                        modifier = Modifier.weight(1f).testTag("input_room_price")
                    )
                }

                OutlinedTextField(
                    value = features,
                    onValueChange = { features = it },
                    label = { Text("Características / Amenidades") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val room = roomToEdit?.copy(
                            name = name,
                            description = description,
                            capacity = capacity,
                            pricePerNight = pricePerNight,
                            isEntireProperty = isEntireProperty,
                            features = features
                        ) ?: RoomEntity(
                            name = name,
                            description = description,
                            capacity = capacity,
                            pricePerNight = pricePerNight,
                            isEntireProperty = isEntireProperty,
                            features = features
                        )
                        onSave(room)
                    }
                },
                modifier = Modifier.testTag("save_room_btn")
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text("Eliminar", color = StatusOccupied) }
                }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        }
    )
}
