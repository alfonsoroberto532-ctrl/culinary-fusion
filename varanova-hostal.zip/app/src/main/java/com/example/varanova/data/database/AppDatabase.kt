package com.example.varanova.data.database

typealias AppDatabase = com.example.data.AppDatabase

