package com.example.varanova.data.database

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Migration Utility Class to safely handle future and incremental Room schema changes
 * without data loss across version upgrades.
 */
object DatabaseMigrations {

    /**
     * Migration from version 3 to 4:
     * Adds the 'roomType' column to the 'rooms' table with a safe default value.
     */
    val MIGRATION_3_4 = object : Migration(3, 4) {
        override fun migrate(database: SupportSQLiteDatabase) {
            try {
                database.execSQL("ALTER TABLE rooms ADD COLUMN roomType TEXT NOT NULL DEFAULT 'DOUBLE'")
            } catch (e: Exception) {
                // Column might already exist or table migration fallback
                android.util.Log.w("DatabaseMigrations", "Migration 3->4 note: ${e.message}")
            }
        }
    }

    /**
     * Migration from version 1 to 2 (Legacy safeguard)
     */
    val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(database: SupportSQLiteDatabase) {
            // No-op or structural column safety
        }
    }

    /**
     * Migration from version 2 to 3 (Legacy safeguard)
     */
    val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(database: SupportSQLiteDatabase) {
            // No-op or structural column safety
        }
    }

    val ALL_MIGRATIONS = arrayOf(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
}
