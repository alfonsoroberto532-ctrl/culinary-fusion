package com.example.varanova.data.repository

import com.example.varanova.data.dao.HostalDao
import com.example.varanova.data.model.*
import com.example.varanova.data.service.ReservationService
import com.example.varanova.data.service.RoomService
import kotlinx.coroutines.flow.*
import java.util.Calendar

class HostalRepository(private val dao: HostalDao) {

    val roomService = RoomService(dao)
    val roomRepository = RoomRepository(dao, roomService)
    val reservationService = ReservationService(dao, roomService)
    val reservationRepository = ReservationRepository(dao, roomService, reservationService)

    val allRooms: Flow<List<RoomEntity>> = roomRepository.allRooms
    val allGuests: Flow<List<GuestEntity>> = dao.getAllGuests()
    val allReservations: Flow<List<ReservationEntity>> = reservationRepository.allReservations
    val allPayments: Flow<List<PaymentEntity>> = dao.getAllPayments()
    val allExpenses: Flow<List<ExpenseEntity>> = dao.getAllExpenses()
    val allExpenseCategories: Flow<List<ExpenseCategoryEntity>> = dao.getAllExpenseCategories()
    val allSupplyItems: Flow<List<SupplyItemEntity>> = dao.getAllSupplyItems()
    val allInventoryMovements: Flow<List<InventoryMovementEntity>> = dao.getAllInventoryMovements()
    val allCleaningRecords: Flow<List<CleaningRecordEntity>> = dao.getAllCleaningRecords()
    val allMaintenanceRecords: Flow<List<MaintenanceRecordEntity>> = dao.getAllMaintenanceRecords()
    val allExchangeRates: Flow<List<ExchangeRateEntity>> = dao.getAllExchangeRates()
    val allAuditLogs: Flow<List<AuditLogEntity>> = dao.getAllAuditLogs()

    // Combining reservations with details
    val reservationsWithDetails: Flow<List<ReservationWithDetails>> = reservationRepository.getReservationsWithDetails(
        allGuests,
        allRooms,
        allPayments,
        allExpenses
    )

    // Checking for overlapping reservation dates on the same room
    suspend fun checkDateConflict(
        roomId: Long,
        checkInDate: Long,
        checkOutDate: Long,
        excludeReservationId: Long = 0
    ): Boolean = reservationRepository.checkDateConflict(roomId, checkInDate, checkOutDate, excludeReservationId)

    // Room CRUD
    suspend fun saveRoom(room: RoomEntity): Long = roomRepository.saveRoom(room)

    suspend fun deleteRoom(room: RoomEntity) = roomRepository.deleteRoom(room)

    // Guest CRUD
    suspend fun saveGuest(guest: GuestEntity): Long {
        return if (guest.id == 0L) {
            dao.insertGuest(guest).also { newId ->
                dao.insertAuditLog(AuditLogEntity(entityType = "GUEST", entityId = newId, action = "CREATE", details = "Huésped ${guest.name} registrado"))
            }
        } else {
            dao.updateGuest(guest)
            dao.insertAuditLog(AuditLogEntity(entityType = "GUEST", entityId = guest.id, action = "UPDATE", details = "Huésped ${guest.name} actualizado"))
            guest.id
        }
    }

    // Reservation CRUD
    suspend fun saveReservation(reservation: ReservationEntity): Long = reservationRepository.saveReservation(reservation)

    suspend fun updateRoomStatusForReservation(reservation: ReservationEntity) = reservationRepository.updateRoomStatusForReservation(reservation)

    suspend fun deleteReservation(reservation: ReservationEntity) = reservationRepository.deleteReservation(reservation)

    // Payment Operations
    suspend fun addPayment(payment: PaymentEntity): Long = reservationRepository.addPayment(payment)

    // Expense Operations
    suspend fun addExpense(expense: ExpenseEntity): Long {
        val id = dao.insertExpense(expense)
        dao.insertAuditLog(AuditLogEntity(entityType = "EXPENSE", entityId = id, action = "CREATE", details = "Gasto ${expense.categoryName}: ${expense.amount} ${expense.currency}"))
        return id
    }

    // Inventory Operations
    suspend fun saveSupplyItem(item: SupplyItemEntity): Long {
        return if (item.id == 0L) {
            dao.insertSupplyItem(item).also { newId ->
                dao.insertAuditLog(AuditLogEntity(entityType = "INVENTORY", entityId = newId, action = "CREATE", details = "Suministro ${item.name} creado"))
            }
        } else {
            dao.updateSupplyItem(item)
            dao.insertAuditLog(AuditLogEntity(entityType = "INVENTORY", entityId = item.id, action = "UPDATE", details = "Suministro ${item.name} actualizado"))
            item.id
        }
    }

    suspend fun recordInventoryMovement(
        supplyItemId: Long,
        movementType: String,
        quantity: Double,
        roomId: Long? = null,
        reservationId: Long? = null,
        notes: String = ""
    ) {
        val item = dao.getSupplyItemById(supplyItemId) ?: return
        val newStock = when (movementType) {
            InventoryMovementEntity.TYPE_PURCHASE -> item.currentStock + quantity
            InventoryMovementEntity.TYPE_CONSUMPTION, InventoryMovementEntity.TYPE_WASTE -> item.currentStock - quantity
            InventoryMovementEntity.TYPE_ADJUSTMENT -> quantity
            else -> item.currentStock
        }

        val updatedStock = if (newStock < 0) 0.0 else newStock
        dao.updateSupplyItem(item.copy(currentStock = updatedStock, lastPurchaseDate = System.currentTimeMillis()))

        dao.insertInventoryMovement(
            InventoryMovementEntity(
                supplyItemId = supplyItemId,
                movementType = movementType,
                quantity = quantity,
                roomId = roomId,
                reservationId = reservationId,
                notes = notes
            )
        )

        // If purchase, also log optional expense
        if (movementType == InventoryMovementEntity.TYPE_PURCHASE && item.lastPurchasePrice > 0) {
            dao.insertExpense(
                ExpenseEntity(
                    categoryName = item.name,
                    description = "Compra inventario: ${quantity} ${item.unit} de ${item.name}",
                    amount = quantity * item.lastPurchasePrice,
                    currency = item.currency,
                    roomId = roomId,
                    reservationId = reservationId,
                    supplier = item.supplier
                )
            )
        }

        dao.insertAuditLog(
            AuditLogEntity(
                entityType = "INVENTORY",
                entityId = supplyItemId,
                action = movementType,
                details = "$movementType $quantity ${item.unit} de ${item.name}. Stock final: $updatedStock"
            )
        )
    }

    // Cleaning & Maintenance
    suspend fun recordCleaning(roomId: Long, productsUsed: String, notes: String) =
        roomRepository.recordCleaning(roomId, productsUsed, notes)

    suspend fun recordMaintenance(
        roomId: Long,
        issue: String,
        priority: String,
        cost: Double = 0.0,
        technician: String? = null,
        notes: String = "",
        blockRoom: Boolean = true
    ) = roomRepository.recordMaintenance(roomId, issue, priority, cost, technician, notes, blockRoom)

    suspend fun resolveMaintenance(record: MaintenanceRecordEntity) =
        roomRepository.resolveMaintenance(record)

    // Exchange Rates
    suspend fun setExchangeRate(currencyCode: String, rateToPrimary: Double) {
        dao.insertOrUpdateExchangeRate(ExchangeRateEntity(currencyCode = currencyCode, rateToPrimary = rateToPrimary))
    }

    // SEED REALISTIC DEMO DATA ("Casa Nova" Hostal)
    suspend fun seedDemoData() {
        clearAllData()

        // Default Exchange Rates
        dao.insertOrUpdateExchangeRate(ExchangeRateEntity("USD", 1.0))
        dao.insertOrUpdateExchangeRate(ExchangeRateEntity("CUP", 500.0))
        dao.insertOrUpdateExchangeRate(ExchangeRateEntity("EUR", 0.92))
        dao.insertOrUpdateExchangeRate(ExchangeRateEntity("CAD", 1.38))

        // Default Categories
        val defaultCategories = listOf(
            "Papel sanitario", "Jabón", "Detergente", "Champú",
            "Electricidad", "Agua", "Reparaciones", "Mantenimiento",
            "Lavandería", "Comida/desayuno", "Transporte", "Otros"
        )
        defaultCategories.forEach { catName ->
            dao.insertExpenseCategory(ExpenseCategoryEntity(name = catName, isSystem = true))
        }

        // Rooms
        val room1Id = dao.insertRoom(
            RoomEntity(
                name = "Habitación 1 (Mar Azul)",
                description = "Amplia habitación con cama matrimonial y balcón privado.",
                capacity = 2,
                pricePerNight = 40.0,
                status = RoomEntity.ROOM_STATUS_OCCUPIED,
                features = "Aire Acondicionado, Baño Privado, Wi-Fi, Balcón, Minibar"
            )
        )
        val room2Id = dao.insertRoom(
            RoomEntity(
                name = "Habitación 2 (Sol Caliente)",
                description = "Habitación doble con aire acondicionado split.",
                capacity = 3,
                pricePerNight = 45.0,
                status = RoomEntity.ROOM_STATUS_MAINTENANCE,
                features = "Aire Acondicionado, TV Cable, Baño Privado"
            )
        )
        val room3Id = dao.insertRoom(
            RoomEntity(
                name = "Habitación 3 (Verde Palma)",
                description = "Habitación individual acogedora ideal para viajeros solos.",
                capacity = 1,
                pricePerNight = 30.0,
                status = RoomEntity.ROOM_STATUS_CLEANING_PENDING,
                features = "Aire Acondicionado, Baño Privado, Escritorio"
            )
        )
        val roomCasaCompleta = dao.insertRoom(
            RoomEntity(
                name = "Casa Nova Completa",
                description = "Alquiler de la casa entera de 3 habitaciones con cocina y terraza.",
                capacity = 7,
                pricePerNight = 120.0,
                status = RoomEntity.ROOM_STATUS_AVAILABLE,
                isEntireProperty = true,
                features = "3 Habitaciones, Cocina Equipada, Terraza, Garaje, Wi-Fi"
            )
        )

        // Guests
        val guest1Id = dao.insertGuest(
            GuestEntity(
                name = "María Fernández",
                phone = "+53 5212 3456",
                nationality = "España",
                notes = "Cliente habitual, prefiere almohadas extras."
            )
        )
        val guest2Id = dao.insertGuest(
            GuestEntity(
                name = "Carlos Miller",
                phone = "+1 305 888 9900",
                nationality = "Canadá",
                notes = "Llega tarde en vuelo nocturno."
            )
        )
        val guest3Id = dao.insertGuest(
            GuestEntity(
                name = "Juan Pérez",
                phone = "+53 5399 1122",
                nationality = "Cuba",
                notes = "Pago pendiente en CUP."
            )
        )

        val cal = Calendar.getInstance()

        // Active Reservation (María en Hab 1)
        val start1 = cal.timeInMillis - (2 * 86400000L) // hace 2 días
        val end1 = cal.timeInMillis + (3 * 86400000L)   // dentro de 3 días
        val res1Id = dao.insertReservation(
            ReservationEntity(
                guestId = guest1Id,
                roomId = room1Id,
                checkInDate = start1,
                checkOutDate = end1,
                pricePerNight = 40.0,
                totalPrice = 200.0,
                advancePayment = 80.0,
                currency = "USD",
                status = ReservationEntity.STATUS_CHECKED_IN,
                notes = "Reserva confirmada. Pagó $80 adelanto."
            )
        )
        dao.insertPayment(PaymentEntity(reservationId = res1Id, amount = 80.0, paymentType = "Adelanto", date = start1))
        dao.insertPayment(PaymentEntity(reservationId = res1Id, amount = 40.0, paymentType = "Parcial", date = cal.timeInMillis))

        // Upcoming Reservation (Carlos llega mañana en Hab 2)
        val start2 = cal.timeInMillis + (1 * 86400000L) // mañana
        val end2 = cal.timeInMillis + (5 * 86400000L)   // 4 noches
        val res2Id = dao.insertReservation(
            ReservationEntity(
                guestId = guest2Id,
                roomId = room2Id,
                checkInDate = start2,
                checkOutDate = end2,
                pricePerNight = 45.0,
                totalPrice = 180.0,
                advancePayment = 50.0,
                currency = "USD",
                status = ReservationEntity.STATUS_CONFIRMED,
                notes = "Llega mañana a las 15:00. Pide recogida en taxi."
            )
        )
        dao.insertPayment(PaymentEntity(reservationId = res2Id, amount = 50.0, paymentType = "Adelanto", date = cal.timeInMillis - 86400000L))

        // Checked Out Reservation (Juan salió ayer de Hab 3)
        val start3 = cal.timeInMillis - (5 * 86400000L)
        val end3 = cal.timeInMillis - (1 * 86400000L)
        val res3Id = dao.insertReservation(
            ReservationEntity(
                guestId = guest3Id,
                roomId = room3Id,
                checkInDate = start3,
                checkOutDate = end3,
                pricePerNight = 30.0,
                totalPrice = 120.0,
                advancePayment = 50.0,
                currency = "USD",
                status = ReservationEntity.STATUS_CHECKED_OUT,
                notes = "Salió ayer. Quedaron $35 pendientes por consumo minibar."
            )
        )
        dao.insertPayment(PaymentEntity(reservationId = res3Id, amount = 50.0, paymentType = "Adelanto", date = start3))
        dao.insertPayment(PaymentEntity(reservationId = res3Id, amount = 35.0, paymentType = "Parcial", date = end3))

        // Supplies
        dao.insertSupplyItem(
            SupplyItemEntity(
                name = "Papel Sanitario",
                category = "Baño",
                unit = "Rollo",
                currentStock = 6.0, // Alert low stock (< 10)
                minStock = 10.0,
                lastPurchasePrice = 0.50,
                supplier = "Mercado Central"
            )
        )
        dao.insertSupplyItem(
            SupplyItemEntity(
                name = "Jabón de Baño",
                category = "Baño",
                unit = "Unidad",
                currentStock = 18.0,
                minStock = 8.0,
                lastPurchasePrice = 0.80,
                supplier = "Distribuidora del Caribe"
            )
        )
        dao.insertSupplyItem(
            SupplyItemEntity(
                name = "Detergente Líquido",
                category = "Limpieza",
                unit = "Litro",
                currentStock = 8.0,
                minStock = 3.0,
                lastPurchasePrice = 2.50,
                supplier = "Tienda Local"
            )
        )
        dao.insertSupplyItem(
            SupplyItemEntity(
                name = "Café Molido",
                category = "Cocina",
                unit = "Paquete",
                currentStock = 4.0,
                minStock = 2.0,
                lastPurchasePrice = 3.20,
                supplier = "Productor Gourmet"
            )
        )

        // Maintenance Record
        dao.insertMaintenanceRecord(
            MaintenanceRecordEntity(
                roomId = room2Id,
                issue = "Aire acondicionado gotea en Habitación 2",
                priority = MaintenanceRecordEntity.PRIORITY_HIGH,
                status = MaintenanceRecordEntity.STATUS_PENDING,
                cost = 25.0,
                technician = "Técnico Roberto",
                notes = "Se requiere repuesto de manguera de desagüe."
            )
        )

        // Expenses
        dao.insertExpense(
            ExpenseEntity(
                categoryName = "Reparaciones",
                description = "Revisión técnica de A/C Habitación 2",
                amount = 18.0,
                roomId = room2Id,
                supplier = "Técnico Roberto"
            )
        )
        dao.insertExpense(
            ExpenseEntity(
                categoryName = "Papel sanitario",
                description = "Compra de paquete de papel sanitario x 12",
                amount = 6.0,
                supplier = "Mercado Central"
            )
        )

        dao.insertAuditLog(AuditLogEntity(entityType = "SYSTEM", entityId = 1, action = "SEED_DEMO", details = "Datos de prueba Casa Nova cargados con éxito"))
    }

    suspend fun clearAllData() {
        dao.clearReservations()
        dao.clearRooms()
        dao.clearGuests()
        dao.clearPayments()
        dao.clearExpenses()
        dao.clearSupplyItems()
        dao.clearInventoryMovements()
        dao.clearCleaningRecords()
        dao.clearMaintenanceRecords()
    }
}
