package com.example.varanova.data.repository

import com.example.varanova.data.dao.HostalDao
import com.example.varanova.data.model.*
import com.example.varanova.data.service.ReservationService
import com.example.varanova.data.service.RoomService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.*

class ReservationRepository(
    private val dao: HostalDao,
    private val roomService: RoomService = RoomService(dao),
    private val reservationService: ReservationService = ReservationService(dao, roomService),
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) {

    /**
     * StateFlow emitting the list of all reservations ordered by check-in date.
     * Provides immediate offline-first cached access for UI subscribers.
     */
    val allReservations: StateFlow<List<ReservationEntity>> = reservationService.allReservations
        .stateIn(
            scope = scope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val reservationsState: StateFlow<List<ReservationEntity>> = allReservations

    suspend fun getReservationById(id: Long): ReservationEntity? {
        return reservationService.getReservationById(id)
    }

    fun getReservationsForRoom(roomId: Long): Flow<List<ReservationEntity>> {
        return reservationService.getReservationsForRoom(roomId)
    }

    fun getPaymentsForReservation(reservationId: Long): Flow<List<PaymentEntity>> {
        return reservationService.getPaymentsForReservation(reservationId)
    }

    fun getReservationsWithDetails(
        guestsFlow: Flow<List<GuestEntity>>,
        roomsFlow: Flow<List<RoomEntity>>,
        paymentsFlow: Flow<List<PaymentEntity>>,
        expensesFlow: Flow<List<ExpenseEntity>>
    ): Flow<List<ReservationWithDetails>> {
        return reservationService.getReservationsWithDetails(
            guestsFlow,
            roomsFlow,
            paymentsFlow,
            expensesFlow
        )
    }

    suspend fun checkDateConflict(
        roomId: Long,
        checkInDate: Long,
        checkOutDate: Long,
        excludeReservationId: Long = 0
    ): Boolean {
        return reservationService.checkDateConflict(
            roomId,
            checkInDate,
            checkOutDate,
            excludeReservationId
        )
    }

    suspend fun saveReservation(reservation: ReservationEntity): Long {
        return reservationService.saveReservation(reservation)
    }

    suspend fun updateRoomStatusForReservation(reservation: ReservationEntity) {
        reservationService.updateRoomStatusForReservation(reservation)
    }

    suspend fun deleteReservation(reservation: ReservationEntity) {
        reservationService.deleteReservation(reservation)
    }

    suspend fun addPayment(payment: PaymentEntity): Long {
        return reservationService.addPayment(payment)
    }
}
