package com.example.varanova.data.dao

import androidx.room.*
import com.example.varanova.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface HostalDao : RoomDao {

    // --- HUÉSPEDES ---
    @Query("SELECT * FROM guests ORDER BY name ASC")
    fun getAllGuests(): Flow<List<GuestEntity>>

    @Query("SELECT * FROM guests WHERE id = :id")
    suspend fun getGuestById(id: Long): GuestEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGuest(guest: GuestEntity): Long

    @Update
    suspend fun updateGuest(guest: GuestEntity)

    @Delete
    suspend fun deleteGuest(guest: GuestEntity)

    // --- RESERVAS ---
    @Query("SELECT * FROM reservations ORDER BY checkInDate DESC")
    fun getAllReservations(): Flow<List<ReservationEntity>>

    @Query("SELECT * FROM reservations WHERE id = :id")
    suspend fun getReservationById(id: Long): ReservationEntity?

    @Query("SELECT * FROM reservations WHERE roomId = :roomId AND status != 'CANCELLED'")
    fun getReservationsForRoom(roomId: Long): Flow<List<ReservationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReservation(reservation: ReservationEntity): Long

    @Update
    suspend fun updateReservation(reservation: ReservationEntity)

    @Delete
    suspend fun deleteReservation(reservation: ReservationEntity)

    // --- PAGOS ---
    @Query("SELECT * FROM payments WHERE reservationId = :reservationId ORDER BY date DESC")
    fun getPaymentsForReservation(reservationId: Long): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments ORDER BY date DESC")
    fun getAllPayments(): Flow<List<PaymentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntity): Long

    @Delete
    suspend fun deletePayment(payment: PaymentEntity)

    // --- CATEGORÍAS DE GASTOS & GASTOS ---
    @Query("SELECT * FROM expense_categories ORDER BY name ASC")
    fun getAllExpenseCategories(): Flow<List<ExpenseCategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpenseCategory(category: ExpenseCategoryEntity): Long

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE roomId = :roomId ORDER BY date DESC")
    fun getExpensesForRoom(roomId: Long): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    // --- SUMINISTROS E INVENTARIO ---
    @Query("SELECT * FROM supply_items ORDER BY name ASC")
    fun getAllSupplyItems(): Flow<List<SupplyItemEntity>>

    @Query("SELECT * FROM supply_items WHERE id = :id")
    suspend fun getSupplyItemById(id: Long): SupplyItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplyItem(item: SupplyItemEntity): Long

    @Update
    suspend fun updateSupplyItem(item: SupplyItemEntity)

    @Delete
    suspend fun deleteSupplyItem(item: SupplyItemEntity)

    @Query("SELECT * FROM inventory_movements ORDER BY date DESC")
    fun getAllInventoryMovements(): Flow<List<InventoryMovementEntity>>

    @Query("SELECT * FROM inventory_movements WHERE supplyItemId = :supplyItemId ORDER BY date DESC")
    fun getMovementsForSupplyItem(supplyItemId: Long): Flow<List<InventoryMovementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventoryMovement(movement: InventoryMovementEntity): Long

    // --- LIMPIEZA & MANTENIMIENTO ---
    @Query("SELECT * FROM cleaning_records ORDER BY date DESC")
    fun getAllCleaningRecords(): Flow<List<CleaningRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCleaningRecord(record: CleaningRecordEntity): Long

    @Query("SELECT * FROM maintenance_records ORDER BY reportedDate DESC")
    fun getAllMaintenanceRecords(): Flow<List<MaintenanceRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaintenanceRecord(record: MaintenanceRecordEntity): Long

    @Update
    suspend fun updateMaintenanceRecord(record: MaintenanceRecordEntity)

    // --- TASAS DE CAMBIO & AUDITORÍA ---
    @Query("SELECT * FROM exchange_rates")
    fun getAllExchangeRates(): Flow<List<ExchangeRateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateExchangeRate(rate: ExchangeRateEntity)

    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAllAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity): Long

    // --- CLEAR ALL FOR DEMO RESET ---
    @Query("DELETE FROM reservations")
    suspend fun clearReservations()

    @Query("DELETE FROM guests")
    suspend fun clearGuests()

    @Query("DELETE FROM payments")
    suspend fun clearPayments()

    @Query("DELETE FROM expenses")
    suspend fun clearExpenses()

    @Query("DELETE FROM supply_items")
    suspend fun clearSupplyItems()

    @Query("DELETE FROM inventory_movements")
    suspend fun clearInventoryMovements()

    @Query("DELETE FROM cleaning_records")
    suspend fun clearCleaningRecords()

    @Query("DELETE FROM maintenance_records")
    suspend fun clearMaintenanceRecords()
}
