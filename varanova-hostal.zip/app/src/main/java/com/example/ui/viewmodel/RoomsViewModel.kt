package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.varanova.data.model.ReservationEntity
import com.example.varanova.data.model.RoomEntity
import com.example.varanova.data.model.RoomProfitability
import com.example.varanova.data.repository.HostalRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class RoomsUiState(
    val isLoading: Boolean = true,
    val rooms: List<RoomEntity> = emptyList(),
    val filteredRooms: List<RoomEntity> = emptyList(),
    val profitabilityList: List<RoomProfitability> = emptyList(),
    val selectedFilterStatus: String? = null,
    val selectedRoom: RoomEntity? = null,
    val userMessage: String? = null,
    val errorMessage: String? = null
)

class RoomsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = HostalRepository(AppDatabase.getDatabase(application).hostalDao())

    private val _uiState = MutableStateFlow(RoomsUiState())
    val uiState: StateFlow<RoomsUiState> = _uiState.asStateFlow()

    init {
        observeRoomsData()
    }

    private fun observeRoomsData() {
        viewModelScope.launch {
            combine(
                repository.allRooms,
                repository.reservationsWithDetails,
                repository.allExpenses
            ) { roomList, resList, expenseList ->
                val profitability = roomList.map { room ->
                    val roomRes = resList.filter { it.room.id == room.id && it.reservation.status != ReservationEntity.STATUS_CANCELLED }
                    val roomIncome = roomRes.sumOf { it.totalPaid }
                    val roomExpenses = expenseList.filter { it.roomId == room.id }.sumOf { it.amount }
                    val totalNights = roomRes.sumOf { it.nights }

                    RoomProfitability(
                        room = room,
                        totalIncome = roomIncome,
                        totalExpenses = roomExpenses,
                        netProfit = roomIncome - roomExpenses,
                        occupancyRatePercent = if (totalNights > 0) (totalNights.toDouble() / 30.0) * 100.0 else 0.0,
                        totalReservationsCount = roomRes.size,
                        totalNightsOccupied = totalNights
                    )
                }

                val currentFilter = _uiState.value.selectedFilterStatus
                val filtered = if (currentFilter == null) roomList else roomList.filter { it.status == currentFilter }

                RoomsUiState(
                    isLoading = false,
                    rooms = roomList,
                    filteredRooms = filtered,
                    profitabilityList = profitability,
                    selectedFilterStatus = currentFilter,
                    selectedRoom = _uiState.value.selectedRoom,
                    userMessage = _uiState.value.userMessage,
                    errorMessage = null
                )
            }.catch { e ->
                _uiState.update { it.copy(isLoading = false, errorMessage = e.localizedMessage) }
            }.collect { updatedState ->
                _uiState.value = updatedState
            }
        }
    }

    fun filterByStatus(status: String?) {
        _uiState.update { currentState ->
            val filtered = if (status == null) currentState.rooms else currentState.rooms.filter { it.status == status }
            currentState.copy(selectedFilterStatus = status, filteredRooms = filtered)
        }
    }

    fun selectRoom(room: RoomEntity?) {
        _uiState.update { it.copy(selectedRoom = room) }
    }

    fun saveRoom(room: RoomEntity) {
        viewModelScope.launch {
            try {
                repository.saveRoom(room)
                _uiState.update { it.copy(userMessage = "Habitación guardada correctamente") }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Error al guardar habitación: ${e.localizedMessage}") }
            }
        }
    }

    fun deleteRoom(room: RoomEntity) {
        viewModelScope.launch {
            try {
                repository.deleteRoom(room)
                _uiState.update { it.copy(userMessage = "Habitación eliminada") }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Error al eliminar habitación: ${e.localizedMessage}") }
            }
        }
    }

    fun clearUserMessage() {
        _uiState.update { it.copy(userMessage = null, errorMessage = null) }
    }
}

