package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.model.Reservation
import com.example.data.model.Room
import com.example.data.repository.ReservationRepository
import com.example.data.repository.RoomRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ReservationsUiState(
    val isLoading: Boolean = true,
    val reservations: List<Reservation> = emptyList(),
    val rooms: List<Room> = emptyList(),
    val selectedStatusFilter: String? = null,
    val userMessage: String? = null,
    val errorMessage: String? = null
)

class ReservationsViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val reservationRepository = ReservationRepository(db.reservationDao())
    private val roomRepository = RoomRepository(db.roomDao())

    private val _uiState = MutableStateFlow(ReservationsUiState())
    val uiState: StateFlow<ReservationsUiState> = _uiState.asStateFlow()

    init {
        observeData()
    }

    private fun observeData() {
        viewModelScope.launch {
            combine(
                reservationRepository.allReservations,
                roomRepository.allRooms,
                _uiState.map { it.selectedStatusFilter }.distinctUntilChanged()
            ) { reservations, rooms, filter ->
                val filtered = if (filter == null) {
                    reservations
                } else {
                    reservations.filter { it.status == filter }
                }

                ReservationsUiState(
                    isLoading = false,
                    reservations = filtered,
                    rooms = rooms,
                    selectedStatusFilter = filter,
                    userMessage = _uiState.value.userMessage,
                    errorMessage = null
                )
            }.catch { e ->
                _uiState.update { it.copy(isLoading = false, errorMessage = e.localizedMessage) }
            }.collect { state ->
                _uiState.value = state
            }
        }
    }

    fun filterByStatus(status: String?) {
        _uiState.update { it.copy(selectedStatusFilter = status) }
    }

    fun saveReservation(reservation: Reservation) {
        viewModelScope.launch {
            try {
                reservationRepository.saveReservation(reservation)
                _uiState.update { it.copy(userMessage = "Reserva guardada correctamente") }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Error al guardar reserva: ${e.localizedMessage}") }
            }
        }
    }

    fun deleteReservation(reservation: Reservation) {
        viewModelScope.launch {
            try {
                reservationRepository.deleteReservation(reservation)
                _uiState.update { it.copy(userMessage = "Reserva eliminada") }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Error al eliminar reserva: ${e.localizedMessage}") }
            }
        }
    }

    fun clearUserMessage() {
        _uiState.update { it.copy(userMessage = null, errorMessage = null) }
    }
}
