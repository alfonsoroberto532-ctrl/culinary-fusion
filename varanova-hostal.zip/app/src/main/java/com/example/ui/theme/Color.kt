package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// VaraNova Hostal Professional Light Theme Palette
val TealPrimary = Color(0xFF0284C7)             // Deep Vibrant Sky/Ocean Teal
val TealPrimaryContainer = Color(0xFFE0F2FE)    // Crisp Soft Blue Container
val AmberSecondary = Color(0xFFD97706)          // Warm Gold Accent
val AmberSecondaryContainer = Color(0xFFFEF3C7) // Soft Amber Light
val EmeraldTertiary = Color(0xFF059669)         // Emerald Success
val EmeraldTertiaryContainer = Color(0xFFD1FAE5)// Soft Emerald Light

val SlateDark = Color(0xFF0F172A)               // High-Contrast Midnight Text
val SlateLightBackground = Color(0xFFF8FAFC)     // Crisp Soft Neutral Off-White Canvas
val SlateSurface = Color(0xFFFFFFFF)            // Pure White Surface Card

// Status Colors for Rooms & Reservations
val StatusAvailable = Color(0xFF059669)   // Green
val StatusReserved = Color(0xFF2563EB)    // Royal Blue
val StatusOccupied = Color(0xFFDC2626)    // Coral Red
val StatusCleaning = Color(0xFFD97706)    // Amber Gold
val StatusMaintenance = Color(0xFF7C3AED) // Purple Violet
