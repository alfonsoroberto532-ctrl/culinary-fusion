package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.model.Expense
import com.example.data.model.Reservation
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class FinancesUiState(
    val isLoading: Boolean = true,
    val expenses: List<Expense> = emptyList(),
    val reservations: List<Reservation> = emptyList(),
    val totalIncome: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val netProfit: Double = 0.0,
    val userMessage: String? = null,
    val errorMessage: String? = null
)

class FinancesViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val expenseDao = db.expenseDao()
    private val reservationDao = db.reservationDao()

    private val _uiState = MutableStateFlow(FinancesUiState())
    val uiState: StateFlow<FinancesUiState> = _uiState.asStateFlow()

    init {
        observeFinances()
    }

    private fun observeFinances() {
        viewModelScope.launch {
            combine(
                expenseDao.getAll(),
                reservationDao.getAll()
            ) { expenseList, reservationList ->
                val income = reservationList.sumOf { it.price - it.balance }
                val expenseTotal = expenseList.sumOf { it.amount }

                FinancesUiState(
                    isLoading = false,
                    expenses = expenseList,
                    reservations = reservationList,
                    totalIncome = income,
                    totalExpenses = expenseTotal,
                    netProfit = income - expenseTotal,
                    userMessage = _uiState.value.userMessage,
                    errorMessage = null
                )
            }.catch { e ->
                _uiState.update { it.copy(isLoading = false, errorMessage = e.localizedMessage) }
            }.collect { state ->
                _uiState.value = state
            }
        }
    }

    fun addExpense(expense: Expense) {
        viewModelScope.launch {
            try {
                expenseDao.insert(expense)
                _uiState.update { it.copy(userMessage = "Gasto registrado correctamente") }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Error al guardar gasto: ${e.localizedMessage}") }
            }
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            try {
                expenseDao.delete(expense)
                _uiState.update { it.copy(userMessage = "Gasto eliminado") }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Error al eliminar gasto: ${e.localizedMessage}") }
            }
        }
    }

    fun clearUserMessage() {
        _uiState.update { it.copy(userMessage = null, errorMessage = null) }
    }
}
