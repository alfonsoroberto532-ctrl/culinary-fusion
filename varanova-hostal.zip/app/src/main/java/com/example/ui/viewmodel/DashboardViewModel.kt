package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.varanova.data.model.RoomEntity
import com.example.varanova.data.model.SmartDashboardAlert
import com.example.varanova.data.repository.HostalRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class DashboardUiState(
    val isLoading: Boolean = true,
    val rooms: List<RoomEntity> = emptyList(),
    val totalRoomsCount: Int = 0,
    val occupiedRoomsCount: Int = 0,
    val occupancyRate: Float = 0f,
    val smartAlerts: List<SmartDashboardAlert> = emptyList(),
    val errorMessage: String? = null
)

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = HostalRepository(AppDatabase.getDatabase(application).hostalDao())

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        observeDashboardData()
    }

    private fun observeDashboardData() {
        viewModelScope.launch {
            combine(
                repository.allRooms,
                repository.reservationsWithDetails,
                repository.allSupplyItems,
                repository.allMaintenanceRecords
            ) { rooms, reservations, supplies, maintenance ->
                val occupiedCount = rooms.count { it.status == RoomEntity.ROOM_STATUS_OCCUPIED }
                val rate = if (rooms.isNotEmpty()) (occupiedCount.toFloat() / rooms.size) * 100f else 0f

                val alerts = mutableListOf<SmartDashboardAlert>()
                supplies.filter { it.currentStock <= it.minStock }.forEach { item ->
                    alerts.add(
                        SmartDashboardAlert(
                            id = "stock_${item.id}",
                            title = "Stock bajo de insumos",
                            message = "⚠️ ${item.name}: quedan ${item.currentStock.toInt()} ${item.unit} (mínimo ${item.minStock.toInt()}).",
                            type = SmartDashboardAlert.AlertType.WARNING,
                            iconName = "inventory",
                            targetTabRoute = "supplies"
                        )
                    )
                }

                DashboardUiState(
                    isLoading = false,
                    rooms = rooms,
                    totalRoomsCount = rooms.size,
                    occupiedRoomsCount = occupiedCount,
                    occupancyRate = rate,
                    smartAlerts = alerts,
                    errorMessage = null
                )
            }.catch { e ->
                _uiState.update { it.copy(isLoading = false, errorMessage = e.localizedMessage) }
            }.collect { state ->
                _uiState.value = state
            }
        }
    }

    fun refreshDashboard() {
        _uiState.update { it.copy(isLoading = true) }
        observeDashboardData()
    }
}
