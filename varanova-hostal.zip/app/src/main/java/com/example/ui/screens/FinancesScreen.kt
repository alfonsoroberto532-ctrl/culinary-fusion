package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.utils.DateUtils
import com.example.ui.components.EmptyState
import com.example.ui.viewmodel.FinancesViewModel
import com.example.varanova.ui.components.SectionHeader
import com.example.varanova.ui.components.StatCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinancesScreen(
    viewModel: FinancesViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Módulo Financiero", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        if (uiState.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    SectionHeader(
                        title = "Balance Financiero General",
                        subtitle = "Ingresos por reservas vs Gastos registrados"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatCard(
                            title = "Ingresos Totales",
                            value = DateUtils.formatCurrency(uiState.totalIncome),
                            subtitle = "Por reservas confirmadas",
                            icon = Icons.Default.AttachMoney,
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.weight(1f),
                            testTag = "stat_total_income"
                        )

                        StatCard(
                            title = "Gastos Totales",
                            value = DateUtils.formatCurrency(uiState.totalExpenses),
                            subtitle = "Mantenimiento e insumos",
                            icon = Icons.Default.MoneyOff,
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f),
                            testTag = "stat_total_expenses"
                        )
                    }
                }

                item {
                    StatCard(
                        title = "Utilidad Neta del Hostal",
                        value = DateUtils.formatCurrency(uiState.netProfit),
                        subtitle = if (uiState.netProfit >= 0) "Balance positivo" else "Atención: Margen negativo",
                        icon = Icons.Default.AccountBalanceWallet,
                        containerColor = if (uiState.netProfit >= 0) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.errorContainer,
                        contentColor = if (uiState.netProfit >= 0) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onErrorContainer,
                        testTag = "stat_net_profit"
                    )
                }

                item {
                    SectionHeader(title = "Registro de Gastos Recientes")
                }

                if (uiState.expenses.isEmpty()) {
                    item {
                        EmptyState(
                            title = "Sin Gastos Registrados",
                            message = "No se han ingresado gastos aún en este período.",
                            icon = Icons.Default.ReceiptLong,
                            testTag = "expenses_empty_state"
                        )
                    }
                } else {
                    items(uiState.expenses) { expense ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("expense_item_${expense.id}"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = expense.description.ifEmpty { "Gasto #${expense.id}" },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = "${expense.category} • ${DateUtils.formatDate(expense.date)}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Text(
                                    text = "- ${DateUtils.formatCurrency(expense.amount)}",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}
